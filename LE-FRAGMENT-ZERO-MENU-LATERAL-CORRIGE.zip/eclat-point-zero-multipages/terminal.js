const form=document.querySelector('#term-form'),input=document.querySelector('#command'),out=document.querySelector('#output');
function say(t){const p=document.createElement('p');p.textContent=t;out.append(p)}
function link(t,href){const p=document.createElement('p');const a=document.createElement('a');a.href=href;a.textContent=t;a.className='button';p.append(a);out.append(p)}
const secrets={
 signalbleu:'FRAGMENT 007 : Signal bleu actif. Une transmission porte la signature d’Aidan.',
 aidanestvivant:'FRAGMENT 008 : Une partie du système d’Aidan répond encore. Identité non confirmée.',
 retourimpossible:'FRAGMENT 009 : Une silhouette ressemblant à Jean a été détectée dans la faille.',
 realiteunique:'FRAGMENT 005 : Jean veut imposer une réalité unique.',
 levidenousobserve:'FRAGMENT 006 : Quelqu’un observe les survivants.'
};
form.addEventListener('submit',e=>{e.preventDefault();const c=input.value.trim().toLowerCase();if(!c)return;say('root@point-zero:~$ '+c);
 if(c==='help')say('Commandes : help, status, files, clear, unlock <code>. Code classé : 286265');
 else if(c==='status')say('POINT ZERO : INSTABLE // SIGNAL : DÉGRADÉ // RÉALITÉS : INCONNUES');
 else if(c==='files')say('Fichiers : fragment_005, fragment_006, fragment_007, fragment_008, fragment_009. Un dossier source reste verrouillé.');
 else if(c==='clear')out.replaceChildren();
 else if(c.startsWith('unlock ')){const code=c.slice(7).trim();if(code==='286265'||code==='origine286'){say('CODE ACCEPTÉ. IDENTITÉS CONFIRMÉES : JEAN / BEN. DOSSIER SOURCE DÉVERROUILLÉ.');say('Avertissement : ce dossier contient des souvenirs effacés et une chronologie complète.');link('OUVRIR LE DOSSIER SECRET — LE PASSÉ DE JEAN ET BEN','secret-origines.html');}else if(secrets[code])say('ACCÈS AUTORISÉ — '+secrets[code]);else say('CODE INVALIDE. Accès refusé.');}
 else say('Commande inconnue. Tape help.');input.value='';});
