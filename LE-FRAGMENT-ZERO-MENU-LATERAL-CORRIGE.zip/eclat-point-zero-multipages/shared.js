// Navigation active + transition interdimensionnelle entre les pages.
(() => {
  const current = location.pathname.split('/').pop() || 'index.html';
  // Niveau de glitch mémorisé entre les pages, utilisé UNIQUEMENT pendant le chargement.
  const CORRUPTION_KEY = 'pz_corruption_level_v2';
  const LAST_PAGE_KEY = 'pz_last_page_v2';
  let corruption = 0;
  try {
    const previousPage = sessionStorage.getItem(LAST_PAGE_KEY);
    corruption = Number(sessionStorage.getItem(CORRUPTION_KEY) || 0);
    if (previousPage && previousPage !== current) corruption = Math.min(9, corruption + 1);
    sessionStorage.setItem(CORRUPTION_KEY, String(corruption));
    sessionStorage.setItem(LAST_PAGE_KEY, current);
  } catch (_) {}
  document.documentElement.dataset.corruption = String(corruption);
  document.documentElement.style.setProperty('--corruption-level', String(corruption));
  const pageNames = {
    'index.html': 'de l’accueil', 'histoire.html': 'de l’histoire',
    'dialogues.html': 'des dialogues', 'personnages.html': 'des personnages',
    'archives.html': 'des archives', 'terminal.html': 'du terminal',
    'secret-origines.html': 'du dossier classifié', 'inconnu.html': 'de la transmission inconnue'
  };
  const loader = document.createElement('div');
  loader.id = 'point-zero-loader';
  loader.dataset.glitchLevel = String(corruption);
  loader.setAttribute('role', 'status');
  loader.setAttribute('aria-live', 'polite');
  const label = pageNames[current] || 'de la réalité';
  loader.innerHTML = `
    <div class="hack-rain" aria-hidden="true">0101 // ACCESS // 1010 // REALITY // 0011 // POINT ZERO //</div>
    <div class="point-zero-loader-content hack-boot">
      <p class="point-zero-loader-kicker">ROOT ACCESS // INSTITUT ONIRIQUE</p>
      <div class="hack-loader-mark" aria-hidden="true"><span class="zero-point-symbol">◉</span></div>
      <p class="point-zero-loader-title">L’ÉCLAT <span>DU POINT ZÉRO</span></p>
      <div class="hack-console" aria-live="polite"><p><b>[ OK ]</b> Connexion au réseau interdimensionnel</p><p><b>[ OK ]</b> Décryptage ${label.toUpperCase()}</p><p class="hack-last-line"><b>[ .. ]</b> Injection de la réalité<span class="loader-dots">...</span></p></div>
      <div class="point-zero-loader-track" role="progressbar" aria-label="Initialisation du système"><span></span></div>
      <p class="point-zero-loader-foot">SESSION CHIFFRÉE <span>//</span> ACCÈS AUTORISÉ ?</p>
    </div>`;
  document.body.appendChild(loader);
  // Le glitch est concentré sur l'écran de chargement; la page reste propre après la transition.
  loader.style.setProperty('--glitch-strength', String(corruption));
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  window.setTimeout(() => loader.classList.add('loader-hidden'), reducedMotion ? 120 : 1250);
  window.setTimeout(() => loader.remove(), reducedMotion ? 240 : 1600);
  const links = [...document.querySelectorAll('nav a')];
  links.forEach((a, i) => {
    if (a.getAttribute('href') === current) {
      a.classList.add('active');
      a.setAttribute('aria-current', 'page');
    }
    a.style.setProperty('--nav-index', i);
    a.addEventListener('click', (event) => {
      const href = a.getAttribute('href');
      if (!href || href === current || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      // Brief visual glitch before native navigation; corruption level persists on next page.
      document.body.classList.add('page-leaving', 'glitch-transition');
      const overlay = document.querySelector('.transition-overlay');
      if (overlay) overlay.classList.add('active');
      return;
    });
  });
  // Accessible hack-style dropdown navigation shared by every page.
  const menuButton = document.querySelector('.menu-toggle');
  const menuPanel = document.querySelector('#site-navigation.site-navigation');
  if (menuButton && menuPanel) {
    const setMenuOpen = (opening) => {
      menuButton.setAttribute('aria-expanded', String(opening));
      menuButton.setAttribute('aria-label', opening ? 'Fermer le menu' : 'Ouvrir le menu');
      menuPanel.classList.toggle('open', opening);
      menuPanel.setAttribute('aria-hidden', String(!opening));
    };
    setMenuOpen(false);
    menuButton.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      setMenuOpen(menuButton.getAttribute('aria-expanded') !== 'true');
    });
    menuPanel.addEventListener('click', (event) => {
      if (event.target.closest('a')) setMenuOpen(false);
    });
    document.addEventListener('click', (event) => {
      if (!event.target.closest('.site-menu')) setMenuOpen(false);
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') { setMenuOpen(false); menuButton.focus(); }
    });
  }
  document.body.classList.add('page-ready');
})();
