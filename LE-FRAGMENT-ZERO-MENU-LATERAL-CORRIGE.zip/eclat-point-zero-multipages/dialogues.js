const scenes = [
 {label:"TRANSMISSION 001 — SIGNAL INSTABLE", title:"Le dernier avertissement", lines:[
 ["BEN","ben",`Jean ? Réponds-moi. Je sais que tu captes cette fréquence.`],
 ["JEAN","jean",`Je t'entends depuis le début, Ben. C'est toi qui refuses d'écouter.`],
 ["BEN","ben",`Alors dis-moi où est Aidan.`],
 ["JEAN","jean",`Tu poses la mauvaise question. Tu devrais te demander pourquoi son dernier signal est apparu après que j'ai coupé le réseau.`],
 ["BEN","ben",`Parce que tu mens. Tu as toujours menti sur ce qui s'est passé dans cette station.`],
 ["JEAN","jean",`Je t'ai caché des choses, oui. Mais pas pour les raisons que tu imagines.`],
 ["BEN","ben",`Tu as abandonné nos amis et condamné des réalités entières. Tu veux encore me faire croire que tu avais une bonne raison ?`],
 ["JEAN","jean",`J'ai vu ce qui arrive quand on laisse le choix à tout le monde. Chaque choix crée une autre possibilité. Chaque possibilité crée un autre conflit.`],
 ["BEN","ben",`Alors tu veux supprimer tous les choix ? Tu appelles ça la paix ?`],
 ["JEAN","jean",`J'appelle ça une chance. Une seule réalité. Une seule histoire. Et tous ceux qui pourraient s'opposer à moi disparaîtront.`],
 ["BEN","ben",`Tu ne veux pas sauver le monde. Tu veux être le seul à décider qui a le droit d'y vivre.`],
 ["JEAN","jean",`Enfin, tu commences à comprendre.`],
 ["BEN","ben",`Je vais entrer chez DECA. Je trouverai tes dossiers et je montrerai à tout le monde ce que tu prépares.`],
 ["JEAN","jean",`Tu peux essayer. La liste est déjà prête, Ben. Et ton nom est dessus.`]
 ]},
 {label:"TRANSMISSION 002 — ARCHIVE DECA", title:"Ce que Jean a sacrifié", lines:[
 ["VANNY","ben",`J'ai ouvert le dossier verrouillé. Ben, tu dois voir ça.`],
 ["BEN","ben",`Des noms… des centaines de noms. Ce n'est pas une liste de coordonnées.`],
 ["VANNY","ben",`Ce sont les personnes que Jean considère comme des menaces. Les lieux sont classés par ordre d'intervention.`],
 ["BEN","ben",`Il ne cherche pas à réparer le Point Zéro. Il prépare une élimination systématique.`],
 ["VANNY","ben",`Et DECA lui fournit les moyens de localiser les survivants entre les réalités.`],
 ["BEN","ben",`Alors on copie tout. Les rapports, les noms, les ordres. On a besoin de preuves avant de sortir d'ici.`],
 ["DUCKY","ben",`J'aimerais signaler que les portes viennent de se verrouiller. Je crois que notre petite visite est terminée.`],
 ["VANNY","ben",`La sécurité a détecté notre accès. Ben, il nous reste moins d'une minute.`],
 ["BEN","ben",`Prends le dossier principal. Je vais détourner les caméras.`],
 ["VANNY","ben",`Tu ne peux pas affronter Jean seul !`],
 ["BEN","ben",`Je ne l'affronte pas. Pas encore. Je veux que le monde sache ce qu'il a fait.`],
 ["SYSTÈME","jean",`MESSAGE PRIORITAIRE : « L'intrusion était prévue. Merci d'avoir ouvert le dernier dossier. »`],
 ["BEN","ben",`Il savait qu'on viendrait… On n'a pas trouvé son piège. On vient d'activer quelque chose.`]
 ]},
 {label:"TRANSMISSION 003 — ORIGINE INCONNUE", title:"Une voix qui ne devrait plus exister", lines:[
 ["VANNY","ben",`J'ai récupéré un fichier audio de DECA. La date est postérieure à la mort d'Aidan.`],
 ["BEN","ben",`Alors c'est un faux. Aidan est mort. Je l'ai vu.`],
 ["VANNY","ben",`Je sais. Mais écoute : le fichier contient des détails qui ne figurent dans aucune archive publique.`],
 ["ENREGISTREMENT","aidan",`Ben… si tu entends ceci, ne viens pas me chercher.`],
 ["BEN","ben",`C'est sa voix. Mais ça ne peut pas être lui.`],
 ["VANNY","ben",`Le fichier a été créé à partir de données récupérées pendant les expériences de DECA. Quelqu'un peut l'avoir fabriqué.`],
 ["BEN","ben",`Ou Jean veut que je croie Aidan vivant pour me faire sortir de ma cachette.`],
 ["DR VOSS","jean",`Vous commencez enfin à poser la bonne question.`],
 ["BEN","ben",`Dr Voss ? Comment êtes-vous entré sur cette fréquence ?`],
 ["DR VOSS","jean",`Je l'ai conçue. Et si vous voulez survivre à cette nuit, cessez de croire que DECA est simplement un laboratoire.`],
 ["VANNY","ben",`Qu'est-ce que c'est, alors ?`],
 ["DR VOSS","jean",`La machine qui permet à Jean de retrouver ceux qu'il veut faire disparaître. J'ai contribué à sa création, et je ne pourrai jamais effacer cette faute.`],
 ["BEN","ben",`Pourquoi nous aider maintenant ?`],
 ["DR VOSS","jean",`Je ne vous aide pas. J'essaie de corriger une erreur que j'aurais dû empêcher avant la mort d'Aidan.`],
 ["SYSTÈME","jean",`ALERTE : ACCÈS NON AUTORISÉ. VERROUILLAGE DE DECA DANS 60 SECONDES.`],
 ["VANNY","ben",`Ben, on doit bouger. Maintenant !`],
 ["BEN","ben",`Copie les fichiers. Tous. Si Jean veut effacer nos noms, on va d'abord révéler le sien.`]
 ]}
 ,{label:"TRANSMISSION 004 — IDENTITÉ INCONNUE", title:"Elle dit s’appeler Olie", lines:[
 ["DOCTEUR VOSS","jean",`Personne n'avance.`],
 ["DUCKY","ben",`Pour une fois, je suis d'accord sans même faire de blague.`],
 ["VANNY","ben",`Ce n'est pas Jean.`],
 ["BEN","ben",`Non. Je ne l'ai jamais vue.`],
 ["OLIE","aidan",`Toi… Tu as ses yeux.`],
 ["BEN","ben",`Les yeux de qui ?`],
 ["OLIE","aidan",`De mon frère.`],
 ["DOCTEUR VOSS","jean",`Ton frère ?`],
 ["OLIE","aidan",`Jean.`],
 ["BEN","ben",`Jean n'a pas de sœur. Il n'en a jamais parlé.`],
 ["OLIE","aidan",`Il ne savait pas non plus. Pas avant qu'on le lui dise.`],
 ["DUCKY","ben",`Je crois qu'on vient d'ouvrir un tout nouveau tiroir.`],
 ["BEN","ben",`Attends… Pourquoi tu me regardes comme si tu me connaissais ?`],
 ["OLIE","aidan",`Parce que toi aussi, tu as ses yeux. Les mêmes que les siens.`],
 ["BEN","ben",`Qu'est-ce que tu racontes ?`],
 ["OLIE","aidan",`Je ne suis pas venue pour ça. Pas seulement.`],
 ["DOCTEUR VOSS","jean",`Alors pourquoi es-tu là ? Qui t'envoie ?`],
 ["OLIE","aidan",`Lui.`],
 ["VANNY","ben",`Qui, lui ?`],
 ["OLIE","aidan",`Celui que vous appelez Le Vide.`],
 ["BEN","ben",`Il t'a envoyée ?`],
 ["OLIE","aidan",`Il voulait que quelqu'un vous parle. Quelqu'un qu'il ne pouvait pas effrayer en se montrant lui-même.`],
 ["DOCTEUR VOSS","jean",`Pourquoi maintenant ?`],
 ["OLIE","aidan",`Parce qu'il a peur que vous ne compreniez jamais pourquoi il est parti, le jour où il est arrivé sur l'île 268.`],
 ["BEN","ben",`Il a attaqué cette île.`],
 ["OLIE","aidan",`Non. Il a fui cette île.`],
 ["DUCKY","ben",`Fui ? Lui ?`],
 ["OLIE","aidan",`Il a senti quelque chose qu'il n'avait pas ressenti depuis très longtemps. Et ça l'a terrifié plus que n'importe quel ennemi.`],
 ["VANNY","ben",`Ressenti quoi ?`],
 ["OLIE","aidan",`Du remords.`],
 ["DOCTEUR VOSS","jean",`Tu es en train de nous dire que Le Vide a des remords ?`],
 ["OLIE","aidan",`Je suis en train de vous dire qu'il ne veut plus se battre.`],
 ["BEN","ben",`Facile à dire, après tout ce qu'il a effacé.`],
 ["OLIE","aidan",`Il le sait. Il ne vous demande pas de pardonner. Il veut seulement reprendre sa forme. Sa vraie forme.`],
 ["DOCTEUR VOSS","jean",`Sa vraie forme ?`],
 ["OLIE","aidan",`Il a un nom. Il en a toujours eu un. Alyss Derimight.`],
 ["VANNY","ben",`Alyss Derimight…`],
 ["BEN","ben",`Et Jean, dans tout ça ?`],
 ["OLIE","aidan",`Toujours là-bas. Toujours pris dans cette réalité qui n'en finit pas.`],
 ["BEN","ben",`Tu peux l'en sortir ?`],
 ["OLIE","aidan",`Pas seule. Pas sans vous.`],
 ["DOCTEUR VOSS","jean",`Et pourquoi on te ferait confiance ?`],
 ["OLIE","aidan",`Parce que je suis sortie du même endroit que lui. Et que je suis revenue pour le ramener. Pas pour vous mentir.`],
 ["BEN","ben",`Si tu es vraiment sa sœur… pourquoi je ne l'ai jamais su ?`],
 ["OLIE","aidan",`Parce que certaines vérités attendent que le monde soit prêt à s'effondrer un peu, avant de se reconstruire autrement.`],
 ["DOCTEUR VOSS","jean",`Bien. On t'écoute. Mais on ne baisse pas notre garde.`],
 ["OLIE","aidan",`Je n'en attendais pas moins de vous.`],
 ["ALYSS","jean",`Olie.`],
 ["OLIE","aidan",`Alyss… Tu avais dit que tu ne viendrais pas.`],
 ["ALYSS","jean",`J'avais dit que je ne viendrais pas devant eux.`],
 ["BEN","ben",`Le Vide…`],
 ["ALYSS","jean",`Ce nom. Je vous ai demandé de ne plus m'appeler ainsi.`],
 ["DOCTEUR VOSS","jean",`Tu débarques après tout ce que tu as fait et tu espères qu'on t'accueille comment ?`],
 ["ALYSS","jean",`Je n'espère rien. Je suis venu parce que vous avez le droit de connaître la vérité.`],
 ["BEN","ben",`Alors commence par nous dire où est Jean.`],
 ["ALYSS","jean",`Je ne sais pas s'il est encore possible de le sauver.`],
 ["OLIE","aidan",`Tu m'as promis qu'on le ramènerait.`],
 ["ALYSS","jean",`Je t'ai promis que j'essaierais.`],
 ["BEN","ben",`Alors on essaiera tous.`],
 ["ALYSS","jean",`Tu lui ressembles tellement…`],
 ["BEN","ben",`Je ne suis pas Jean.`],
 ["ALYSS","jean",`Je sais. C'est justement pour ça que j'ai peur.`],
 ["DOCTEUR VOSS","jean",`Tu vas nous raconter ce qui est arrivé à Jean. Tout.`],
 ["ALYSS","jean",`D'accord. Mais si nous voulons le retrouver, nous devrons retourner à l'endroit où tout a commencé.`],
 ["BEN","ben",`Et qu'est-ce qui nous attend là-bas ?`],
 ["ALYSS","jean",`Quelque chose qui ne veut surtout pas que Jean revienne.`],
 ["OLIE","aidan",`Non… Ce n'est pas possible.`],
 ["VANNY","ben",`Olie ? Qu'est-ce qu'il y a ?`],
 ["OLIE","aidan",`Ce n'est pas Jean. C'est celui qui l'a enfermé.`]
 ]}

];
let sceneIndex = 0, lineCount = 1;
const content = document.querySelector('#dialogue-content');
const title = document.querySelector('#scene-title');
const label = document.querySelector('#scene-label');
const progress = document.querySelector('#progress');
const next = document.querySelector('#next-line');
function render() {
 const scene = scenes[sceneIndex]; title.textContent = scene.title; label.textContent = scene.label; content.replaceChildren();
 scene.lines.slice(0, lineCount).forEach(([speaker, type, text]) => {
  const div = document.createElement('div'); div.className = 'dialogue-line ' + type;
  const name = document.createElement('span'); name.className = 'speaker'; name.textContent = speaker;
  const words = document.createElement('div'); words.textContent = '« ' + text + ' »'; div.append(name, words); content.append(div);
 });
 progress.textContent = `Réplique ${Math.min(lineCount, scene.lines.length)} / ${scene.lines.length}`;
 next.textContent = lineCount >= scene.lines.length ? 'RECOMMENCER ↻' : 'RÉPLIQUE SUIVANTE →';
}
document.querySelectorAll('[data-scene]').forEach(button => button.addEventListener('click', () => {
 sceneIndex = Number(button.dataset.scene); lineCount = 1;
 document.querySelectorAll('[data-scene]').forEach(item => item.classList.toggle('active', item === button)); render();
}));
next.addEventListener('click', () => { lineCount = lineCount >= scenes[sceneIndex].lines.length ? 1 : lineCount + 1; render(); });
render();
