const form=document.querySelector('#term-form'),input=document.querySelector('#command'),out=document.querySelector('#output');
/* Les réponses sont conservées en français puis retraduites au rendu :
   l'historique reste lisible après un changement de langue. */
const tr=(value)=>(window.FZ&&typeof window.FZ.t==='function')?window.FZ.t(value):value;
const history=[];
function paint(){
 out.replaceChildren();
 history.forEach((item)=>{
  const p=document.createElement('p');
  if(item.href){const a=document.createElement('a');a.href=item.href;a.textContent=tr(item.text);a.className='button';p.append(a);}
  else if(item.raw)p.textContent=item.text;
  else p.textContent=(item.prefix?tr(item.prefix)+' ':'')+tr(item.text);
  out.append(p);
 });
}
function say(text,raw=false,prefix=null){history.push({text,raw,prefix});paint();}
function link(text,href){history.push({text,href});paint();}
const secrets={
 signalbleu:'FRAGMENT 007 : Signal bleu actif. Une transmission porte la signature d’Aidan.',
 aidanestvivant:'FRAGMENT 008 : Une partie du système d’Aidan répond encore. Identité non confirmée.',
 retourimpossible:'FRAGMENT 009 : Une silhouette ressemblant à Jean a été détectée dans la faille.',
 realiteunique:'FRAGMENT 005 : Jean veut imposer une réalité unique.',
 levidenousobserve:'FRAGMENT 006 : Quelqu’un observe les survivants.',
 kael:'FRAGMENT 010 : Un individu nommé KAEL est arrivé sur l’île grâce à une machine temporelle. Signature temporelle confirmée.',
 ancienallie:'FRAGMENT 011 : KAEL et JEAN ont autrefois été des amis proches. Une dispute ancienne a mis fin à leur relation.',
 oliekael:'FRAGMENT 012 : Olie et Kael se connaissent. Ils ont partagé une aventure dont les détails ne figurent pas dans les archives.',
 sanctuaire:'FRAGMENT 013 : Le fragment rose-violet est apparu au centre d’un sanctuaire circulaire bleu. Les alliés l’ont récupéré avant Jean.',
 dernierfragment:'FRAGMENT 014 : Le dernier fragment du deuxième Point Zéro a permis aux alliés de vaincre Jean.',
 etoile:'FRAGMENT 015 : La lumière dans le ciel était la machine de Jean détruite. Jean s’est désintégré en étoile. Aucun signal de menace.',
 restauration:'FRAGMENT 016 : Le Point Zéro a été libéré et certaines villes corrompues ont été restaurées. L’île est reconstruite.',
 kaelretour:'FRAGMENT 017 : Kael est arrivé par machine temporelle à la villa du lac. Ancien ami proche de Jean, il connaît aussi Olie.',
 signalfreaky:'FRAGMENT 018 : Une pulsation bleue a été détectée sous Freaky Zero. Sa signature ne correspond à aucun Point Zéro ni fragment connu.',
 porte:'FRAGMENT 019 : Les relevés indiquent une structure géométrique enfouie sous la forêt. Il pourrait s’agir d’un passage, mais aucune ouverture n’a été confirmée.',
 reponse:'FRAGMENT 020 : Le signal contient une phrase : « Vous avez libéré le Point Zéro. Mais vous n’avez jamais découvert ce qu’il retenait. » Source inconnue.'
};
form.addEventListener('submit',e=>{e.preventDefault();const c=input.value.trim().toLowerCase();if(!c)return;say('root@point-zero:~$ '+c,true);
 if(c==='help'){
  say('Commandes : help, status, files, clear, unlock');
  say('Codes classés : 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse');
 }
 else if(c==='status')say('POINT ZERO : LIBÉRÉ // ÎLE : RECONSTRUITE // CHAPITRE : 02 / SAISON : 01 // SIGNAL : ACTIF SOUS FREAKY ZERO');
 else if(c==='files')say('Fichiers : fragment_005 à fragment_020. Dossier temporel : KAEL. Signal : FREAKY ZERO. Dossier verrouillé détecté : J.DERIMIGHT.');
 else if(c==='clear'){history.length=0;paint();}
 else if(c.startsWith('unlock ')){const code=c.slice(7).trim();if(code==='286265'||code==='origine286'){say('CODE ACCEPTÉ. IDENTITÉS CONFIRMÉES : JEAN / BEN. DOSSIER SOURCE DÉVERROUILLÉ.');say('Avertissement : ce dossier contient des souvenirs effacés et une chronologie complète.');link('OUVRIR LE DOSSIER SECRET — LE PASSÉ DE JEAN ET BEN','secret-origines.html');}else if(code==='l0op-268'){try{sessionStorage.setItem('fz_jennifer_unlocked','1');}catch(_){}say('CODE ACCEPTÉ. SIGNATURE IDENTIFIÉE : LOOPING. DOSSIER PERSONNEL : JENNIFER DERIMIGHT.');say('Accès temporaire accordé. Certaines données restent classifiées.');link('OUVRIR LE DOSSIER PERSONNEL — JENNIFER DERIMIGHT','dossier-jennifer.html');}else if(secrets[code])say(secrets[code],false,'ACCÈS AUTORISÉ —');else say('CODE INVALIDE. Accès refusé.');}
 else say('Commande inconnue. Tape help.');input.value='';});
document.addEventListener('fz:language',paint);
