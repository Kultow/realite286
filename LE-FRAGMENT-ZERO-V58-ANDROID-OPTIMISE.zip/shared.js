/* ============================================================
   LE FRAGMENT ZÉRO — NOYAU PARTAGÉ
   Navigation, écran de connexion, effets de réalité et moteur
   de traduction natif (fr, en, es, it, ca, ar).
   Aucun service externe : les textes viennent de i18n-data.js.
   ============================================================ */
(() => {
  'use strict';

  const root = document.documentElement;
  const reduced = !!((window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) || (() => { try { return localStorage.getItem('fz44_less') === '1'; } catch (_) { return false; } })());
  const current = (location.pathname.split('/').pop() || 'index.html').toLowerCase();

  /* ---------------------------------------------------------
     1. Traductions
     --------------------------------------------------------- */
  const DICT = (window.FZ_I18N && typeof window.FZ_I18N === 'object') ? window.FZ_I18N : {};
  const LANGS = ['fr', 'it', 'es', 'en'];
  const LANG_NAMES = { fr: 'French', en: 'English', es: 'Spanish', it: 'Italian' };
  const norm = (value) => String(value).replace(/\s+/g, ' ').trim();
  const reverse = { en: {}, es: {}, it: {} };

  Object.keys(DICT).forEach((fr) => {
    const entry = DICT[fr];
    if (!entry) return;
    Object.keys(reverse).forEach((code) => {
      const value = entry[code];
      if (value) {
        const key = norm(value);
        if (key && !reverse[code][key]) reverse[code][key] = fr;
      }
    });
  });

  let lang = 'fr';
  try {
    const stored = localStorage.getItem('fz_language');
    if (LANGS.includes(stored)) lang = stored;
  } catch (_) { /* stockage indisponible */ }
  let appliedLang = lang;

  const textOriginals = new WeakMap();
  const attrOriginals = new WeakMap();

  function t(french) {
    if (!french) return '';
    if (lang === 'fr') return french;
    const entry = DICT[norm(french)];
    return (entry && (entry[lang] || (lang === 'zh' && entry.en))) ? (entry[lang] || entry.en) : french;
  }

  function frenchSource(value) {
    const key = norm(value);
    if (!key) return null;
    if (Object.prototype.hasOwnProperty.call(DICT, key)) return key;
    const previous = reverse[appliedLang];
    if (previous && previous[key]) return previous[key];
    return null;
  }

  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION', 'CODE', 'PRE']);
  const SKIP_SELECTOR = '.fz-language-bar, .fz-floating-core, [data-no-i18n], [data-fz-html]';

  /* Éléments dont le texte contient du balisage (titres sur deux lignes).
     On traduit l'ensemble et on réinjecte le HTML traduit. */
  const htmlOriginals = new WeakMap();

  function applyHtmlElement(el) {
    let source = htmlOriginals.get(el);
    if (!source) {
      source = { html: el.innerHTML, key: norm(el.textContent) };
      htmlOriginals.set(el, source);
    }
    const key = el.getAttribute('data-fz-html') || source.key;
    const entry = DICT[key];
    const value = (lang !== 'fr' && entry && (entry[lang] || (lang === 'zh' && entry.en))) ? (entry[lang] || entry.en) : source.html;
    if (el.innerHTML !== value) el.innerHTML = value;
  }

  function translatable(node) {
    const parent = node.parentElement;
    if (!parent) return false;
    if (SKIP_TAGS.has(parent.tagName)) return false;
    if (parent.closest(SKIP_SELECTOR)) return false;
    return true;
  }

  function applyTextNode(node) {
    if (!translatable(node)) return;
    const raw = node.nodeValue;
    const key = norm(raw);
    if (!key) return;
    let fr = frenchSource(raw);
    if (!fr && textOriginals.has(node)) fr = textOriginals.get(node);
    if (!fr) return;
    textOriginals.set(node, fr);
    const value = lang === 'fr' ? fr : (DICT[fr] && (DICT[fr][lang] || (lang === 'zh' && DICT[fr].en))) || fr;
    if (value === key) { if (lang === 'ar' && /[A-Za-zÀ-ÿ]/.test(key) && !/[\u0600-\u06FF]/.test(key)) { node.parentElement?.setAttribute('dir', 'ltr'); node.parentElement?.setAttribute('lang', 'fr'); } return; }
    const lead = raw.match(/^\s*/)[0];
    const trail = raw.match(/\s*$/)[0];
    const next = lead + value + trail;
    if (node.nodeValue !== next) node.nodeValue = next;
    if (lang === 'ar' && /[\u0600-\u06FF]/.test(value)) { node.parentElement?.setAttribute('dir', 'rtl'); node.parentElement?.setAttribute('lang', 'ar'); } else if (lang === 'ar' && /[A-Za-zÀ-ÿ]/.test(value)) { node.parentElement?.setAttribute('dir', 'ltr'); node.parentElement?.setAttribute('lang', 'fr'); } else { node.parentElement?.removeAttribute('dir'); node.parentElement?.removeAttribute('lang'); }
  }

  const ATTRS = ['aria-label', 'title', 'alt', 'placeholder', 'data-text'];

  function applyAttribute(el, attr) {
    const value = el.getAttribute(attr);
    if (!value) return;
    let store = attrOriginals.get(el);
    if (!store) { store = {}; attrOriginals.set(el, store); }
    let fr = frenchSource(value);
    if (!fr && store[attr] !== undefined) fr = store[attr];
    if (!fr) return;
    store[attr] = fr;
    const next = lang === 'fr' ? fr : (DICT[fr] && (DICT[fr][lang] || (lang === 'zh' && DICT[fr].en))) || fr;
    if (el.getAttribute(attr) !== next) el.setAttribute(attr, next);
  }

  const applyAttributes = (scope) => {
    const list = scope.querySelectorAll ? scope.querySelectorAll('[aria-label],[title],[alt],[placeholder],[data-text]') : [];
    list.forEach((el) => ATTRS.forEach((attr) => {
      if (el.hasAttribute(attr)) applyAttribute(el, attr);
    }));
  };

  function applyTranslations(scope = document.body) {
    if (!scope) return;
    if (scope.querySelectorAll) scope.querySelectorAll('[data-fz-html]').forEach(applyHtmlElement);
    const walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) applyTextNode(walker.currentNode);
    applyAttributes(scope);

    if (scope === document.body) {
      const title = document.querySelector('title');
      if (title) {
        const fr = title.dataset.fzFr || title.textContent;
        if (!title.dataset.fzFr) title.dataset.fzFr = norm(fr);
        title.textContent = t(title.dataset.fzFr);
      }
      const meta = document.querySelector('meta[name="description"]');
      if (meta) {
        if (!meta.dataset.fzFr) meta.dataset.fzFr = meta.getAttribute('content') || '';
        meta.setAttribute('content', t(meta.dataset.fzFr));
      }
    }
  }

  function applyLanguage(code, persist = true) {
    if (!LANGS.includes(code)) code = 'fr';
    lang = code;
    root.lang = code;
    root.dir = code === 'ar' ? 'rtl' : 'ltr';
    document.body.classList.toggle('fz-arabic', code === 'ar');
    document.body.classList.toggle('fz-translated', code !== 'fr');
    applyTranslations(document.body);

    // Le sélecteur reste en anglais, lisible de gauche à droite.
    languageBar.lang = 'en';
    languageBar.dir = 'ltr';
    languageBar.style.direction = 'ltr';
    languageBar.style.textAlign = 'left';
    if (languageSelect) {
      languageSelect.value = code;
      languageSelect.lang = 'en';
      languageSelect.dir = 'ltr';
      Array.from(languageSelect.options).forEach((option) => {
        option.lang = 'en';
        option.dir = 'ltr';
        option.textContent = LANG_NAMES[option.value] || option.textContent;
      });
    }
    appliedLang = code;
    if (persist) {
      try { localStorage.setItem('fz_language', code); } catch (_) { /* ignore */ }
    }
    document.dispatchEvent(new CustomEvent('fz:language', { detail: { lang: code } }));
  }

  /* ---------------------------------------------------------
     2. Navigation
     --------------------------------------------------------- */
  const button = document.querySelector('.menu-toggle');
  const menu = document.querySelector('#site-navigation');

  const setMenu = (open) => {
    if (!button || !menu) return;
    button.setAttribute('aria-expanded', String(open));
    button.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
    menu.classList.toggle('open', open);
    menu.setAttribute('aria-hidden', String(!open));
    document.body.classList.toggle('menu-open', open);
  };

  if (button && menu) {
    setMenu(false);
    if (menu.contains(document.querySelector('a.active'))) setMenu(false);
    button.addEventListener('click', (event) => {
      event.preventDefault();
      setMenu(button.getAttribute('aria-expanded') !== 'true');
    });
    menu.addEventListener('click', (event) => {
      if (event.target.closest('a')) setMenu(false);
    });
    document.addEventListener('click', (event) => {
      if (!event.target.closest('.site-menu')) setMenu(false);
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && button.getAttribute('aria-expanded') === 'true') {
        setMenu(false);
        button.focus();
      }
    });
  }

  document.querySelectorAll('.site-navigation a').forEach((link) => {
    let target = (link.getAttribute('href') || '').split('#')[0].toLowerCase();
    if (!target) target = 'index.html';
    if (target === current) {
      link.classList.add('active');
      link.setAttribute('aria-current', 'page');
    }
  });

  /* ---------------------------------------------------------
     3. Sélecteur de langues
     --------------------------------------------------------- */
  const languageBar = document.createElement('div');
  languageBar.className = 'fz-language-bar';
  languageBar.setAttribute('role', 'group');
  languageBar.setAttribute('aria-label', 'Language');
  languageBar.innerHTML =
    '<label for="fz-language-select">LANGUAGE</label>' +
    '<select id="fz-language-select" aria-label="Select language" autocomplete="off">' +
    LANGS.map((code) => '<option value="' + code + '">' + LANG_NAMES[code] + '</option>').join('') +
    '</select>';
  const languageHost = document.getElementById('fz46-settings-host');
  if (languageHost) { languageHost.prepend(languageBar); languageBar.setAttribute('aria-label','Site language'); }
  // On all other pages, the selector remains detached: the saved choice is applied normally.
  const languageSelect = languageBar.querySelector('select');
  languageSelect.addEventListener('change', () => applyLanguage(languageSelect.value));

  /* V47 : ancien écran de connexion supprimé. Les transitions par thème restent actives. */

  /* ---------------------------------------------------------
     5. Corruption de réalité (légère et plafonnée)
     --------------------------------------------------------- */
  let level = 0;
  try {
    const previous = Number(sessionStorage.getItem('fz_corruption_level') || 0);
    const last = sessionStorage.getItem('fz_last_page');
    level = Math.min(4, Math.max(0, previous + (last && last !== current ? 1 : 0)));
    sessionStorage.setItem('fz_corruption_level', String(level));
    sessionStorage.setItem('fz_last_page', current);
  } catch (_) { level = 0; }
  root.dataset.corruption = String(level);
  root.style.setProperty('--corruption-level', String(level));

  const overlay = document.createElement('div');
  overlay.className = 'reality-corruption-overlay';
  overlay.setAttribute('aria-hidden', 'true');
  overlay.innerHTML = '<span></span><i></i><b>REALITY SIGNAL // 0X-265</b>';
  document.body.appendChild(overlay);

  if (!reduced) {
    let burstTimer;
    const burst = () => {
      if (document.hidden) return;
      document.body.classList.add('reality-burst');
      window.clearTimeout(burstTimer);
      burstTimer = window.setTimeout(() => document.body.classList.remove('reality-burst'), 200 + level * 30);
    };
    const first = window.setTimeout(burst, 8200);
    const interval = window.setInterval(() => {
      if (!document.hidden && Math.random() < (0.1 + level * 0.03)) burst();
    }, 12000);
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) document.body.classList.remove('reality-burst');
    });
    window.addEventListener('pagehide', () => {
      window.clearTimeout(first);
      window.clearTimeout(burstTimer);
      window.clearInterval(interval);
    }, { once: true });
  }

  /* ---------------------------------------------------------
     6. Noyau flottant
     --------------------------------------------------------- */
  const floatingCore = document.createElement('a');
  floatingCore.className = 'fz-floating-core';
  floatingCore.href = 'index.html';
  floatingCore.innerHTML = '<span class="fz-floating-orbit fz-floating-orbit-a"></span><span class="fz-floating-orbit fz-floating-orbit-b"></span><img src="assets/point-zero.gif" alt=""><span class="fz-floating-core-label"></span>';
  const coreLabel = floatingCore.querySelector('.fz-floating-core-label');
  const paintCore = () => {
    floatingCore.setAttribute('aria-label', t('Retour au Point Zéro'));
    coreLabel.textContent = t('POINT ZÉRO');
  };
  paintCore();
  document.addEventListener('fz:language', paintCore);
  document.body.appendChild(floatingCore);

  /* ---------------------------------------------------------
     7. Transitions de page
     --------------------------------------------------------- */
  // Navigation transitions are managed exclusively by v44.js.


  /* ---------------------------------------------------------
     8. Contenus injectés par JavaScript
     --------------------------------------------------------- */
  let applying = false;
  const observer = new MutationObserver((records) => {
    if (applying || lang === 'fr') return;
    applying = true;
    try {
      records.forEach((record) => {
        if (record.type === 'characterData') {
          applyTextNode(record.target);
        } else {
          record.addedNodes.forEach((node) => {
            if (node.nodeType === Node.TEXT_NODE) applyTextNode(node);
            else if (node.nodeType === Node.ELEMENT_NODE) {
              const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
              while (walker.nextNode()) applyTextNode(walker.currentNode);
              applyAttributes(node);
            }
          });
        }
      });
    } finally {
      applying = false;
    }
  });
  observer.observe(document.body, { childList: true, characterData: true, subtree: true });

  /* ---------------------------------------------------------
     9. Démarrage
     --------------------------------------------------------- */
  applyLanguage(lang, false);
  applyTranslations(document.body);
  document.body.classList.add('page-ready');

  window.FZ = {
    get lang() { return lang; },
    get languages() { return LANGS.slice(); },
    t,
    setLang: (code) => applyLanguage(code),
    refresh: (scope) => { applyTranslations(scope || document.body); },
    reapply: () => applyTranslations(document.body)
  };
})();
