(()=>{'use strict';function init(){
 const menu=document.getElementById('fz43-sidebar'),toggle=document.getElementById('fz43-menu-toggle');
 if(menu&&toggle){toggle.setAttribute('aria-controls','fz43-sidebar');toggle.setAttribute('aria-expanded',document.body.classList.contains('fz43-menu-open')?'true':'false');
 const obs=new MutationObserver(()=>toggle.setAttribute('aria-expanded',document.body.classList.contains('fz43-menu-open')?'true':'false'));obs.observe(document.body,{attributes:true,attributeFilter:['class']});
 menu.querySelectorAll('a[href]').forEach(a=>a.addEventListener('click',()=>{if(innerWidth<=960)document.body.classList.remove('fz43-menu-open')}));
 document.addEventListener('keydown',e=>{if(e.key==='Escape')document.body.classList.remove('fz43-menu-open')});
 }
 document.querySelectorAll('img').forEach((img,i)=>{img.decoding='async';if(i>1&&!img.hasAttribute('loading'))img.loading='lazy'});
 document.querySelectorAll('iframe').forEach(frame=>{if(!frame.hasAttribute('loading'))frame.loading='lazy'});
 document.querySelectorAll('a[target="_blank"]').forEach(a=>{try{const u=new URL(a.href,location.href);if(u.origin===location.origin)a.removeAttribute('target')}catch{}});
 }if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();})();