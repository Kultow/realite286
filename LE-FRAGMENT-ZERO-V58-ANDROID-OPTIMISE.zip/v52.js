(()=>{'use strict';
function init(){
 const root=document.documentElement;
 const allowed=['zero','hacker','institute','guard'];
 if(!allowed.includes(root.dataset.fzTheme)){root.dataset.fzTheme='zero';try{localStorage.setItem('fz44_theme','zero')}catch{}}
 const select=document.getElementById('fz44-theme');if(select){[...select.options].forEach(o=>{if(!allowed.includes(o.value))o.remove()});if(!allowed.includes(select.value))select.value='zero';}
 const host=document.getElementById('fz46-settings-host');if(!host)return;
 const controls=host.querySelector('.fz44-controls');const bar=host.querySelector('.fz-language-bar');
 const layout=document.querySelector('.fz46-settings-layout');
 if(!layout)return;
 if(controls){controls.classList.add('fz52-theme-card');const h=document.createElement('h2');h.className='fz52-card-title';h.textContent='Thèmes et animations';controls.prepend(h)}
 if(bar){const card=document.createElement('section');card.className='fz52-language-card';card.id='langues';const h=document.createElement('h2');h.className='fz52-card-title';h.textContent='Langues';card.append(h,bar);layout.insertAdjacentElement('afterend',card)}
 const emblem=document.querySelector('.fz51-theme-emblem');if(emblem){const parent=emblem.parentElement;if(parent){parent.classList.add('fz52-institute-note');layout.insertAdjacentElement('afterend',parent)}}
 const preview=layout.querySelector('.fz46-preview');if(preview)preview.classList.add('fz52-preview-card');
 const panel=controls?.querySelector('.fz44-panel');if(panel){const themeLabel=panel.querySelector('#fz44-theme-label');if(themeLabel)themeLabel.classList.add('fz52-section-label');const reduceLabel=panel.querySelector('.fz44-reduce');if(reduceLabel)reduceLabel.classList.add('fz52-reduce-row')}
 const heading=document.querySelector('.fz52-theme-card .fz52-card-title');const langHeading=document.querySelector('.fz52-language-card .fz52-card-title');
 const titles={fr:['Thèmes et animations','Langues'],en:['Themes and animations','Languages'],it:['Temi e animazioni','Lingue'],es:['Temas y animaciones','Idiomas']};
 function paint(){let l='fr';try{l=localStorage.getItem('fz_language')||'fr'}catch{}const t=titles[l]||titles.fr;if(heading)heading.textContent=t[0];if(langHeading)langHeading.textContent=t[1]}
 document.addEventListener('fz:language',paint);paint();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
