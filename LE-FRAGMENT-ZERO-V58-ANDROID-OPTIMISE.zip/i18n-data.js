window.FZ_I18N = {
 "??? — Transmission inconnue": {
  "en": "??? — Unknown transmission",
  "es": "??? — Transmisión desconocida",
  "it": "??? — Trasmissione sconosciuta",
  "ca": "??? — Transmissió desconeguda",
  "ar": "؟؟؟ — بث مجهول"
 },
 ". Codes classés : 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse": {
  "en": ". Classified codes: 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse",
  "es": ". Códigos clasificados: 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse",
  "it": ". Codici classificati: 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse",
  "ca": ". Codis classificats: 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse",
  "ar": ". رموز مصنَّفة: 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse"
 },
 ". Kael et Jean ont autrefois été des amis proches. Une dispute ancienne a mis fin à leur amitié. Les archives ne précisent pas ce qui s'est passé.": {
  "en": ". Kael and Jean were once close friends. An old dispute ended their friendship. The archives do not specify what happened.",
  "es": ". Kael y Jean fueron en otro tiempo amigos cercanos. Una antigua disputa puso fin a su amistad. Los archivos no precisan qué ocurrió.",
  "it": ". Kael e Jean erano un tempo amici stretti. Un'antica lite pose fine alla loro amicizia. Gli archivi non precisano ciò che è accaduto.",
  "ca": ". En Kael i en Jean van ser un temps amics propers. Una disputa antiga va posar fi a la seva amistat. Els arxius no concreten què va passar.",
  "ar": ". كان كايل وجان صديقين مقرَّبين في الماضي. أنهى خلاف قديم صداقتهما. لا توضّح الأرشيفات ما حدث."
 },
 ". Olie et Kael se connaissent déjà grâce à une aventure vécue ensemble. Son contenu n'a pas encore été ajouté aux archives.": {
  "en": ". Olie and Kael already know each other thanks to an adventure lived together. Its content has not yet been added to the archives.",
  "es": ". Olie y Kael ya se conocen gracias a una aventura vivida juntos. Su contenido aún no se ha añadido a los archivos.",
  "it": ". Olie e Kael si conoscono già grazie a un'avventura vissuta insieme. Il suo contenuto non è ancora stato aggiunto agli archivi.",
  "ca": ". L'Olie i en Kael ja es coneixen gràcies a una aventura viscuda junts. El seu contingut encara no s'ha afegit als arxius.",
  "ar": ". أولي وكايل يعرفان بعضهما مسبقًا بفضل مغامرة عاشاها معًا. لم يُضف مضمونها بعد إلى الأرشيف."
 },
 ". Pour lire les fragments cachés, utilise la commande": {
  "en": ". To read the hidden fragments, use the command",
  "es": ". Para leer los fragmentos ocultos, usa el comando",
  "it": ". Per leggere i frammenti nascosti, usa il comando",
  "ca": ". Per llegir els fragments ocults, fes servir la comanda",
  "ar": ". لقراءة الشظايا المخفية، استخدم الأمر"
 },
 ". Un individu identifié sous le nom de KAEL est arrivé sur l'île grâce à une machine temporelle. Son origine exacte reste inconnue.": {
  "en": ". An individual identified as KAEL arrived on the island by time machine. His exact origin remains unknown.",
  "es": ". Un individuo identificado como KAEL llegó a la isla mediante una máquina del tiempo. Su origen exacto sigue siendo desconocido.",
  "it": ". Un individuo identificato come KAEL è arrivato sull'isola con una macchina del tempo. La sua origine esatta resta sconosciuta.",
  "ca": ". Un individu identificat com a KAEL va arribar a l'illa amb una màquina del temps. El seu origen exacte continua sent desconegut.",
  "ar": ". وصل فرد يُعرَف باسم KAEL إلى الجزيرة بآلة زمن. أصله الدقيق لا يزال مجهولًا."
 },
 ". Une partie du système d'Aidan répond encore, mais l'identité de la présence reste incertaine.": {
  "en": ". Part of Aidan's system still responds, but the identity of the presence remains uncertain.",
  "es": ". Una parte del sistema de Aidan sigue respondiendo, pero la identidad de la presencia sigue siendo incierta.",
  "it": ". Una parte del sistema di Aidan risponde ancora, ma l'identità della presenza resta incerta.",
  "ca": ". Una part del sistema de l'Aidan encara respon, però la identitat de la presència continua sent incerta.",
  "ar": ". جزء من نظام أيدن لا يزال يستجيب، لكن هوية الحضور لا تزال غير مؤكدة."
 },
 ". Une silhouette ressemblant à Jean a été détectée dans la faille. La date de l'enregistrement est incohérente.": {
  "en": ". A figure resembling Jean was detected in the rift. The date of the recording is inconsistent.",
  "es": ". Se ha detectado una silueta parecida a Jean en la falla. La fecha de la grabación es incoherente.",
  "it": ". È stata rilevata una sagoma simile a Jean nella faglia. La data della registrazione è incoerente.",
  "ca": ". S'ha detectat una silueta semblant a en Jean a l'escletxa. La data de l'enregistrament és incoherent.",
  "ar": ". رُصد ظلٌّ يشبه جان في الصدع. تاريخ التسجيل غير متسق."
 },
 ". Une transmission portant la signature d'Aidan a été détectée dans la faille.": {
  "en": ". A transmission bearing Aidan's signature was detected in the rift.",
  "es": ". Se ha detectado una transmisión con la firma de Aidan en la falla.",
  "it": ". È stata rilevata una trasmissione con la firma di Aidan nella faglia.",
  "ca": ". S'ha detectat una transmissió amb la signatura de l'Aidan a l'escletxa.",
  "ar": ". رُصد بثٌّ يحمل توقيع أيدن في الصدع."
 },
 "· TRANSMISSION NON AUTORISÉE": {
  "en": "· UNAUTHORISED TRANSMISSION",
  "es": "· TRANSMISIÓN NO AUTORIZADA",
  "it": "· TRASMISSIONE NON AUTORIZZATA",
  "ca": "· TRANSMISSIÓ NO AUTORITZADA",
  "ar": "· بث غير مصرَّح به"
 },
 "« …Enfin. Le signal passe. »": {
  "en": "« …Finally. The signal is coming through. »",
  "es": "« …Por fin. La señal pasa. »",
  "it": "« …Finalmente. Il segnale passa. »",
  "ca": "« …Per fi. El senyal passa. »",
  "ar": "«…أخيرًا. الإشارة تمر.»"
 },
 "« Alors on ne touche à rien avant de savoir ce qui répond. »": {
  "en": "« Then we touch nothing until we know what is answering. »",
  "es": "« Entonces no tocamos nada hasta saber qué responde. »",
  "it": "« Allora non tocchiamo nulla prima di sapere cosa risponde. »",
  "ca": "« Llavors no toquem res fins a saber què respon. »",
  "ar": "«إذًا لا نلمس شيئًا حتى نعرف ما الذي يجيب.»"
 },
 "« Ben croit peut-être qu'il peut réparer ce qui a été brisé. Il a toujours eu cette façon de regarder les ruines comme si quelque chose pouvait encore y pousser. Je ne lui en veux pas. C'est ce qui le rend dangereux… et c'est aussi ce qui me fait hésiter. »": {
  "en": "« Ben may believe he can repair what was broken. He always had that way of looking at ruins as if something could still grow there. I do not blame him. It is what makes him dangerous… and it is also what makes me hesitate. »",
  "es": "« Ben quizá crea que puede reparar lo que se rompió. Siempre tuvo esa forma de mirar las ruinas como si algo pudiera crecer aún allí. No se lo reprocho. Es lo que lo hace peligroso… y también lo que me hace dudar. »",
  "it": "« Ben forse crede di poter riparare ciò che è stato spezzato. Ha sempre avuto quel modo di guardare le rovine come se qualcosa potesse ancora crescervi. Non gliene voglio. È ciò che lo rende pericoloso… ed è anche ciò che mi fa esitare. »",
  "ca": "« En Ben potser creu que pot reparar el que s’ha trencat. Sempre ha tingut aquesta manera de mirar les ruïnes com si alguna cosa encara hi pogués créixer. No li’n vull. És el que el fa perillós… i també el que em fa dubtar. »",
  "ar": "«ربما يعتقد بن أنه قادر على إصلاح ما تحطَّم. لطالما نظر إلى الأطلال كأن شيئًا ما يمكن أن ينمو فيها بعد. لا ألومه. هذا ما يجعله خطيرًا… وهذا أيضًا ما يجعلني أتردد.»"
 },
 "« Ce n’est pas une faille. Quelque chose essaie de se synchroniser avec l’île. »": {
  "en": "« It is not a rift. Something is trying to synchronise with the island. »",
  "es": "« No es una falla. Algo intenta sincronizarse con la isla. »",
  "it": "« Non è una faglia. Qualcosa sta cercando di sincronizzarsi con l’isola. »",
  "ca": "« No és una escletxa. Alguna cosa intenta sincronitzar-se amb l’illa. »",
  "ar": "«إنه ليس صدعًا. شيء ما يحاول التزامن مع الجزيرة.»"
 },
 "« Dites-moi que vous voyez ça aussi. »": {
  "en": "« Tell me you see this too. »",
  "es": "« Decidme que vosotros también lo veis. »",
  "it": "« Ditemi che lo vedete anche voi. »",
  "ca": "« Digueu-me que vosaltres també ho veieu. »",
  "ar": "«قولوا لي إنكم ترون هذا أيضًا.»"
 },
 "« Je le vois. Et pour une fois, je préférerais vraiment ne pas comprendre comment ça fonctionne. »": {
  "en": "« I see it. And for once, I would really rather not understand how it works. »",
  "es": "« Lo veo. Y por una vez, preferiría de verdad no entender cómo funciona. »",
  "it": "« Lo vedo. E per una volta, preferirei davvero non capire come funziona. »",
  "ca": "« Ho veig. I per una vegada, preferiria de debò no entendre com funciona. »",
  "ar": "«أراه. ولمرة واحدة، أفضّل حقًّا ألا أفهم كيف يعمل.»"
 },
 "« Je ne peux pas vous dire où je suis. Chaque fois que je prononce le nom de cette réalité, le signal se déchire. Mais j'ai vu quelque chose au-delà de la faille. Quelque chose qui n'aurait jamais dû exister. »": {
  "en": "« I cannot tell you where I am. Every time I speak the name of this reality, the signal tears apart. But I saw something beyond the rift. Something that should never have existed. »",
  "es": "« No puedo deciros dónde estoy. Cada vez que pronuncio el nombre de esta realidad, la señal se desgarra. Pero he visto algo más allá de la falla. Algo que nunca debería haber existido. »",
  "it": "« Non posso dirvi dove sono. Ogni volta che pronuncio il nome di questa realtà, il segnale si lacera. Ma ho visto qualcosa oltre la faglia. Qualcosa che non sarebbe mai dovuto esistere. »",
  "ca": "« No us puc dir on sóc. Cada vegada que pronuncio el nom d’aquesta realitat, el senyal es desgarra. Però he vist alguna cosa més enllà de l’escletxa. Alguna cosa que no hauria d’haver existit mai. »",
  "ar": "«لا أستطيع أن أخبركم أين أنا. في كل مرة أنطق فيها اسم هذا الواقع، تتمزق الإشارة. لكنني رأيت شيئًا خلف الصدع. شيئًا ما كان يجب ألا يوجد قط.»"
 },
 "« Rien n'est terminé. Pas encore. »": {
  "en": "« Nothing is over. Not yet. »",
  "es": "« Nada ha terminado. Todavía no. »",
  "it": "« Niente è finito. Non ancora. »",
  "ca": "« Res no s’ha acabat. Encara no. »",
  "ar": "«لم ينتهِ شيء. ليس بعد.»"
 },
 "« Si le Point Zéro recommence à parler… ne lui répondez pas. »": {
  "en": "« If Point Zero starts speaking again… do not answer it. »",
  "es": "« Si el Punto Cero vuelve a hablar… no le respondáis. »",
  "it": "« Se il Punto Zero ricomincia a parlare… non rispondetegli. »",
  "ca": "« Si el Punt Zero torna a parlar… no li respongueu. »",
  "ar": "«إذا بدأت النقطة صفر تتكلم مجددًا… فلا تجيبوها.»"
 },
 "« Si tu lis ces lignes, c'est que j'ai réussi à trouver une fissure. Je ne sais pas combien de temps elle restera ouverte. Ici, le ciel n'a plus la même couleur. Les secondes se répètent parfois… et parfois, elles ne reviennent jamais. »": {
  "en": "« If you are reading this, it means I found a crack. I do not know how long it will stay open. Here, the sky is no longer the same colour. Seconds sometimes repeat… and sometimes they never come back. »",
  "es": "« Si lees estas líneas, es que he conseguido encontrar una grieta. No sé cuánto tiempo seguirá abierta. Aquí, el cielo ya no tiene el mismo color. Los segundos se repiten a veces… y a veces no vuelven nunca. »",
  "it": "« Se leggi queste righe, significa che sono riuscito a trovare una fessura. Non so quanto resterà aperta. Qui il cielo non ha più lo stesso colore. I secondi a volte si ripetono… e a volte non tornano mai. »",
  "ca": "« Si llegeixes aquestes línies, és que he aconseguit trobar una fissura. No sé quant de temps romandrà oberta. Aquí, el cel ja no té el mateix color. Els segons de vegades es repeteixen… i de vegades no tornen mai. »",
  "ar": "«إن كنت تقرأ هذه السطور، فذلك يعني أنني نجحت في إيجاد شق. لا أعرف كم سيبقى مفتوحًا. هنا، لم تعد السماء باللون نفسه. الثواني تتكرر أحيانًا… وأحيانًا لا تعود أبدًا.»"
 },
 "« Vous avez libéré le Point Zéro.": {
  "en": "« You freed Point Zero.",
  "es": "« Habéis liberado el Punto Cero.",
  "it": "« Avete liberato il Punto Zero.",
  "ca": "« Heu alliberat el Punt Zero.",
  "ar": "«لقد حرَّرتم النقطة صفر."
 },
 "« Vous avez libéré le Point Zéro. Mais vous n’avez jamais découvert ce qu’il retenait. »": {
  "en": "« You freed Point Zero. But you never discovered what it was holding back. »",
  "es": "« Habéis liberado el Punto Cero. Pero nunca descubristeis lo que retenía. »",
  "it": "« Avete liberato il Punto Zero. Ma non avete mai scoperto ciò che tratteneva. »",
  "ca": "« Heu alliberat el Punt Zero. Però mai no heu descobert què retenia. »",
  "ar": "«لقد حرَّرتم النقطة صفر. لكنكم لم تكتشفوا قط ما كان يحتجزه.»"
 },
 "« Vous me cherchez sûrement. Vous vous demandez si je suis mort, si je suis encore quelque part, si tout ça est terminé. »": {
  "en": "« You are surely looking for me. You wonder whether I am dead, whether I am still somewhere, whether all this is over. »",
  "es": "« Seguramente me buscáis. Os preguntáis si estoy muerto, si sigo en algún lugar, si todo esto ha terminado. »",
  "it": "« Mi state certamente cercando. Vi chiedete se sono morto, se sono ancora da qualche parte, se tutto questo è finito. »",
  "ca": "« Segurament em busqueu. Us pregunteu si sóc mort, si encara sóc en algun lloc, si tot això s’ha acabat. »",
  "ar": "«لا بد أنكم تبحثون عني. تتساءلون إن كنت ميتًا، وإن كنت ما زلت في مكان ما، وإن كان كل هذا قد انتهى.»"
 },
 "[ CLIQUE SUR LA CARTE POUR L’OUVRIR EN GRAND ]": {
  "en": "[ CLICK THE MAP TO OPEN IT FULL SIZE ]",
  "es": "[ HAZ CLIC EN EL MAPA PARA ABRIRLO EN GRANDE ]",
  "it": "[ CLICCA SULLA MAPPA PER APRIRLA A SCHERMO INTERO ]",
  "ca": "[ FES CLIC AL MAPA PER OBRIR-LO EN GRAN ]",
  "ar": "[ انقر على الخريطة لفتحها بالحجم الكامل ]"
 },
 "[ SÉLECTIONNE LA CARTE POUR L’AFFICHER EN GRAND ]": {
  "en": "[ SELECT THE MAP TO DISPLAY IT FULL SIZE ]",
  "es": "[ SELECCIONA EL MAPA PARA MOSTRARLO EN GRANDE ]",
  "it": "[ SELEZIONA LA MAPPA PER VISUALIZZARLA A SCHERMO INTERO ]",
  "ca": "[ SELECCIONA EL MAPA PER MOSTRAR-LO EN GRAN ]",
  "ar": "[ اختر الخريطة لعرضها بالحجم الكامل ]"
 },
 "[BRUIT NUMÉRIQUE] — SIGNAL PERDU — FIN DE TRANSMISSION ?": {
  "en": "[DIGITAL NOISE] — SIGNAL LOST — END OF TRANSMISSION ?",
  "es": "[RUIDO DIGITAL] — SEÑAL PERDIDA — ¿FIN DE LA TRANSMISIÓN ?",
  "it": "[RUMORE DIGITALE] — SEGNALE PERDUTO — FINE DELLA TRASMISSIONE ?",
  "ca": "[SOROLL DIGITAL] — SENYAL PERDUT — FI DE LA TRANSMISSIÓ ?",
  "ar": "[تشويش رقمي] — فُقدت الإشارة — نهاية البث؟"
 },
 "// Transmission entrante — source impossible à identifier": {
  "en": "// Incoming transmission — source impossible to identify",
  "es": "// Transmisión entrante — fuente imposible de identificar",
  "it": "// Trasmissione in arrivo — fonte impossibile da identificare",
  "ca": "// Transmissió entrant — font impossible d’identificar",
  "ar": "// بث وارد — مصدر يستحيل تحديده"
 },
 "#command": {
  "en": "#command",
  "es": "#command",
  "it": "#command",
  "ca": "#command",
  "ar": "#command"
 },
 "#output": {
  "en": "#output",
  "es": "#output",
  "it": "#output",
  "ca": "#output",
  "ar": "#output"
 },
 "#term-form": {
  "en": "#term-form",
  "es": "#term-form",
  "it": "#term-form",
  "ca": "#term-form",
  "ar": "#term-form"
 },
 "← Retour à l'accueil": {
  "en": "← Back to home",
  "es": "← Volver al inicio",
  "it": "← Torna alla home",
  "ca": "← Torna a l'inici",
  "ar": "← العودة إلى الرئيسية"
 },
 "↳ OUVRIR LE TERMINAL": {
  "en": "↳ OPEN THE TERMINAL",
  "es": "↳ ABRIR LA TERMINAL",
  "it": "↳ APRI IL TERMINALE",
  "ca": "↳ OBRE LA TERMINAL",
  "ar": "↳ افتح الطرفية"
 },
 "↻ TENTER DE RÉTABLIR LE SIGNAL": {
  "en": "↻ TRY TO RESTORE THE SIGNAL",
  "es": "↻ INTENTAR RESTABLECER LA SEÑAL",
  "it": "↻ PROVA A RIPRISTINARE IL SEGNALE",
  "ca": "↻ INTENTA RESTABLIR EL SENYAL",
  "ar": "↻ محاولة استعادة الإشارة"
 },
 "● LIVE": {
  "en": "● LIVE",
  "es": "● EN VIVO",
  "it": "● LIVE",
  "ca": "● EN DIRECTE",
  "ar": "● مباشر"
 },
 "✕ FERMER": {
  "en": "✕ CLOSE",
  "es": "✕ CERRAR",
  "it": "✕ CHIUDI",
  "ca": "✕ TANCA",
  "ar": "✕ إغلاق"
 },
 "001 · Le dernier avertissement": {
  "en": "001 · The last warning",
  "es": "001 · La última advertencia",
  "it": "001 · L'ultimo avvertimento",
  "ca": "001 · L'últim advertiment",
  "ar": "001 · التحذير الأخير"
 },
 "002 · Ce que Jean a sacrifié": {
  "en": "002 · What Jean sacrificed",
  "es": "002 · Lo que Jean sacrificó",
  "it": "002 · Ciò che Jean ha sacrificato",
  "ca": "002 · El que Jean va sacrificar",
  "ar": "002 · ما ضحّى به جان"
 },
 "003 · La voix d'Aidan": {
  "en": "003 · Aidan's voice",
  "es": "003 · La voz de Aidan",
  "it": "003 · La voce di Aidan",
  "ca": "003 · La veu d'Aidan",
  "ar": "003 · صوت أيدن"
 },
 "004 · Elle dit s’appeler Olie": {
  "en": "004 · She says her name is Olie",
  "es": "004 · Dice llamarse Olie",
  "it": "004 · Dice di chiamarsi Olie",
  "ca": "004 · Diu que es diu Olie",
  "ar": "004 · تقول إن اسمها أولي"
 },
 "01 / CHRONOLOGIE": {
  "en": "01 / TIMELINE",
  "es": "01 / CRONOLOGÍA",
  "it": "01 / CRONOLOGIA",
  "ca": "01 / CRONOLOGIA",
  "ar": "01 / التسلسل الزمني"
 },
 "01 / ÉVÉNEMENT EN COURS": {
  "en": "01 / ONGOING EVENT",
  "es": "01 / EVENTO EN CURSO",
  "it": "01 / EVENTO IN CORSO",
  "ca": "01 / ESDEVENIMENT EN CURS",
  "ar": "01 / حدث جارٍ"
 },
 "02 / CARTOGRAPHIE": {
  "en": "02 / CARTOGRAPHY",
  "es": "02 / CARTOGRAFÍA",
  "it": "02 / CARTOGRAFIA",
  "ca": "02 / CARTOGRAFIA",
  "ar": "02 / رسم الخرائط"
 },
 "02 / IDENTITÉS": {
  "en": "02 / IDENTITIES",
  "es": "02 / IDENTIDADES",
  "it": "02 / IDENTITÀ",
  "ca": "02 / IDENTITATS",
  "ar": "02 / الهويات"
 },
 "03 / ACCÈS AUX DOSSIERS": {
  "en": "03 / FILE ACCESS",
  "es": "03 / ACCESO A LOS ARCHIVOS",
  "it": "03 / ACCESSO AI FASCICOLI",
  "ca": "03 / ACCÉS ALS EXPEDIENTS",
  "ar": "03 / الوصول إلى الملفات"
 },
 "03 / ENREGISTREMENTS": {
  "en": "03 / RECORDINGS",
  "es": "03 / GRABACIONES",
  "it": "03 / REGISTRAZIONI",
  "ca": "03 / ENREGISTRAMENTS",
  "ar": "03 / التسجيلات"
 },
 "04 / DOCUMENTS": {
  "en": "04 / DOCUMENTS",
  "es": "04 / DOCUMENTOS",
  "it": "04 / DOCUMENTI",
  "ca": "04 / DOCUMENTS",
  "ar": "04 / الوثائق"
 },
 "05 / CLASSIFICATION": {
  "en": "05 / CLASSIFICATION",
  "es": "05 / CLASIFICACIÓN",
  "it": "05 / CLASSIFICAZIONE",
  "ca": "05 / CLASSIFICACIÓ",
  "ar": "05 / التصنيف"
 },
 "06 / SIGNAL": {
  "en": "06 / SIGNAL",
  "es": "06 / SEÑAL",
  "it": "06 / SEGNALE",
  "ca": "06 / SENYAL",
  "ar": "06 / الإشارة"
 },
 "07 / INTERFACE SYSTÈME": {
  "en": "07 / SYSTEM INTERFACE",
  "es": "07 / INTERFAZ DEL SISTEMA",
  "it": "07 / INTERFACCIA DI SISTEMA",
  "ca": "07 / INTERFÍCIE DEL SISTEMA",
  "ar": "07 / واجهة النظام"
 },
 "0X · 00 · 265": {
  "en": "0X · 00 · 265",
  "es": "0X · 00 · 265",
  "it": "0X · 00 · 265",
  "ca": "0X · 00 · 265",
  "ar": "0X · 00 · 265"
 },
 "ACCÉDER AUX SECRETS →": {
  "en": "ACCESS THE SECRETS →",
  "es": "ACCEDER A LOS SECRETOS →",
  "it": "ACCEDI AI SEGRETI →",
  "ca": "ACCEDEIX ALS SECRETS →",
  "ar": "الوصول إلى الأسرار →"
 },
 "ACCÈS AUTORISÉ —": {
  "en": "ACCESS GRANTED —",
  "es": "ACCESO AUTORIZADO —",
  "it": "ACCESSO AUTORIZZATO —",
  "ca": "ACCÉS AUTORITZAT —",
  "ar": "تم السماح بالوصول —"
 },
 "ACCÈS RESTREINT": {
  "en": "RESTRICTED ACCESS",
  "es": "ACCESO RESTRINGIDO",
  "it": "ACCESSO RISERVATO",
  "ca": "ACCÉS RESTRINGIT",
  "ar": "وصول مقيَّد"
 },
 "Accueil": {
  "en": "Home",
  "es": "Inicio",
  "it": "Home",
  "ca": "Inici",
  "ar": "الرئيسية",
  "zh": "首页"
 },
 "Aidan": {
  "en": "Aidan",
  "es": "Aidan",
  "it": "Aidan",
  "ca": "Aidan",
  "ar": "أيدن"
 },
 "Aidan a disparu pendant l'effondrement du Point Zéro. Aucun témoin ne peut confirmer ce qui lui est arrivé, mais des fragments de sa voix réapparaissent dans les systèmes endommagés. Les messages sont troublants : ils contiennent des souvenirs privés, des blagues que seul le groupe pouvait comprendre et des avertissements sur les plans de Jean.": {
  "en": "Aidan disappeared during the collapse of Point Zero. No witness can confirm what happened to him, but fragments of his voice reappear in damaged systems. The messages are disturbing: they contain private memories, jokes only the group could understand, and warnings about Jean's plans.",
  "es": "Aidan desapareció durante el colapso del Punto Cero. Ningún testigo puede confirmar lo que le ocurrió, pero fragmentos de su voz reaparecen en los sistemas dañados. Los mensajes son inquietantes: contienen recuerdos privados, bromas que solo el grupo podía entender y advertencias sobre los planes de Jean.",
  "it": "Aidan è scomparso durante il collasso del Punto Zero. Nessun testimone può confermare ciò che gli è accaduto, ma frammenti della sua voce riappaiono nei sistemi danneggiati. I messaggi sono inquietanti: contengono ricordi privati, battute che solo il gruppo poteva capire e avvertimenti sui piani di Jean.",
  "ca": "L'Aidan va desaparèixer durant el col·lapse del Punt Zero. Cap testimoni no pot confirmar què li va passar, però fragments de la seva veu reapareixen en els sistemes malmesos. Els missatges són inquietants: contenen records privats, acudits que només el grup podia entendre i advertiments sobre els plans d'en Jean.",
  "ar": "اختفى أيدن أثناء انهيار النقطة صفر. لا يستطيع أي شاهد تأكيد ما جرى له، لكن أجزاءً من صوته تعود للظهور في الأنظمة المتضررة. الرسائل مقلقة: تحتوي على ذكريات خاصة، ونكات لا يفهمها سوى المجموعة، وتحذيرات بشأن خطط جان."
 },
 "Aidan a disparu pendant l'effondrement du Point Zéro. Aucun témoin ne peut confirmer ce qui lui est arrivé, mais des fragments de sa voix réapparaissent dans les systèmes endommagés. Les…": {
  "en": "Aidan disappeared during the collapse of Point Zero. No witness can confirm what happened to him, but fragments of his voice reappear in damaged systems. The…",
  "es": "Aidan desapareció durante el colapso del Punto Cero. Ningún testigo puede confirmar lo que le ocurrió, pero fragmentos de su voz reaparecen en los sistemas dañados. Los…",
  "it": "Aidan è scomparso durante il collasso del Punto Zero. Nessun testimone può confermare ciò che gli è accaduto, ma frammenti della sua voce riappaiono nei sistemi danneggiati. I…",
  "ca": "L'Aidan va desaparèixer durant el col·lapse del Punt Zero. Cap testimoni no pot confirmar què li va passar, però fragments de la seva veu reapareixen en els sistemes malmesos. Els…",
  "ar": "اختفى أيدن أثناء انهيار النقطة صفر. لا يستطيع أي شاهد تأكيد ما جرى له، لكن أجزاءً من صوته تعود للظهور في الأنظمة المتضررة. الرسائل…"
 },
 "ALERTE : ACCÈS NON AUTORISÉ. VERROUILLAGE DE DECA DANS 60 SECONDES.": {
  "en": "ALERT: UNAUTHORISED ACCESS. DECA LOCKDOWN IN 60 SECONDS.",
  "es": "ALERTA: ACCESO NO AUTORIZADO. BLOQUEO DE DECA EN 60 SEGUNDOS.",
  "it": "ALLARME: ACCESSO NON AUTORIZZATO. BLOCCO DI DECA TRA 60 SECONDI.",
  "ca": "ALERTA: ACCÉS NO AUTORITZAT. BLOQUEIG DE DECA EN 60 SEGONS.",
  "ar": "تنبيه: وصول غير مصرَّح به. إغلاق DECA خلال 60 ثانية."
 },
 "ALLIÉE — ANALYSTE": {
  "en": "ALLY — ANALYST",
  "es": "ALIADA — ANALISTA",
  "it": "ALLEATA — ANALISTA",
  "ca": "ALIADA — ANALISTA",
  "ar": "حليفة — محلِّلة"
 },
 "Alors c'est un faux. Aidan est mort. Je l'ai vu.": {
  "en": "Then it is a fake. Aidan is dead. I saw it.",
  "es": "Entonces es falso. Aidan está muerto. Lo vi.",
  "it": "Allora è un falso. Aidan è morto. L'ho visto.",
  "ca": "Llavors és fals. L'Aidan és mort. Ho vaig veure.",
  "ar": "إذًا هو مزيف. أيدن ميت. لقد رأيته."
 },
 "Alors commence par nous dire où est Jean.": {
  "en": "Then start by telling us where Jean is.",
  "es": "Entonces empieza por decirnos dónde está Jean.",
  "it": "Allora comincia col dirci dov'è Jean.",
  "ca": "Llavors comença per dir-nos on és en Jean.",
  "ar": "إذًا ابدأ بإخبارنا أين جان."
 },
 "Alors dis-moi où est Aidan.": {
  "en": "Then tell me where Aidan is.",
  "es": "Entonces dime dónde está Aidan.",
  "it": "Allora dimmi dov'è Aidan.",
  "ca": "Llavors digues-me on és l'Aidan.",
  "ar": "إذًا أخبرني أين أيدن."
 },
 "Alors on copie tout. Les rapports, les noms, les ordres. On a besoin de preuves avant de sortir d'ici.": {
  "en": "Then we copy everything. Reports, names, orders. We need proof before we get out of here.",
  "es": "Entonces copiamos todo. Informes, nombres, órdenes. Necesitamos pruebas antes de salir de aquí.",
  "it": "Allora copiamo tutto. Rapporti, nomi, ordini. Ci servono prove prima di uscire di qui.",
  "ca": "Llavors ho copiem tot. Informes, noms, ordres. Necessitem proves abans de sortir d'aquí.",
  "ar": "إذًا ننسخ كل شيء. التقارير، والأسماء، والأوامر. نحتاج أدلة قبل أن نخرج من هنا."
 },
 "Alors on essaiera tous.": {
  "en": "Then we will all try.",
  "es": "Entonces lo intentaremos todos.",
  "it": "Allora proveremo tutti.",
  "ca": "Llavors ho intentarem tots.",
  "ar": "إذًا سنحاول جميعًا."
 },
 "Alors pourquoi es-tu là ? Qui t'envoie ?": {
  "en": "Then why are you here? Who sent you?",
  "es": "Entonces ¿por qué estás aquí? ¿Quién te envía?",
  "it": "Allora perché sei qui? Chi ti manda?",
  "ca": "Llavors per què ets aquí? Qui t'envia?",
  "ar": "إذًا لماذا أنت هنا؟ من أرسلك؟"
 },
 "Alors tu veux supprimer tous les choix ? Tu appelles ça la paix ?": {
  "en": "So you want to remove all choices? You call that peace?",
  "es": "¿Así que quieres eliminar todas las elecciones? ¿A eso lo llamas paz?",
  "it": "Quindi vuoi eliminare tutte le scelte? La chiami pace?",
  "ca": "Així que vols eliminar totes les eleccions? En dius pau, d'això?",
  "ar": "إذًا تريد محو كل الخيارات؟ وتسمّي ذلك سلامًا؟"
 },
 "ALYSS": {
  "en": "ALYSS",
  "es": "ALYSS",
  "it": "ALYSS",
  "ca": "ALYSS",
  "ar": "أليس"
 },
 "Alyss Derimight": {
  "en": "Alyss Derimight",
  "es": "Alyss Derimight",
  "it": "Alyss Derimight",
  "ca": "Alyss Derimight",
  "ar": "أليس ديرمايت"
 },
 "Alyss Derimight est le véritable nom de celui que les survivants appellent Le Vide. Après avoir provoqué des destructions et effacé des réalités, il semble désormais vouloir cesser le combat. Il ne demande pas qu'on oublie ses actes : il souhaite retrouver sa véritable forme et affronter ce qu'il a fait.": {
  "en": "Alyss Derimight is the true name of the one the survivors call the Void. After causing destruction and erasing realities, he now seems to want to stop fighting. He does not ask that his acts be forgotten: he wishes to recover his true form and face what he has done.",
  "es": "Alyss Derimight es el verdadero nombre de aquel a quien los supervivientes llaman el Vacío. Tras provocar destrucciones y borrar realidades, ahora parece querer poner fin al combate. No pide que se olviden sus actos: desea recuperar su verdadera forma y afrontar lo que ha hecho.",
  "it": "Alyss Derimight è il vero nome di colui che i sopravvissuti chiamano il Vuoto. Dopo aver causato distruzioni e cancellato realtà, ora sembra voler cessare il combattimento. Non chiede che i suoi atti vengano dimenticati: desidera ritrovare la sua vera forma e affrontare ciò che ha fatto.",
  "ca": "Alyss Derimight és el veritable nom d'aquell que els supervivents anomenen el Buit. Després de provocar destruccions i esborrar realitats, ara sembla voler aturar el combat. No demana que s'oblidin els seus actes: desitja recuperar la seva veritable forma i afrontar el que ha fet.",
  "ar": "أليس ديرمايت هو الاسم الحقيقي لمن يسمّيه الناجون الفراغ. بعد أن تسبّب في دمار ومحو أواقع، يبدو الآن أنه يريد وقف القتال. لا يطلب أن تُنسى أفعاله: بل يرغب في استعادة شكله الحقيقي ومواجهة ما فعله."
 },
 "Alyss Derimight…": {
  "en": "Alyss Derimight…",
  "es": "Alyss Derimight…",
  "it": "Alyss Derimight…",
  "ca": "Alyss Derimight…",
  "ar": "أليس ديرمايت…"
 },
 "Alyss… Tu avais dit que tu ne viendrais pas.": {
  "en": "Alyss… You said you would not come.",
  "es": "Alyss… Dijiste que no vendrías.",
  "it": "Alyss… Avevi detto che non saresti venuto.",
  "ca": "Alyss… Vas dir que no vindries.",
  "ar": "أليس… قلت إنك لن تأتي."
 },
 "ancien ami proche de Jean ; connaît Olie grâce à une aventure passée.": {
  "en": "former close friend of Jean; knows Olie through a past adventure.",
  "es": "antiguo amigo cercano de Jean; conoce a Olie por una aventura pasada.",
  "it": "ex amico stretto di Jean; conosce Olie grazie a un’avventura passata.",
  "ca": "antic amic proper d’en Jean; coneix l’Olie gràcies a una aventura passada.",
  "ar": "صديق مقرَّب سابق لجان؛ يعرف أولي عبر مغامرة ماضية."
 },
 "Ancien complexe fortifié au nord.": {
  "en": "Old fortified complex in the north.",
  "es": "Antiguo complejo fortificado al norte.",
  "it": "Vecchio complesso fortificato a nord.",
  "ca": "Antic complex fortificat al nord.",
  "ar": "مجمع محصَّن قديم في الشمال."
 },
 "Ancienne carte · Saison 8": {
  "en": "Old map · Season 8",
  "es": "Mapa antiguo · Temporada 8",
  "it": "Mappa precedente · Stagione 8",
  "ca": "Mapa antic · Temporada 8",
  "ar": "خريطة سابقة · الموسم 8"
 },
 "Après la libération du Point Zéro, l’île a retrouvé son équilibre. Cette version reste consultable comme archive historique.": {
  "en": "After the liberation of Point Zero, the island regained its balance. This version remains available as a historical archive.",
  "es": "Tras la liberación del Punto Cero, la isla recuperó su equilibrio. Esta versión sigue consultable como archivo histórico.",
  "it": "Dopo la liberazione del Punto Zero, l'isola ha ritrovato il suo equilibrio. Questa versione resta consultabile come archivio storico.",
  "ca": "Després de l'alliberament del Punt Zero, l'illa va recuperar el seu equilibri. Aquesta versió continua consultable com a arxiu històric.",
  "ar": "بعد تحرير النقطة صفر، استعادت الجزيرة توازنها. تبقى هذه النسخة متاحة كأرشيف تاريخي."
 },
 "Après la mort de Jean, le Point Zéro a été libéré de toute sa puissance et certaines villes corrompues ont été restaurées. Les débris et les limites visibles de la carte ne sont pas des signes de menace.": {
  "en": "After Jean's death, Point Zero was freed of all its power and some corrupted cities were restored. The debris and visible edges of the map are not signs of threat.",
  "es": "Tras la muerte de Jean, el Punto Cero quedó liberado de todo su poder y algunas ciudades corrompidas fueron restauradas. Los restos y los bordes visibles del mapa no son signos de amenaza.",
  "it": "Dopo la morte di Jean, il Punto Zero è stato liberato da tutta la sua potenza e alcune città corrotte sono state restaurate. I detriti e i bordi visibili della mappa non sono segni di minaccia.",
  "ca": "Després de la mort d'en Jean, el Punt Zero va quedar alliberat de tot el seu poder i algunes ciutats corruptes es van restaurar. Les restes i les vores visibles del mapa no són signes d'amenaça.",
  "ar": "بعد موت جان، تحرَّرت النقطة صفر من كل قوتها واستُعيدت بعض المدن الفاسدة. الحطام والحواف الظاهرة للخريطة ليست علامات تهديد."
 },
 "Archipel au sud, au milieu du lac.": {
  "en": "Archipelago to the south, in the middle of the lake.",
  "es": "Archipiélago al sur, en medio del lago.",
  "it": "Arcipelago a sud, in mezzo al lago.",
  "ca": "Arxipèlag al sud, al mig del llac.",
  "ar": "أرخبيل في الجنوب، وسط البحيرة."
 },
 "ARCHIVE 008": {
  "en": "ARCHIVE 008",
  "es": "ARCHIVO 008",
  "it": "ARCHIVIO 008",
  "ca": "ARXIU 008",
  "ar": "أرشيف 008"
 },
 "ARCHIVE 008 // TERRITOIRE RESTAURÉ": {
  "en": "ARCHIVE 008 // RESTORED TERRITORY",
  "es": "ARCHIVO 008 // TERRITORIO RESTAURADO",
  "it": "ARCHIVIO 008 // TERRITORIO RESTAURATO",
  "ca": "ARXIU 008 // TERRITORI RESTAURAT",
  "ar": "أرشيف 008 // إقليم مستعاد"
 },
 "ARCHIVE 01": {
  "en": "ARCHIVE 01",
  "es": "ARCHIVO 01",
  "it": "ARCHIVIO 01",
  "ca": "ARXIU 01",
  "ar": "أرشيف 01"
 },
 "ARCHIVE 02": {
  "en": "ARCHIVE 02",
  "es": "ARCHIVO 02",
  "it": "ARCHIVIO 02",
  "ca": "ARXIU 02",
  "ar": "أرشيف 02"
 },
 "ARCHIVE 03": {
  "en": "ARCHIVE 03",
  "es": "ARCHIVO 03",
  "it": "ARCHIVIO 03",
  "ca": "ARXIU 03",
  "ar": "أرشيف 03"
 },
 "ARCHIVE 04": {
  "en": "ARCHIVE 04",
  "es": "ARCHIVO 04",
  "it": "ARCHIVIO 04",
  "ca": "ARXIU 04",
  "ar": "أرشيف 04"
 },
 "ARCHIVE 05": {
  "en": "ARCHIVE 05",
  "es": "ARCHIVO 05",
  "it": "ARCHIVIO 05",
  "ca": "ARXIU 05",
  "ar": "أرشيف 05"
 },
 "ARCHIVE 06": {
  "en": "ARCHIVE 06",
  "es": "ARCHIVO 06",
  "it": "ARCHIVIO 06",
  "ca": "ARXIU 06",
  "ar": "أرشيف 06"
 },
 "ARCHIVE 07": {
  "en": "ARCHIVE 07",
  "es": "ARCHIVO 07",
  "it": "ARCHIVIO 07",
  "ca": "ARXIU 07",
  "ar": "أرشيف 07"
 },
 "ARCHIVE 08": {
  "en": "ARCHIVE 08",
  "es": "ARCHIVO 08",
  "it": "ARCHIVIO 08",
  "ca": "ARXIU 08",
  "ar": "أرشيف 08"
 },
 "ARCHIVE 09": {
  "en": "ARCHIVE 09",
  "es": "ARCHIVO 09",
  "it": "ARCHIVIO 09",
  "ca": "ARXIU 09",
  "ar": "أرشيف 09"
 },
 "ARCHIVE 10": {
  "en": "ARCHIVE 10",
  "es": "ARCHIVO 10",
  "it": "ARCHIVIO 10",
  "ca": "ARXIU 10",
  "ar": "أرشيف 10"
 },
 "ARCHIVE 11": {
  "en": "ARCHIVE 11",
  "es": "ARCHIVO 11",
  "it": "ARCHIVIO 11",
  "ca": "ARXIU 11",
  "ar": "أرشيف 11"
 },
 "ARCHIVE 12": {
  "en": "ARCHIVE 12",
  "es": "ARCHIVO 12",
  "it": "ARCHIVIO 12",
  "ca": "ARXIU 12",
  "ar": "أرشيف 12"
 },
 "ARCHIVE 13": {
  "en": "ARCHIVE 13",
  "es": "ARCHIVO 13",
  "it": "ARCHIVIO 13",
  "ca": "ARXIU 13",
  "ar": "أرشيف 13"
 },
 "ARCHIVE AUTOMATIQUE : FRAGMENT 0x-J // L'IDENTITÉ DE L'ÉMETTEUR N'EST PAS CERTIFIÉE.": {
  "en": "AUTO ARCHIVE: FRAGMENT 0x-J // SENDER IDENTITY NOT CERTIFIED.",
  "es": "ARCHIVO AUTOMÁTICO: FRAGMENTO 0x-J // LA IDENTIDAD DEL EMISOR NO ESTÁ CERTIFICADA.",
  "it": "ARCHIVIO AUTOMATICO: FRAMMENTO 0x-J // L’IDENTITÀ DEL MITTENTE NON È CERTIFICATA.",
  "ca": "ARXIU AUTOMÀTIC: FRAGMENT 0x-J // LA IDENTITAT DE L’EMISSOR NO ESTÀ CERTIFICADA.",
  "ar": "أرشيف تلقائي: الشظية 0x-J // هوية المرسِل غير موثَّقة."
 },
 "ARCHIVE HISTORIQUE — cette transmission a été enregistrée avant la mort de Jean, à la fin de la Saison 7.": {
  "en": "HISTORICAL ARCHIVE — this transmission was recorded before Jean’s death, at the end of Season 7.",
  "es": "ARCHIVO HISTÓRICO — esta transmisión se grabó antes de la muerte de Jean, al final de la Temporada 7.",
  "it": "ARCHIVIO STORICO — questa trasmissione è stata registrata prima della morte di Jean, alla fine della Stagione 7.",
  "ca": "ARXIU HISTÒRIC — aquesta transmissió es va enregistrar abans de la mort d’en Jean, al final de la Temporada 7.",
  "ar": "أرشيف تاريخي — سُجِّل هذا البث قبل موت جان، في نهاية الموسم 7."
 },
 "ARCHIVE S8 CONSULTABLE": {
  "en": "S8 ARCHIVE AVAILABLE",
  "es": "ARCHIVO T8 DISPONIBLE",
  "it": "ARCHIVIO S8 DISPONIBILE",
  "ca": "ARXIU T8 DISPONIBLE",
  "ar": "أرشيف الموسم 8 متاح"
 },
 "Archives": {
  "en": "Archives",
  "es": "Archivos",
  "it": "Archivi",
  "ca": "Arxius",
  "ar": "الأرشيف",
  "zh": "档案"
 },
 "Archives — L'Éclat du Point Zéro": {
  "en": "Archives — The Shard of Point Zero",
  "es": "Archivos — El Resplandor del Punto Cero",
  "it": "Archivi — Lo Splendore del Punto Zero",
  "ca": "Arxius — L'Esclat del Punt Zero",
  "ar": "الأرشيف — وهج النقطة صفر"
 },
 "ARCHIVES CARTOGRAPHIQUES": {
  "en": "CARTOGRAPHIC ARCHIVES",
  "es": "ARCHIVOS CARTOGRÁFICOS",
  "it": "ARCHIVI CARTOGRAFICI",
  "ca": "ARXIUS CARTOGRÀFICS",
  "ar": "أرشيفات خرائطية"
 },
 "Archives de l'univers du Fragment Zéro. Histoire, personnages, carte et transmissions de la Garde Zéro.": {
  "en": "Archives of the Zero Fragment universe. History, characters, map and transmissions of the Zero Guard.",
  "es": "Archivos del universo del Fragmento Cero. Historia, personajes, mapa y transmisiones de la Guardia Cero.",
  "it": "Archivi dell’universo del Frammento Zero. Storia, personaggi, mappa e trasmissioni della Guardia Zero.",
  "ca": "Arxius de l’univers del Fragment Zero. Història, personatges, mapa i transmissions de la Guàrdia Zero.",
  "ar": "أرشيفات عالم الجزء صفر. التاريخ والشخصيات والخريطة وبثّات حرس الصفر."
 },
 "Archives historiques et nouvelles pièces de la Saison 8. Les fragments 005 à 012 concernent les événements antérieurs ; les fragments 013 à 017 documentent la fin de Jean et l’arrivée de Kael.": {
  "en": "Historical archives and new pieces from Season 8. Fragments 005 to 012 concern earlier events; fragments 013 to 017 document Jean's end and Kael's arrival.",
  "es": "Archivos históricos y nuevas piezas de la Temporada 8. Los fragmentos 005 a 012 conciernen a acontecimientos anteriores; los fragmentos 013 a 017 documentan el final de Jean y la llegada de Kael.",
  "it": "Archivi storici e nuovi pezzi della Stagione 8. I frammenti da 005 a 012 riguardano eventi precedenti; i frammenti da 013 a 017 documentano la fine di Jean e l'arrivo di Kael.",
  "ca": "Arxius històrics i noves peces de la Temporada 8. Els fragments del 005 al 012 tracten d'esdeveniments anteriors; els fragments del 013 al 017 documenten el final d'en Jean i l'arribada d'en Kael.",
  "ar": "أرشيفات تاريخية وقطع جديدة من الموسم 8. تتعلق الشظايا 005 إلى 012 بأحداث سابقة؛ وتوثّق الشظايا 013 إلى 017 نهاية جان ووصول كايل."
 },
 "ARCHIVES RÉCUPÉRÉES": {
  "en": "RECOVERED ARCHIVES",
  "es": "ARCHIVOS RECUPERADOS",
  "it": "ARCHIVI RECUPERATI",
  "ca": "ARXIUS RECUPERATS",
  "ar": "أرشيفات مستعادة"
 },
 "Arrivé sur l'île reconstruite grâce à une machine temporelle, Kael connaît le Point Zéro. Il a été autrefois un ami proche de Jean, mais leur amitié s'est brisée après une dispute, il y a très longtemps…": {
  "en": "Arriving on the rebuilt island by time machine, Kael knows Point Zero. He was once a close friend of Jean, but their friendship broke after a dispute, a very long time ago…",
  "es": "Llegado a la isla reconstruida mediante una máquina del tiempo, Kael conoce el Punto Cero. Fue en otro tiempo un amigo cercano de Jean, pero su amistad se rompió tras una disputa, hace muchísimo tiempo…",
  "it": "Arrivato sull'isola ricostruita con una macchina del tempo, Kael conosce il Punto Zero. Fu un tempo un amico stretto di Jean, ma la loro amicizia si ruppe dopo una lite, molto tempo fa…",
  "ca": "Arribat a l'illa reconstruïda amb una màquina del temps, en Kael coneix el Punt Zero. Va ser un temps un amic proper d'en Jean, però la seva amistat es va trencar després d'una disputa, fa moltíssim temps…",
  "ar": "بعد وصوله إلى الجزيرة المُعاد بناؤها بآلة زمن، يعرف كايل النقطة صفر. كان في الماضي صديقًا مقرَّبًا لجان، لكن صداقتهما انكسرت بعد خلاف، منذ زمن بعيد جدًّا…"
 },
 "Attends… Pourquoi tu me regardes comme si tu me connaissais ?": {
  "en": "Wait… Why are you looking at me as if you know me?",
  "es": "Espera… ¿Por qué me miras como si me conocieras?",
  "it": "Aspetta… Perché mi guardi come se mi conoscessi?",
  "ca": "Espera… Per què em mires com si em coneguessis?",
  "ar": "انتظر… لماذا تنظرين إليّ كأنك تعرفينني؟"
 },
 "Au milieu des arbres bleutés, le sol s’illumine par cercles concentriques. Les feuilles se soulèvent sans vent. Une forme géométrique apparaît sous la terre, comme le contour d’une porte enfouie.": {
  "en": "Among the bluish trees, the ground lights up in concentric circles. Leaves lift without any wind. A geometric shape appears beneath the earth, like the outline of a buried door.",
  "es": "Entre los árboles azulados, el suelo se ilumina en círculos concéntricos. Las hojas se levantan sin viento. Una forma geométrica aparece bajo la tierra, como el contorno de una puerta enterrada.",
  "it": "Tra gli alberi bluastri, il suolo si illumina in cerchi concentrici. Le foglie si sollevano senza vento. Una forma geometrica appare sotto terra, come il contorno di una porta sepolta.",
  "ca": "Entre els arbres blavosos, el terra s’il·lumina en cercles concèntrics. Les fulles s’aixequen sense vent. Una forma geomètrica apareix sota la terra, com el contorn d’una porta enterrada.",
  "ar": "بين الأشجار المائلة إلى الزرقة، يضيء الأرض بدوائر متحدة المركز. ترتفع الأوراق دون ريح. ويظهر شكل هندسي تحت التراب، كحدود باب مدفون."
 },
 "avant le Vide": {
  "en": "before the Void",
  "es": "antes del Vacío",
  "it": "prima del Vuoto",
  "ca": "abans del Buit",
  "ar": "قبل الفراغ"
 },
 "Avant les îles, les armées et les Points Zéro, Jean n'était qu'un enfant qui voulait comprendre pourquoi le monde semblait toujours sur le point de se briser. Dans ses premiers souvenirs, il y avait une maison aux fenêtres bleues, une table trop petite pour tous les livres de son père et la voix de sa mère qui l'appelait lorsque la nuit tombait.": {
  "en": "Before the islands, the armies and the Points Zero, Jean was only a child who wanted to understand why the world always seemed about to break. In his earliest memories, there was a house with blue windows, a table too small for all his father's books, and his mother's voice calling him when night fell.",
  "es": "Antes de las islas, los ejércitos y los Puntos Cero, Jean no era más que un niño que quería entender por qué el mundo parecía siempre a punto de romperse. En sus primeros recuerdos había una casa de ventanas azules, una mesa demasiado pequeña para todos los libros de su padre y la voz de su madre llamándolo cuando caía la noche.",
  "it": "Prima delle isole, degli eserciti e dei Punti Zero, Jean era solo un bambino che voleva capire perché il mondo sembrasse sempre sul punto di spezzarsi. Nei suoi primi ricordi c'era una casa con le finestre blu, un tavolo troppo piccolo per tutti i libri di suo padre e la voce di sua madre che lo chiamava quando scendeva la notte.",
  "ca": "Abans de les illes, els exèrcits i els Punts Zero, en Jean no era més que un nen que volia entendre per què el món sempre semblava a punt de trencar-se. En els seus primers records hi havia una casa de finestres blaves, una taula massa petita per a tots els llibres del seu pare i la veu de la seva mare cridant-lo quan queia la nit.",
  "ar": "قبل الجزر والجيوش والنقاط صفر، لم يكن جان سوى طفل يريد أن يفهم لماذا يبدو العالم دائمًا على وشك الانكسار. في أولى ذكرياته، كان هناك بيت بنوافذ زرقاء، وطاولة أصغر من أن تتسع لكل كتب والده، وصوت والدته يناديه عند حلول الليل."
 },
 "Avant les réalités": {
  "en": "Before the realities",
  "es": "Antes de las realidades",
  "it": "Prima delle realtà",
  "ca": "Abans de les realitats",
  "ar": "قبل الأواقع"
 },
 "Avec Voss, ils forment le noyau de ce qui deviendra la Garde Zéro. À ce moment-là, Ben ne connaît pas le secret du Vide. Il ne sait pas non plus que le désir de paix de Jean est en train de se transformer en volonté de contrôle. Pour Ben, Jean est encore un allié — parfois difficile à comprendre, mais pas encore l'ennemi qu'il deviendra.": {
  "en": "With Voss, they form the core of what will become the Zero Guard. At that moment, Ben does not know the Void's secret. Nor does he know that Jean's desire for peace is turning into a will to control. For Ben, Jean is still an ally — sometimes hard to understand, but not yet the enemy he will become.",
  "es": "Con Voss, forman el núcleo de lo que será la Guardia Cero. En ese momento, Ben no conoce el secreto del Vacío. Tampoco sabe que el deseo de paz de Jean se está transformando en voluntad de control. Para Ben, Jean sigue siendo un aliado —a veces difícil de entender, pero todavía no el enemigo en que se convertirá.",
  "it": "Con Voss, formano il nucleo di ciò che diventerà la Guardia Zero. In quel momento, Ben non conosce il segreto del Vuoto. Non sa nemmeno che il desiderio di pace di Jean si sta trasformando in volontà di controllo. Per Ben, Jean è ancora un alleato — a volte difficile da capire, ma non ancora il nemico che diventerà.",
  "ca": "Amb en Voss, formen el nucli del que serà la Guàrdia Zero. En aquell moment, en Ben no coneix el secret del Buit. Tampoc no sap que el desig de pau d'en Jean s'està transformant en voluntat de control. Per a en Ben, en Jean encara és un aliat — de vegades difícil d'entendre, però encara no l'enemic en què es convertirà.",
  "ar": "مع فوس، يشكّلون نواة ما سيصبح حرس الصفر. في تلك اللحظة، لا يعرف بن سرّ الفراغ. ولا يعرف أيضًا أن رغبة جان في السلام تتحول إلى إرادة سيطرة. بالنسبة إلى بن، لا يزال جان حليفًا — صعب الفهم أحيانًا، لكنه ليس بعد العدو الذي سيصبحه."
 },
 "Avertissement : ce dossier contient des souvenirs effacés et une chronologie complète.": {
  "en": "Warning: this file contains erased memories and a complete timeline.",
  "es": "Advertencia: este expediente contiene recuerdos borrados y una cronología completa.",
  "it": "Avvertenza: questo fascicolo contiene ricordi cancellati e una cronologia completa.",
  "ca": "Advertiment: aquest expedient conté records esborrats i una cronologia completa.",
  "ar": "تحذير: هذا الملف يحتوي على ذكريات ممحاة وتسلسل زمني كامل."
 },
 "Base de Ben": {
  "en": "Ben's Base",
  "es": "Base de Ben",
  "it": "Base di Ben",
  "ca": "Base d'en Ben",
  "ar": "قاعدة بن"
 },
 "Base située au sud de l’île.": {
  "en": "Base located south of the island.",
  "es": "Base situada al sur de la isla.",
  "it": "Base situata a sud dell'isola.",
  "ca": "Base situada al sud de l'illa.",
  "ar": "قاعدة تقع جنوب الجزيرة."
 },
 "Base située sur la côte sud-est.": {
  "en": "Base located on the south-east coast.",
  "es": "Base situada en la costa sureste.",
  "it": "Base situata sulla costa sud-est.",
  "ca": "Base situada a la costa sud-est.",
  "ar": "قاعدة على الساحل الجنوبي الشرقي."
 },
 "Ben": {
  "en": "Ben",
  "es": "Ben",
  "it": "Ben",
  "ca": "Ben",
  "ar": "بن"
 },
 "BEN": {
  "en": "BEN",
  "es": "BEN",
  "it": "BEN",
  "ca": "BEN",
  "ar": "بن"
 },
 "BEN :": {
  "en": "BEN:",
  "es": "BEN:",
  "it": "BEN:",
  "ca": "BEN:",
  "ar": "بن:"
 },
 "Ben découvre que la réalité où tout commence vraiment, la Réalité 0, est en fait une île unique (après simplification de ce qui semblait être cinq îles distinctes), couvrant des lieux comme The Sanctuary, The Prison, l'Ancien Sanctuaire ou Reality Ross. C'est là que se trouve le dernier éclat manquant, à l'Ancien Sanctuaire.": {
  "en": "Ben discovers that the reality where everything truly begins, Reality 0, is in fact a single island (after simplifying what seemed to be five distinct islands), covering places such as The Sanctuary, The Prison, the Old Sanctuary and Reality Ross. That is where the last missing shard lies, at the Old Sanctuary.",
  "es": "Ben descubre que la realidad donde todo empieza de verdad, la Realidad 0, es en realidad una isla única (tras simplificar lo que parecían cinco islas distintas), que abarca lugares como The Sanctuary, The Prison, el Antiguo Santuario o Reality Ross. Allí se encuentra el último destello que falta, en el Antiguo Santuario.",
  "it": "Ben scopre che la realtà in cui tutto comincia davvero, la Realtà 0, è in realtà un’unica isola (dopo aver semplificato ciò che sembrava essere cinque isole distinte), che comprende luoghi come The Sanctuary, The Prison, l’Antico Santuario o Reality Ross. È lì che si trova l’ultimo frammento mancante, all’Antico Santuario.",
  "ca": "En Ben descobreix que la realitat on tot comença de debò, la Realitat 0, és en realitat una illa única (després de simplificar el que semblaven cinc illes diferents), que abasta llocs com The Sanctuary, The Prison, l’Antic Santuari o Reality Ross. És allà on es troba l’últim esclat que falta, a l’Antic Santuari.",
  "ar": "يكتشف بن أن الواقع الذي يبدأ فيه كل شيء حقًّا، الواقع 0، هو في الحقيقة جزيرة واحدة (بعد تبسيط ما بدا خمس جزر منفصلة)، وتضم أماكن مثل The Sanctuary وThe Prison والملاذ القديم وReality Ross. هناك يوجد الوميض الأخير المفقود، في الملاذ القديم."
 },
 "Ben est celui qui refuse de considérer les disparus comme de simples pertes nécessaires. Depuis l'effondrement du Point Zéro, il avance avec une idée fixe : retrouver Aidan et empêcher Jean de décider seul du destin de toutes les réalités. Il n'est pas un chef né, et il doute souvent de ses choix. Pourtant, quand tout le monde préfère détourner le regard, Ben continue de poser les questions qui dérangent.": {
  "en": "Ben is the one who refuses to consider the missing as mere necessary losses. Since the collapse of Point Zero, he moves forward with one fixed idea: to find Aidan and stop Jean from deciding alone the fate of all realities. He is not a born leader, and he often doubts his choices. Yet when everyone else prefers to look away, Ben keeps asking the questions that unsettle.",
  "es": "Ben es el que se niega a considerar a los desaparecidos como simples pérdidas necesarias. Desde el colapso del Punto Cero, avanza con una idea fija: encontrar a Aidan e impedir que Jean decida solo el destino de todas las realidades. No es un líder nato y a menudo duda de sus elecciones. Sin embargo, cuando todos prefieren apartar la mirada, Ben sigue haciendo las preguntas que incomodan.",
  "it": "Ben è colui che rifiuta di considerare i dispersi come semplici perdite necessarie. Dal collasso del Punto Zero, va avanti con un'idea fissa: ritrovare Aidan e impedire che Jean decida da solo il destino di tutte le realtà. Non è un leader nato e dubita spesso delle sue scelte. Eppure, quando tutti preferiscono distogliere lo sguardo, Ben continua a porre le domande che danno fastidio.",
  "ca": "En Ben és el qui es nega a considerar els desapareguts com a simples pèrdues necessàries. Des del col·lapse del Punt Zero, avança amb una idea fixa: retrobar l'Aidan i impedir que en Jean decideixi sol el destí de totes les realitats. No és un líder nat i sovint dubta de les seves eleccions. Tanmateix, quan tothom prefereix girar la mirada, en Ben continua fent les preguntes que incomoden.",
  "ar": "بن هو من يرفض اعتبار المفقودين مجرد خسائر ضرورية. منذ انهيار النقطة صفر، يمضي بفكرة ثابتة: إيجاد أيدن ومنع جان من تقرير مصير جميع الأواقع وحده. ليس قائدًا بالفطرة، وكثيرًا ما يشك في خياراته. ومع ذلك، حين يفضّل الجميع النظر في اتجاه آخر، يواصل بن طرح الأسئلة المزعجة."
 },
 "Ben est celui qui refuse de considérer les disparus comme de simples pertes nécessaires. Depuis l'effondrement du Point Zéro, il avance avec une idée fixe : retrouver Aidan et empêcher Jean…": {
  "en": "Ben is the one who refuses to consider the missing as mere necessary losses. Since the collapse of Point Zero, he moves forward with one fixed idea: find Aidan and stop Jean…",
  "es": "Ben es el que se niega a considerar a los desaparecidos como simples pérdidas necesarias. Desde el colapso del Punto Cero, avanza con una idea fija: encontrar a Aidan e impedir que Jean…",
  "it": "Ben è colui che rifiuta di considerare i dispersi come semplici perdite necessarie. Dal collasso del Punto Zero, va avanti con un'idea fissa: ritrovare Aidan e impedire a Jean…",
  "ca": "En Ben és el qui es nega a considerar els desapareguts com a simples pèrdues necessàries. Des del col·lapse del Punt Zero, avança amb una idea fixa: retrobar l'Aidan i impedir que en Jean…",
  "ar": "بن هو من يرفض اعتبار المفقودين مجرد خسائر ضرورية. منذ انهيار النقطة صفر، يمضي بفكرة ثابتة: إيجاد أيدن ومنع جان…"
 },
 "Ben fixe les relevés projetés au-dessus de la table. Les impulsions apparaissent, disparaissent, puis recommencent exactement au même intervalle.": {
  "en": "Ben stares at the readings projected above the table. The pulses appear, vanish, then start again at exactly the same interval.",
  "es": "Ben observa los registros proyectados sobre la mesa. Las pulsaciones aparecen, desaparecen y vuelven a empezar exactamente con el mismo intervalo.",
  "it": "Ben fissa le rilevazioni proiettate sopra il tavolo. Le pulsazioni appaiono, svaniscono e ricominciano esattamente con lo stesso intervallo.",
  "ca": "En Ben mira els registres projectats sobre la taula. Les pulsacions apareixen, desapareixen i tornen a començar exactament amb el mateix interval.",
  "ar": "يحدّق بن في القياسات المعروضة فوق الطاولة. تظهر النبضات، تختفي، ثم تعود من جديد بالفاصل نفسه تمامًا."
 },
 "Ben prévient le Docteur Voss en privé, en lui apportant des preuves irréfutables : des réponses qu'il ne pourrait connaître que venant du futur, et un enregistrement testamentaire d'Aidan. Voss révèle la vérité à Vanny et Ducky, mais décide de ne rien dire à Jean. Elle isole Aidan du réseau pour empêcher le virus de passer par lui, et prépare un portail vers une réalité cauchemardesque, d'abord pensé pour y envoyer l'éclat, puis réorienté pour y envoyer Jean lui-même.": {
  "en": "Ben warns Doctor Voss in private, bringing irrefutable proof: answers he could only know if he came from the future, and a testamentary recording from Aidan. Voss reveals the truth to Vanny and Ducky, but decides to say nothing to Jean. She isolates Aidan from the network to stop the virus passing through him, and prepares a portal to a nightmarish reality, first intended to send the shard through, then redirected to send Jean himself.",
  "es": "Ben advierte al doctor Voss en privado, aportando pruebas irrefutables: respuestas que solo podría conocer viniendo del futuro, y una grabación testamentaria de Aidan. Voss revela la verdad a Vanny y Ducky, pero decide no decir nada a Jean. Aísla a Aidan de la red para impedir que el virus pase por él, y prepara un portal hacia una realidad de pesadilla, pensado primero para enviar el destello y luego reorientado para enviar al propio Jean.",
  "it": "Ben avverte in privato il Dottor Voss, portando prove irrefutabili: risposte che potrebbe conoscere solo venendo dal futuro, e una registrazione testamentaria di Aidan. Voss rivela la verità a Vanny e Ducky, ma decide di non dire nulla a Jean. Isola Aidan dalla rete per impedire che il virus passi attraverso di lui, e prepara un portale verso una realtà da incubo, pensato prima per inviarvi il frammento, poi reindirizzato per inviarvi Jean stesso.",
  "ca": "En Ben adverteix el doctor Voss en privat, aportant proves irrefutables: respostes que només podria conèixer venint del futur, i un enregistrament testamentari d’Aidan. En Voss revela la veritat a en Vanny i en Ducky, però decideix no dir res a en Jean. Aïlla Aidan de la xarxa per impedir que el virus hi passi a través, i prepara un portal cap a una realitat de malson, pensat primer per enviar-hi l’esclat i després reorientat per enviar-hi el mateix Jean.",
  "ar": "يحذّر بن الدكتور فوس على انفراد، حاملًا أدلة دامغة: إجابات لا يمكن أن يعرفها إلا قادمًا من المستقبل، وتسجيلًا وصيًّا من أيدن. تكشف فوس الحقيقة لفاني ودكي، لكنها تقرر ألا تقول شيئًا لجان. تعزل أيدن عن الشبكة لمنع الفيروس من المرور عبره، وتُعدّ بوابة إلى واقع كابوسي، كان مخططًا أولًا لإرسال الوميض عبرها، ثم أُعيد توجيهها لإرسال جان نفسه."
 },
 "Ben, au contraire, voyait ses parents reconnaître leurs erreurs et se réconcilier. Cela ne rendait pas leur vie parfaite. Cela lui apprenait que la paix se construisait, qu'elle ne pouvait pas être imposée une fois pour toutes. Cette différence entre eux deviendrait, plus tard, le cœur de leur opposition.": {
  "en": "Ben, by contrast, saw his parents acknowledge their mistakes and reconcile. That did not make their life perfect. It taught him that peace had to be built, that it could not be imposed once and for all. That difference between them would later become the heart of their opposition.",
  "es": "Ben, en cambio, vio a sus padres reconocer sus errores y reconciliarse. Eso no hacía perfecta su vida. Le enseñaba que la paz se construye, que no puede imponerse de una vez por todas. Esa diferencia entre ellos se convertiría más tarde en el corazón de su oposición.",
  "it": "Ben, al contrario, vedeva i suoi genitori riconoscere i propri errori e riconciliarsi. Questo non rendeva perfetta la loro vita. Gli insegnava che la pace si costruisce, che non può essere imposta una volta per tutte. Quella differenza tra loro sarebbe diventata, più tardi, il cuore della loro contrapposizione.",
  "ca": "En Ben, en canvi, veia els seus pares reconèixer els seus errors i reconciliar-se. Això no feia perfecta la seva vida. Li ensenyava que la pau es construeix, que no es pot imposar d'una vegada per sempre. Aquesta diferència entre ells es convertiria més tard en el cor de la seva oposició.",
  "ar": "أما بن، فرأى والديه يعترفان بأخطائهما ويتصالحان. لم يجعل ذلك حياتهما مثالية. لكنه علّمه أن السلام يُبنى، ولا يمكن فرضه مرة واحدة وإلى الأبد. وسيصبح ذلك الفارق بينهما لاحقًا جوهر تعارضهما."
 },
 "Ben, lui, venait d'une autre réalité. Dans la Réalité 286, ses parents étaient eux aussi vivants. Leur maison était plus modeste, mais on y riait souvent. Ben avait appris à réparer les objets cassés avec sa famille : pas toujours parfaitement, mais assez pour leur donner une seconde chance. Il croyait qu'une chose abîmée n'était pas forcément une chose perdue.": {
  "en": "Ben came from another reality. In Reality 286, his parents were alive too. Their house was more modest, but laughter was frequent there. Ben had learned to repair broken objects with his family: not always perfectly, but enough to give them a second chance. He believed that a damaged thing was not necessarily a lost thing.",
  "es": "Ben venía de otra realidad. En la Realidad 286, sus padres también estaban vivos. Su casa era más modesta, pero en ella se reía a menudo. Ben había aprendido a reparar objetos rotos con su familia: no siempre perfectamente, pero lo suficiente para darles una segunda oportunidad. Creía que una cosa dañada no era forzosamente una cosa perdida.",
  "it": "Ben veniva da un'altra realtà. Nella Realtà 286, anche i suoi genitori erano vivi. La loro casa era più modesta, ma vi si rideva spesso. Ben aveva imparato a riparare oggetti rotti con la sua famiglia: non sempre perfettamente, ma abbastanza per dare loro una seconda possibilità. Credeva che una cosa danneggiata non fosse necessariamente una cosa perduta.",
  "ca": "En Ben venia d'una altra realitat. A la Realitat 286, els seus pares també eren vius. La seva casa era més modesta, però hi reien sovint. En Ben havia après a reparar objectes trencats amb la seva família: no sempre perfectament, però prou per donar-los una segona oportunitat. Creia que una cosa malmesa no era forçosament una cosa perduda.",
  "ar": "أما بن، فجاء من واقع آخر. في الواقع 286، كان والداه أيضًا على قيد الحياة. كان بيتهما أكثر تواضعًا، لكن الضحك كان كثيرًا فيه. تعلّم بن إصلاح الأشياء المكسورة مع عائلته: لا دائمًا بإتقان، لكن بما يكفي لمنحها فرصة ثانية. كان يؤمن أن الشيء التالف ليس بالضرورة شيئًا مفقودًا."
 },
 "Ben, on doit bouger. Maintenant !": {
  "en": "Ben, we have to move. Now!",
  "es": "Ben, tenemos que movernos. ¡Ahora!",
  "it": "Ben, dobbiamo muoverci. Ora!",
  "ca": "Ben, ens hem de moure. Ara!",
  "ar": "بن، علينا التحرك. الآن!"
 },
 "Ben, protagoniste de cette histoire, vient de la Réalité 286 et est bien vivant. Il ne faut pas le confondre avec le frère de Jean, mort en Réalité 265.": {
  "en": "Ben, the protagonist of this story, comes from Reality 286 and is very much alive. He must not be confused with Jean's brother, who died in Reality 265.",
  "es": "Ben, protagonista de esta historia, viene de la Realidad 286 y está muy vivo. No debe confundirse con el hermano de Jean, muerto en la Realidad 265.",
  "it": "Ben, protagonista di questa storia, viene dalla Realtà 286 ed è vivo e vegeto. Non va confuso con il fratello di Jean, morto nella Realtà 265.",
  "ca": "En Ben, protagonista d’aquesta història, ve de la Realitat 286 i és ben viu. No s’ha de confondre amb el germà d’en Jean, mort a la Realitat 265.",
  "ar": "بن، بطل هذه القصة، يأتي من الواقع 286 وهو على قيد الحياة. لا يجب الخلط بينه وبين شقيق جان، الذي مات في الواقع 265."
 },
 "Ben… si tu entends ceci, ne viens pas me chercher.": {
  "en": "Ben… if you hear this, do not come looking for me.",
  "es": "Ben… si oyes esto, no vengas a buscarme.",
  "it": "Ben… se senti questo, non venire a cercarmi.",
  "ca": "Ben… si sents això, no vinguis a buscar-me.",
  "ar": "بن… إن سمعت هذا، لا تأتِ للبحث عني."
 },
 "Bien. On t'écoute. Mais on ne baisse pas notre garde.": {
  "en": "Fine. We are listening. But we do not lower our guard.",
  "es": "Bien. Te escuchamos. Pero no bajamos la guardia.",
  "it": "Bene. Ti ascoltiamo. Ma non abbassiamo la guardia.",
  "ca": "Bé. T'escoltem. Però no baixem la guàrdia.",
  "ar": "حسنًا. نستمع إليك. لكننا لا نخفض حذرنا."
 },
 "Boulevard Cinema": {
  "en": "Boulevard Cinema",
  "es": "Boulevard Cinema",
  "it": "Boulevard Cinema",
  "ca": "Boulevard Cinema",
  "ar": "Boulevard Cinema"
 },
 "Burd": {
  "en": "Burd",
  "es": "Burd",
  "it": "Burd",
  "ca": "Burd",
  "ar": "Burd"
 },
 "C'est sa voix. Mais ça ne peut pas être lui.": {
  "en": "It is his voice. But it cannot be him.",
  "es": "Es su voz. Pero no puede ser él.",
  "it": "È la sua voce. Ma non può essere lui.",
  "ca": "És la seva veu. Però no pot ser ell.",
  "ar": "إنه صوته. لكنه لا يمكن أن يكون هو."
 },
 "Campagn Liberty": {
  "en": "Campagn Liberty",
  "es": "Campagn Liberty",
  "it": "Campagn Liberty",
  "ca": "Campagn Liberty",
  "ar": "Campagn Liberty"
 },
 "CANAL 0X": {
  "en": "CHANNEL 0X",
  "es": "CANAL 0X",
  "it": "CANALE 0X",
  "ca": "CANAL 0X",
  "ar": "القناة 0X"
 },
 "CANAL 0X-265": {
  "en": "CHANNEL 0X-265",
  "es": "CANAL 0X-265",
  "it": "CANALE 0X-265",
  "ca": "CANAL 0X-265",
  "ar": "القناة 0X-265"
 },
 "CANAL INSTABLE · ORIGINE : INCONNUE · RÉALITÉ : NON RÉPERTORIÉE": {
  "en": "UNSTABLE CHANNEL · ORIGIN: UNKNOWN · REALITY: UNCATALOGUED",
  "es": "CANAL INESTABLE · ORIGEN: DESCONOCIDO · REALIDAD: NO CATALOGADA",
  "it": "CANALE INSTABILE · ORIGINE: SCONOSCIUTA · REALTÀ: NON CATALOGATA",
  "ca": "CANAL INESTABLE · ORIGEN: DESCONEGUT · REALITAT: NO CATALOGADA",
  "ar": "قناة غير مستقرة · الأصل: مجهول · الواقع: غير مُفهرَس"
 },
 "CAPTURE N°018": {
  "en": "CAPTURE N°018",
  "es": "CAPTURA N°018",
  "it": "CAPTURA N°018",
  "ca": "CAPTURA N°018",
  "ar": "التقاط رقم 018"
 },
 "CARTE ACTIVE": {
  "en": "ACTIVE MAP",
  "es": "MAPA ACTIVO",
  "it": "MAPPA ATTIVA",
  "ca": "MAPA ACTIU",
  "ar": "الخريطة النشطة"
 },
 "CARTE ACTIVE — CHAPITRE 2 · SAISON 1 // ARCHIVE INSTITUT ONIRIQUE": {
  "en": "ACTIVE MAP — CHAPTER 2 · SEASON 1 // DREAM INSTITUTE ARCHIVE",
  "es": "MAPA ACTIVO — CAPÍTULO 2 · TEMPORADA 1 // ARCHIVO DEL INSTITUTO ONÍRICO",
  "it": "MAPPA ATTIVA — CAPITOLO 2 · STAGIONE 1 // ARCHIVIO DELL'ISTITUTO ONIRICO",
  "ca": "MAPA ACTIU — CAPÍTOL 2 · TEMPORADA 1 // ARXIU DE L'INSTITUT ONÍRIC",
  "ar": "خريطة نشطة — الفصل 2 · الموسم 1 // أرشيف المعهد الحالم"
 },
 "CARTE CHAPITRE 2 · SAISON 1 SYNCHRONISÉE": {
  "en": "CHAPTER 2 · SEASON 1 MAP SYNCHRONISED",
  "es": "MAPA DEL CAPÍTULO 2 · TEMPORADA 1 SINCRONIZADO",
  "it": "MAPPA CAPITOLO 2 · STAGIONE 1 SINCRONIZZATA",
  "ca": "MAPA DEL CAPÍTOL 2 · TEMPORADA 1 SINCRONITZAT",
  "ar": "خريطة الفصل 2 · الموسم 1 مُزامَنة"
 },
 "Carte complète de l'île du Chapitre 2 Saison 1": {
  "en": "Complete map of the Chapter 2 Season 1 island",
  "es": "Mapa completo de la isla del Capítulo 2 Temporada 1",
  "it": "Mappa completa dell’isola del Capitolo 2 Stagione 1",
  "ca": "Mapa complet de l’illa del Capítol 2 Temporada 1",
  "ar": "خريطة كاملة لجزيرة الفصل 2 الموسم 1"
 },
 "Carte de l’île": {
  "en": "Island map",
  "es": "Mapa de la isla",
  "it": "Mappa dell’isola",
  "ca": "Mapa de l’illa",
  "ar": "خريطة الجزيرة",
  "zh": "岛屿地图"
 },
 "Carte de l’île du Chapitre 2 Saison 1 avec Dirty Docks, Sanctuaire Déferlante, Greasy Groove, Holly Hedge, Risky Reels, Hotel Forest, Hony Strip, Freaky Zero, Paradise Palm, Lavish Rools, Lazy Lake, Burd, Misty Seven, Kael Base et Holliday Forge.": {
  "en": "Chapter 2 Season 1 island map with Dirty Docks, Rolling Sanctuary, Greasy Groove, Holly Hedge, Risky Reels, Hotel Forest, Hony Strip, Freaky Zero, Paradise Palm, Lavish Rools, Lazy Lake, Burd, Misty Seven, Kael Base and Holliday Forge.",
  "es": "Mapa de la isla del Capítulo 2 Temporada 1 con Dirty Docks, Santuario Rompiente, Greasy Groove, Holly Hedge, Risky Reels, Hotel Forest, Hony Strip, Freaky Zero, Paradise Palm, Lavish Rools, Lazy Lake, Burd, Misty Seven, Base de Kael y Holliday Forge.",
  "it": "Mappa dell'isola del Capitolo 2 Stagione 1 con Dirty Docks, Santuario Travolgente, Greasy Groove, Holly Hedge, Risky Reels, Hotel Forest, Hony Strip, Freaky Zero, Paradise Palm, Lavish Rools, Lazy Lake, Burd, Misty Seven, Base di Kael e Holliday Forge.",
  "ca": "Mapa de l'illa del Capítol 2 Temporada 1 amb Dirty Docks, Santuari Devastador, Greasy Groove, Holly Hedge, Risky Reels, Hotel Forest, Hony Strip, Freaky Zero, Paradise Palm, Lavish Rools, Lazy Lake, Burd, Misty Seven, Base d'en Kael i Holliday Forge.",
  "ar": "خريطة جزيرة الفصل 2 الموسم 1 مع Dirty Docks وRolling Sanctuary وGreasy Groove وHolly Hedge وRisky Reels وHotel Forest وHony Strip وFreaky Zero وParadise Palm وLavish Rools وLazy Lake وBurd وMisty Seven وقاعدة كايل وHolliday Forge."
 },
 "CARTE DE L’UNIVERS DE L’ÉCLAT DU POINT ZÉRO · SIGNAL INTERDIMENSIONNEL ACTIF.": {
  "en": "MAP OF THE UNIVERSE OF THE SHARD OF POINT ZERO · INTERDIMENSIONAL SIGNAL ACTIVE.",
  "es": "MAPA DEL UNIVERSO DEL RESPLANDOR DEL PUNTO CERO · SEÑAL INTERDIMENSIONAL ACTIVA.",
  "it": "MAPPA DELL'UNIVERSO DELLO SPLENDORE DEL PUNTO ZERO · SEGNALE INTERDIMENSIONALE ATTIVO.",
  "ca": "MAPA DE L'UNIVERS DE L'ESCLAT DEL PUNT ZERO · SENYAL INTERDIMENSIONAL ACTIU.",
  "ar": "خريطة عالم وهج النقطة صفر · إشارة بين الأبعاد نشطة."
 },
 "Carte de la Saison 8": {
  "en": "Season 8 map",
  "es": "Mapa de la Temporada 8",
  "it": "Mappa della Stagione 8",
  "ca": "Mapa de la Temporada 8",
  "ar": "خريطة الموسم 8"
 },
 "CARTE OFFICIELLE — SAISON 8 · ÎLE RECONSTRUITE": {
  "en": "OFFICIAL MAP — SEASON 8 · REBUILT ISLAND",
  "es": "MAPA OFICIAL — TEMPORADA 8 · ISLA RECONSTRUIDA",
  "it": "MAPPA UFFICIALE — STAGIONE 8 · ISOLA RICOSTRUITA",
  "ca": "MAPA OFICIAL — TEMPORADA 8 · ILLA RECONSTRUÏDA",
  "ar": "خريطة رسمية — الموسم 8 · جزيرة أُعيد بناؤها"
 },
 "Carte vue du dessus de l’île reconstruite en Saison 8, avec les lieux Esclate Root, The Prison, Greasy Groove, Holy Hedge, Burd, Boulevard Cinema, Point Zéro, Sanctuaire Sampiternel, Risky Reels, Campagn Liberty, Tilted Jool, Happy Nightmare, Frenzy Gold, Base de Ben et Lavish Tools.": {
  "en": "Top-down view of the island rebuilt in Season 8, with the locations Esclate Root, The Prison, Greasy Groove, Holy Hedge, Burd, Boulevard Cinema, Point Zero, Sampiternel Sanctuary, Risky Reels, Campagn Liberty, Tilted Jool, Happy Nightmare, Frenzy Gold, Ben's Base and Lavish Tools.",
  "es": "Vista cenital de la isla reconstruida en la Temporada 8, con los lugares Esclate Root, The Prison, Greasy Groove, Holy Hedge, Burd, Boulevard Cinema, Punto Cero, Santuario Sampiternel, Risky Reels, Campagn Liberty, Tilted Jool, Happy Nightmare, Frenzy Gold, Base de Ben y Lavish Tools.",
  "it": "Vista dall'alto dell'isola ricostruita nella Stagione 8, con i luoghi Esclate Root, The Prison, Greasy Groove, Holy Hedge, Burd, Boulevard Cinema, Punto Zero, Santuario Sampiternel, Risky Reels, Campagn Liberty, Tilted Jool, Happy Nightmare, Frenzy Gold, Base di Ben e Lavish Tools.",
  "ca": "Vista zenital de l'illa reconstruïda a la Temporada 8, amb els llocs Esclate Root, The Prison, Greasy Groove, Holy Hedge, Burd, Boulevard Cinema, Punt Zero, Santuari Sampiternel, Risky Reels, Campagn Liberty, Tilted Jool, Happy Nightmare, Frenzy Gold, Base d'en Ben i Lavish Tools.",
  "ar": "منظر علوي للجزيرة المُعاد بناؤها في الموسم 8، مع المواقع Esclate Root وThe Prison وGreasy Groove وHoly Hedge وBurd وBoulevard Cinema والنقطة صفر وملاذ Sampiternel وRisky Reels وCampagn Liberty وTilted Jool وHappy Nightmare وFrenzy Gold وقاعدة بن وLavish Tools."
 },
 "Cartographie interdimensionnelle — Le Fragment Zéro": {
  "en": "Interdimensional cartography — The Zero Fragment",
  "es": "Cartografía interdimensional — El Fragmento Cero",
  "it": "Cartografia interdimensionale — Il Frammento Zero",
  "ca": "Cartografia interdimensional — El Fragment Zero",
  "ar": "خرائط بين الأبعاد — الجزء صفر"
 },
 "Ce dossier n'apparaît qu'après la saisie du code. Il rassemble les souvenirs que les archives officielles ont effacés : l'enfance de Jean et Ben, leurs parents encore vivants, et les premiers signes d'une fracture qui allait dépasser leur famille.": {
  "en": "This file appears only after the code is entered. It gathers the memories that official archives erased: the childhood of Jean and Ben, their parents still alive, and the first signs of a fracture that would exceed their family.",
  "es": "Este expediente solo aparece tras introducir el código. Reúne los recuerdos que los archivos oficiales borraron: la infancia de Jean y Ben, sus padres aún vivos y los primeros signos de una fractura que superaría a su familia.",
  "it": "Questo fascicolo appare solo dopo l'inserimento del codice. Riunisce i ricordi che gli archivi ufficiali hanno cancellato: l'infanzia di Jean e Ben, i loro genitori ancora vivi e i primi segni di una frattura che avrebbe superato la loro famiglia.",
  "ca": "Aquest expedient només apareix després d'introduir el codi. Reuneix els records que els arxius oficials van esborrar: la infància d'en Jean i en Ben, els seus pares encara vius i els primers signes d'una fractura que superaria la seva família.",
  "ar": "لا يظهر هذا الملف إلا بعد إدخال الرمز. يجمع الذكريات التي محتها الأرشيفات الرسمية: طفولة جان وبن، ووالديهما الأحياء، وأولى علامات تصدُّع سيتجاوز عائلتهما."
 },
 "Ce n'est pas Jean.": {
  "en": "It is not Jean.",
  "es": "No es Jean.",
  "it": "Non è Jean.",
  "ca": "No és en Jean.",
  "ar": "إنه ليس جان."
 },
 "Ce n'est pas Jean. C'est celui qui l'a enfermé.": {
  "en": "It is not Jean. It is the one who locked him away.",
  "es": "No es Jean. Es el que lo encerró.",
  "it": "Non è Jean. È colui che l'ha rinchiuso.",
  "ca": "No és en Jean. És el qui el va tancar.",
  "ar": "إنه ليس جان. إنه من حبسه."
 },
 "Ce nom. Je vous ai demandé de ne plus m'appeler ainsi.": {
  "en": "That name. I asked you not to call me that any more.",
  "es": "Ese nombre. Os pedí que no me llamarais así.",
  "it": "Quel nome. Vi ho chiesto di non chiamarmi più così.",
  "ca": "Aquest nom. Us vaig demanar que no em diguéssiu així.",
  "ar": "ذلك الاسم. طلبت منكم ألا تنادونني به بعد الآن."
 },
 "Ce que Jean a sacrifié": {
  "en": "What Jean sacrificed",
  "es": "Lo que Jean sacrificó",
  "it": "Ciò che Jean ha sacrificato",
  "ca": "El que en Jean va sacrificar",
  "ar": "ما ضحّى به جان"
 },
 "Ce que Jean a voulu préserver": {
  "en": "What Jean wanted to preserve",
  "es": "Lo que Jean quiso preservar",
  "it": "Ciò che Jean ha voluto preservare",
  "ca": "El que en Jean va voler preservar",
  "ar": "ما أراد جان الحفاظ عليه"
 },
 "Ce sont les personnes que Jean considère comme des menaces. Les lieux sont classés par ordre d'intervention.": {
  "en": "These are the people Jean considers threats. The locations are ranked by order of intervention.",
  "es": "Estas son las personas que Jean considera amenazas. Los lugares están clasificados por orden de intervención.",
  "it": "Queste sono le persone che Jean considera minacce. I luoghi sono ordinati per intervento.",
  "ca": "Aquestes són les persones que en Jean considera amenaces. Els llocs estan classificats per ordre d'intervenció.",
  "ar": "هؤلاء هم الأشخاص الذين يعتبرهم جان تهديدات. والمواقع مرتَّبة حسب ترتيب التدخل."
 },
 "Celui que vous appelez Le Vide.": {
  "en": "The one you call the Void.",
  "es": "Aquel al que llamáis el Vacío.",
  "it": "Colui che chiamate il Vuoto.",
  "ca": "Aquell que anomeneu el Buit.",
  "ar": "من تسمّونه الفراغ."
 },
 "certaines transmissions semblent répondre à des pensées qu'il n'a jamais prononcées à voix haute.": {
  "en": "some transmissions seem to answer thoughts he has never spoken aloud.",
  "es": "algunas transmisiones parecen responder a pensamientos que nunca ha dicho en voz alta.",
  "it": "alcune trasmissioni sembrano rispondere a pensieri che non ha mai detto ad alta voce.",
  "ca": "algunes transmissions semblen respondre a pensaments que mai no ha dit en veu alta.",
  "ar": "تبدو بعض البثّات تجيب عن أفكار لم ينطق بها قط."
 },
 "CH. 02 // S. 01": {
  "en": "CH. 02 // S. 01",
  "es": "CAP. 02 // T. 01",
  "it": "CAP. 02 // S. 01",
  "ca": "CAP. 02 // T. 01",
  "ar": "الفصل 02 // الموسم 01"
 },
 "CH.02 / S.01": {
  "en": "CH.02 / S.01",
  "es": "CAP.02 / T.01",
  "it": "CAP.02 / S.01",
  "ca": "CAP.02 / T.01",
  "ar": "CH.02 / S.01"
 },
 "CHAPITRE 02": {
  "en": "CHAPTER 02",
  "es": "CAPÍTULO 02",
  "it": "CAPITOLO 02",
  "ca": "CAPÍTOL 02",
  "ar": "الفصل 02"
 },
 "CHAPITRE 2 · SAISON 1": {
  "en": "CHAPTER 2 · SEASON 1",
  "es": "CAPÍTULO 2 · TEMPORADA 1",
  "it": "CAPITOLO 2 · STAGIONE 1",
  "ca": "CAPÍTOL 2 · TEMPORADA 1",
  "ar": "الفصل 2 · الموسم 1"
 },
 "CHAPITRE I · LA MAISON AUX FENÊTRES BLEUES": {
  "en": "CHAPTER I · THE HOUSE WITH BLUE WINDOWS",
  "es": "CAPÍTULO I · LA CASA DE LAS VENTANAS AZULES",
  "it": "CAPITOLO I · LA CASA CON LE FINESTRE BLU",
  "ca": "CAPÍTOL I · LA CASA DE LES FINESTRES BLAVES",
  "ar": "الفصل I · البيت ذو النوافذ الزرقاء"
 },
 "CHAPITRE II · DEUX ENFANTS, DEUX MONDES": {
  "en": "CHAPTER II · TWO CHILDREN, TWO WORLDS",
  "es": "CAPÍTULO II · DOS NIÑOS, DOS MUNDOS",
  "it": "CAPITOLO II · DUE BAMBINI, DUE MONDI",
  "ca": "CAPÍTOL II · DOS NENS, DOS MONS",
  "ar": "الفصل II · طفلان، عالمان"
 },
 "CHAPITRE III · LA PREMIÈRE ANOMALIE": {
  "en": "CHAPTER III · THE FIRST ANOMALY",
  "es": "CAPÍTULO III · LA PRIMERA ANOMALÍA",
  "it": "CAPITOLO III · LA PRIMA ANOMALIA",
  "ca": "CAPÍTOL III · LA PRIMERA ANOMALIA",
  "ar": "الفصل III · الشذوذ الأول"
 },
 "CHAPITRE IV · LES PARENTS VIVANTS": {
  "en": "CHAPTER IV · THE LIVING PARENTS",
  "es": "CAPÍTULO IV · LOS PADRES VIVOS",
  "it": "CAPITOLO IV · I GENITORI VIVI",
  "ca": "CAPÍTOL IV · ELS PARES VIUS",
  "ar": "الفصل IV · الوالدان الحيان"
 },
 "CHAPITRE V · LA ROUTE VERS LA GARDE ZÉRO": {
  "en": "CHAPTER V · THE ROAD TO THE ZERO GUARD",
  "es": "CAPÍTULO V · EL CAMINO HACIA LA GUARDIA CERO",
  "it": "CAPITOLO V · LA STRADA VERSO LA GUARDIA ZERO",
  "ca": "CAPÍTOL V · EL CAMÍ CAP A LA GUÀRDIA ZERO",
  "ar": "الفصل V · الطريق إلى حرس الصفر"
 },
 "CHAPITRE VI · CE QUE LE CODE DÉVERROUILLE": {
  "en": "CHAPTER VI · WHAT THE CODE UNLOCKS",
  "es": "CAPÍTULO VI · LO QUE DESBLOQUEA EL CÓDIGO",
  "it": "CAPITOLO VI · CIÒ CHE IL CODICE SBLOCCA",
  "ca": "CAPÍTOL VI · EL QUE DESBLOQUEJA EL CODI",
  "ar": "الفصل VI · ما يفتحه الرمز"
 },
 "Chaque dossier contient une partie de la vérité. Certains éléments sont encore incomplets.": {
  "en": "Each file holds part of the truth. Some pieces are still missing.",
  "es": "Cada expediente contiene parte de la verdad. Algunos elementos aún están incompletos.",
  "it": "Ogni fascicolo contiene una parte della verità. Alcuni elementi sono ancora incompleti.",
  "ca": "Cada expedient conté una part de la veritat. Alguns elements encara són incomplets.",
  "ar": "كل ملف يحمل جزءًا من الحقيقة. بعض العناصر لا تزال ناقصة."
 },
 "Chargement": {
  "en": "Loading",
  "es": "Cargando",
  "it": "Caricamento",
  "ca": "Carregant",
  "ar": "جارٍ التحميل",
  "zh": "加载中"
 },
 "CHERCHER LES SECRETS →": {
  "en": "SEARCH FOR THE SECRETS →",
  "es": "BUSCAR LOS SECRETOS →",
  "it": "CERCA I SEGRETI →",
  "ca": "CERCA ELS SECRETS →",
  "ar": "ابحث عن الأسرار →"
 },
 "Chez Jean, chaque dispute familiale le bouleversait plus qu'il ne le montrait. Il rêvait d'un monde où personne ne hausserait jamais la voix, où aucune porte ne claquerait et où aucun départ ne serait possible. Ses parents tentaient de lui apprendre qu'une famille pouvait se disputer et continuer à s'aimer. Mais Jean transformait peu à peu leur leçon en une idée dangereuse : si le conflit faisait souffrir, il suffirait de supprimer tout ce qui pouvait provoquer un conflit.": {
  "en": "In Jean, every family argument upset him more than he showed. He dreamed of a world where no one would ever raise their voice, where no door would slam and where no departure would be possible. His parents tried to teach him that a family could argue and still love each other. But Jean gradually turned their lesson into a dangerous idea: if conflict caused suffering, it would be enough to remove everything that could provoke conflict.",
  "es": "En Jean, cada disputa familiar lo perturbaba más de lo que mostraba. Soñaba con un mundo donde nadie levantaría nunca la voz, donde ninguna puerta se cerraría de golpe y donde ninguna partida sería posible. Sus padres intentaban enseñarle que una familia podía discutir y seguir queriéndose. Pero Jean transformaba poco a poco su lección en una idea peligrosa: si el conflicto causaba sufrimiento, bastaría con eliminar todo lo que pudiera provocar conflicto.",
  "it": "In Jean, ogni discussione familiare lo turbava più di quanto mostrasse. Sognava un mondo in cui nessuno alzasse mai la voce, in cui nessuna porta sbattesse e in cui nessuna partenza fosse possibile. I suoi genitori cercavano di insegnargli che una famiglia poteva litigare e continuare ad amarsi. Ma Jean trasformava a poco a poco la loro lezione in un'idea pericolosa: se il conflitto causava sofferenza, sarebbe bastato eliminare tutto ciò che poteva provocare conflitto.",
  "ca": "En Jean, cada disputa familiar el trasbalsava més del que mostrava. Somiava un món on ningú no aixequés mai la veu, on cap porta no es tanqués de cop i on cap marxa no fos possible. Els seus pares intentaven ensenyar-li que una família podia discutir i continuar estimant-se. Però en Jean transformava a poc a poc la seva lliçó en una idea perillosa: si el conflicte causava patiment, n'hi hauria prou d'eliminar tot el que pogués provocar conflicte.",
  "ar": "في جان، كانت كل مشاجرة عائلية تزعجه أكثر مما يُظهر. كان يحلم بعالم لا يرفع فيه أحد صوته أبدًا، ولا يُصفق فيه باب، ولا يكون فيه رحيل ممكنًا. حاول والداه تعليمه أن العائلة قد تتشاجر وتواصل الحب. لكن جان كان يحوّل درسهم شيئًا فشيئًا إلى فكرة خطرة: إذا كان الصراع يسبّب الألم، فيكفي محو كل ما قد يثير الصراع."
 },
 "Choisis un épisode dans le menu. Lis toute la scène ou avance réplique par réplique avec le bouton. Commence par la Transmission 001 pour suivre l'histoire dans l'ordre.": {
  "en": "Choose an episode from the menu. Read the whole scene or advance line by line with the button. Start with Transmission 001 to follow the story in order.",
  "es": "Elige un episodio en el menú. Lee toda la escena o avanza réplica por réplica con el botón. Empieza por la Transmisión 001 para seguir la historia en orden.",
  "it": "Scegli un episodio dal menu. Leggi tutta la scena o avanza battuta per battuta con il pulsante. Inizia dalla Trasmissione 001 per seguire la storia in ordine.",
  "ca": "Tria un episodi al menú. Llegeix tota l'escena o avança rèplica per rèplica amb el botó. Comença per la Transmissió 001 per seguir la història en ordre.",
  "ar": "اختر حلقة من القائمة. اقرأ المشهد كاملًا أو تقدَّم جملة بجملة بالزر. ابدأ بالبث 001 لمتابعة القصة بالترتيب."
 },
 "Chronologie complète — Le Fragment Zéro": {
  "en": "Complete timeline — The Zero Fragment",
  "es": "Cronología completa — El Fragmento Cero",
  "it": "Cronologia completa — Il Frammento Zero",
  "ca": "Cronologia completa — El Fragment Zero",
  "ar": "تسلسل زمني كامل — الجزء صفر"
 },
 "Chronologie mise à jour — Saison 7 : conclusion de Jean ; Saison 8 : arrivée de Kael et nouvelle île.": {
  "en": "Timeline updated — Season 7: Jean's conclusion; Season 8: Kael's arrival and a new island.",
  "es": "Cronología actualizada — Temporada 7: conclusión de Jean; Temporada 8: llegada de Kael y nueva isla.",
  "it": "Cronologia aggiornata — Stagione 7: conclusione di Jean; Stagione 8: arrivo di Kael e nuova isola.",
  "ca": "Cronologia actualitzada — Temporada 7: conclusió d’en Jean; Temporada 8: arribada d’en Kael i nova illa.",
  "ar": "تم تحديث التسلسل الزمني — الموسم 7: خاتمة جان؛ الموسم 8: وصول كايل وجزيرة جديدة."
 },
 "Clique sur « Lire la fiche complète » sous chaque personnage pour découvrir son histoire, ses motivations, ses liens et ses secrets.": {
  "en": "Click on « Read the full sheet » under each character to discover their story, motivations, links and secrets.",
  "es": "Haz clic en « Leer la ficha completa » bajo cada personaje para descubrir su historia, sus motivaciones, sus vínculos y sus secretos.",
  "it": "Clicca su « Leggi la scheda completa » sotto ogni personaggio per scoprirne la storia, le motivazioni, i legami e i segreti.",
  "ca": "Fes clic a « Llegeix la fitxa completa » sota cada personatge per descobrir la seva història, motivacions, vincles i secrets.",
  "ar": "انقر على «اقرأ البطاقة الكاملة» أسفل كل شخصية لتكتشف قصتها ودوافعها وروابطها وأسرارها."
 },
 "CODE ACCEPTÉ. IDENTITÉS CONFIRMÉES : JEAN / BEN. DOSSIER SOURCE DÉVERROUILLÉ.": {
  "en": "CODE ACCEPTED. IDENTITIES CONFIRMED: JEAN / BEN. SOURCE FILE UNLOCKED.",
  "es": "CÓDIGO ACEPTADO. IDENTIDADES CONFIRMADAS: JEAN / BEN. EXPEDIENTE FUENTE DESBLOQUEADO.",
  "it": "CODICE ACCETTATO. IDENTITÀ CONFERMATE: JEAN / BEN. FASCICOLO SORGENTE SBLOCCATO.",
  "ca": "CODI ACCEPTAT. IDENTITATS CONFIRMADES: JEAN / BEN. EXPEDIENT FONT DESBLOQUEJAT.",
  "ar": "تم قبول الرمز. تم تأكيد الهويات: جان / بن. تم فتح الملف المصدر."
 },
 "CODE INVALIDE. Accès refusé.": {
  "en": "INVALID CODE. Access denied.",
  "es": "CÓDIGO NO VÁLIDO. Acceso denegado.",
  "it": "CODICE NON VALIDO. Accesso negato.",
  "ca": "CODI NO VÀLID. Accés denegat.",
  "ar": "رمز غير صالح. تم رفض الوصول."
 },
 "Codes classés : 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse": {
  "en": "Classified codes: 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse",
  "es": "Códigos clasificados: 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse",
  "it": "Codici classificati: 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse",
  "ca": "Codis classificats: 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse",
  "ar": "رموز مصنَّفة: 286265, kael, ancienallie, oliekael, sanctuaire, dernierfragment, etoile, restauration, kaelretour, signalfreaky, porte, reponse"
 },
 "Coincé par les sentinelles de Jean, Ben est contacté par le Vide lui-même, qui lui offre de remonter le temps grâce à l'aide d'Aidan : revivre le jour où tout a basculé, avant le dîner fatal. Ben atterrit dans le passé et retrouve Ducky vivant, qui ne le reconnaît pas encore.": {
  "en": "Trapped by Jean's sentinels, Ben is contacted by the Void itself, which offers to send him back in time with Aidan's help: to relive the day everything tipped over, before the fatal dinner. Ben lands in the past and finds Ducky alive, not yet recognising him.",
  "es": "Atrapado por las centinelas de Jean, Ben recibe el contacto del propio Vacío, que le ofrece retroceder en el tiempo con la ayuda de Aidan: revivir el día en que todo cambió, antes de la cena fatal. Ben aterriza en el pasado y encuentra a Ducky vivo, que aún no lo reconoce.",
  "it": "Intrappolato dalle sentinelle di Jean, Ben viene contattato dal Vuoto stesso, che gli offre di tornare indietro nel tempo grazie all’aiuto di Aidan: rivivere il giorno in cui tutto è cambiato, prima della cena fatale. Ben atterra nel passato e ritrova Ducky vivo, che non lo riconosce ancora.",
  "ca": "Atrapat per les sentinelles d’en Jean, en Ben rep el contacte del mateix Buit, que li ofereix tornar enrere en el temps gràcies a l’ajuda d’Aidan: reviure el dia en què tot va canviar, abans del sopar fatal. En Ben aterra en el passat i troba en Ducky viu, que encara no el reconeix.",
  "ar": "بعد أن حاصرته حراسة جان، يتواصل الفراغ نفسه مع بن، ويعرض عليه العودة في الزمن بمساعدة أيدن: أن يعيش من جديد اليوم الذي انقلب فيه كل شيء، قبل العشاء القاتل. يهبط بن في الماضي ويجد دكي حيًّا، لكنه لا يعرفه بعد."
 },
 "Commande inconnue. Tape help.": {
  "en": "Unknown command. Type help.",
  "es": "Comando desconocido. Escribe help.",
  "it": "Comando sconosciuto. Digita help.",
  "ca": "Comanda desconeguda. Escriu help.",
  "ar": "أمر غير معروف. اكتب help."
 },
 "Commande terminal :": {
  "en": "Terminal command:",
  "es": "Comando de terminal:",
  "it": "Comando del terminale:",
  "ca": "Ordre de terminal:",
  "ar": "أمر الطرفية:"
 },
 "Commandes : help, status, files, clear, unlock": {
  "en": "Commands: help, status, files, clear, unlock",
  "es": "Comandos: help, status, files, clear, unlock",
  "it": "Comandi: help, status, files, clear, unlock",
  "ca": "Ordres: help, status, files, clear, unlock",
  "ar": "الأوامر: help, status, files, clear, unlock"
 },
 "Commence par taper": {
  "en": "Start by typing",
  "es": "Empieza escribiendo",
  "it": "Inizia digitando",
  "ca": "Comença escrivint",
  "ar": "ابدأ بكتابة"
 },
 "Complexe au cœur de la forêt.": {
  "en": "Complex at the heart of the forest.",
  "es": "Complejo en el corazón del bosque.",
  "it": "Complesso nel cuore della foresta.",
  "ca": "Complex al cor del bosc.",
  "ar": "مجمع في قلب الغابة."
 },
 "Complexe au sud-est.": {
  "en": "Complex to the south-east.",
  "es": "Complejo al sureste.",
  "it": "Complesso a sud-est.",
  "ca": "Complex al sud-est.",
  "ar": "مجمع في الجنوب الشرقي."
 },
 "comprendre le Point Zéro et empêcher une réaction en chaîne entre les réalités.": {
  "en": "to understand Point Zero and prevent a chain reaction between realities.",
  "es": "comprender el Punto Cero y evitar una reacción en cadena entre las realidades.",
  "it": "comprendere il Punto Zero e impedire una reazione a catena tra le realtà.",
  "ca": "comprendre el Punt Zero i evitar una reacció en cadena entre les realitats.",
  "ar": "فهم النقطة صفر ومنع تفاعل متسلسل بين الأواقع."
 },
 "confidentiels": {
  "en": "classified",
  "es": "clasificados",
  "it": "classificati",
  "ca": "classificats",
  "ar": "مصنَّفة"
 },
 "Connexion au Point Zéro": {
  "en": "Connecting to Point Zero",
  "es": "Conexión con el Punto Cero",
  "it": "Connessione al Punto Zero",
  "ca": "Connexió amb el Punt Zero",
  "ar": "الاتصال بالنقطة صفر"
 },
 "CONNEXION AU POINT ZÉRO": {
  "en": "CONNECTING TO POINT ZERO",
  "es": "CONEXIÓN AL PUNTO CERO",
  "it": "CONNESSIONE AL PUNTO ZERO",
  "ca": "CONNEXIÓ AL PUNT ZERO",
  "ar": "الاتصال بالنقطة صفر"
 },
 "Connexion locale établie. Point Zéro libéré // Île reconstruite // Archives Saison 8 disponibles.": {
  "en": "Local connection established. Point Zero released // Island rebuilt // Season 8 archives available.",
  "es": "Conexión local establecida. Punto Cero liberado // Isla reconstruida // Archivos de la Temporada 8 disponibles.",
  "it": "Connessione locale stabilita. Punto Zero liberato // Isola ricostruita // Archivi Stagione 8 disponibili.",
  "ca": "Connexió local establerta. Punt Zero alliberat // Illa reconstruïda // Arxius de la Temporada 8 disponibles.",
  "ar": "تم إنشاء اتصال محلي. النقطة صفر محرَّرة // الجزيرة أُعيد بناؤها // أرشيفات الموسم 8 متاحة."
 },
 "Connu sous le nom du Vide, Alyss est une entité redoutée capable d'effacer des réalités. Mais derrière cette force se cache un être hanté par le remords.": {
  "en": "Known as the Void, Alyss is a feared entity capable of erasing realities. But behind this force hides a being haunted by remorse.",
  "es": "Conocido como el Vacío, Alyss es una entidad temida capaz de borrar realidades. Pero tras esa fuerza se esconde un ser atormentado por el remordimiento.",
  "it": "Conosciuto come il Vuoto, Alyss è un'entità temuta capace di cancellare realtà. Ma dietro questa forza si nasconde un essere tormentato dal rimorso.",
  "ca": "Connegut com el Buit, l'Alyss és una entitat temuda capaç d'esborrar realitats. Però darrere d'aquesta força s'amaga un ésser turmentat pel remordiment.",
  "ar": "يُعرف باسم الفراغ، أليس كيانٌ مخيف قادر على محو الأواقع. لكن خلف هذه القوة يختبئ كائن يطارده الندم."
 },
 "CONSULTER": {
  "en": "VIEW",
  "es": "CONSULTAR",
  "it": "CONSULTA",
  "ca": "CONSULTA",
  "ar": "اطّلع"
 },
 "Consulter les archives": {
  "en": "View the archives",
  "es": "Consultar los archivos",
  "it": "Consulta gli archivi",
  "ca": "Consulta els arxius",
  "ar": "تصفّح الأرشيف"
 },
 "Consulter les transmissions →": {
  "en": "View the transmissions →",
  "es": "Consultar las transmisiones →",
  "it": "Consulta le trasmissioni →",
  "ca": "Consulta les transmissions →",
  "ar": "اطّلع على البثّات →"
 },
 "COORD. 0X-265-FZ": {
  "en": "COORD. 0X-265-FZ",
  "es": "COORD. 0X-265-FZ",
  "it": "COORD. 0X-265-FZ",
  "ca": "COORD. 0X-265-FZ",
  "ar": "COORD. 0X-265-FZ"
 },
 "Copie les fichiers. Tous. Si Jean veut effacer nos noms, on va d'abord révéler le sien.": {
  "en": "Copy the files. All of them. If Jean wants to erase our names, we will reveal his first.",
  "es": "Copia los archivos. Todos. Si Jean quiere borrar nuestros nombres, primero revelaremos el suyo.",
  "it": "Copia i file. Tutti. Se Jean vuole cancellare i nostri nomi, riveleremo prima il suo.",
  "ca": "Copia els fitxers. Tots. Si en Jean vol esborrar els nostres noms, primer revelarem el seu.",
  "ar": "انسخ الملفات. كلها. إن أراد جان محو أسمائنا، فسنكشف اسمه أولًا."
 },
 "D'accord. Mais si nous voulons le retrouver, nous devrons retourner à l'endroit où tout a commencé.": {
  "en": "All right. But if we want to find him, we will have to return to where it all began.",
  "es": "De acuerdo. Pero si queremos encontrarlo, tendremos que volver al lugar donde todo empezó.",
  "it": "D'accordo. Ma se vogliamo ritrovarlo, dovremo tornare dove tutto è cominciato.",
  "ca": "D'acord. Però si volem retrobar-lo, haurem de tornar al lloc on tot va començar.",
  "ar": "حسنًا. لكن إن أردنا إيجاده، فسعلينا العودة إلى حيث بدأ كل شيء."
 },
 "Dans la Réalité 286, Ben vit un phénomène similaire des années plus tard : une lumière au loin et un bref tremblement dans l'air. Mais il entendit aussi sa mère lui dire que la peur ne devait pas décider à sa place. Il garda cette phrase avec lui.": {
  "en": "In Reality 286, Ben experiences a similar phenomenon years later: a light in the distance and a brief tremor in the air. But he also heard his mother tell him that fear must not decide in his place. He kept that sentence with him.",
  "es": "En la Realidad 286, Ben vive un fenómeno similar años más tarde: una luz a lo lejos y un breve temblor en el aire. Pero también oyó a su madre decirle que el miedo no debía decidir en su lugar. Guardó esa frase consigo.",
  "it": "Nella Realtà 286, Ben vive un fenomeno simile anni dopo: una luce in lontananza e un breve tremore nell'aria. Ma sentì anche sua madre dirgli che la paura non doveva decidere al posto suo. Conservò quella frase con sé.",
  "ca": "A la Realitat 286, en Ben viu un fenomen semblant anys més tard: una llum al lluny i un breu tremolor en l'aire. Però també va sentir la seva mare dir-li que la por no havia de decidir al seu lloc. Va guardar aquella frase amb ell.",
  "ar": "في الواقع 286، يعيش بن ظاهرة مشابهة بعد سنوات: ضوء في الأفق وارتجاف قصير في الهواء. لكنه سمع أيضًا والدته تقول إن الخوف لا ينبغي أن يقرر مكانه. احتفظ بتلك الجملة معه."
 },
 "Dans le souvenir conservé par ce dossier, les parents de Jean sont toujours vivants. Il revient les voir après ses premières expériences et leur promet qu'un jour, il trouvera un moyen d'empêcher la souffrance. Sa mère lui répond qu'on ne peut pas protéger les gens en leur retirant le droit de choisir. Son père lui dit qu'un monde sans désaccord peut aussi devenir un monde où personne n'ose plus parler.": {
  "en": "In the memory preserved by this file, Jean's parents are still alive. He returns to see them after his first experiments and promises them that one day he will find a way to prevent suffering. His mother answers that one cannot protect people by taking away their right to choose. His father tells him that a world without disagreement can also become a world where no one dares speak any more.",
  "es": "En el recuerdo conservado por este expediente, los padres de Jean siguen vivos. Vuelve a verlos tras sus primeros experimentos y les promete que algún día encontrará la forma de impedir el sufrimiento. Su madre le responde que no se puede proteger a la gente quitándole el derecho a elegir. Su padre le dice que un mundo sin desacuerdo también puede convertirse en un mundo donde nadie se atreva ya a hablar.",
  "it": "Nel ricordo conservato da questo fascicolo, i genitori di Jean sono ancora vivi. Torna a trovarli dopo i suoi primi esperimenti e promette loro che un giorno troverà un modo per impedire la sofferenza. Sua madre gli risponde che non si possono proteggere le persone togliendo loro il diritto di scegliere. Suo padre gli dice che un mondo senza disaccordo può diventare anche un mondo in cui nessuno osa più parlare.",
  "ca": "En el record conservat per aquest expedient, els pares d'en Jean continuen vius. Torna a veure'ls després dels seus primers experiments i els promet que algun dia trobarà la manera d'impedir el patiment. La seva mare li respon que no es pot protegir la gent traient-li el dret a triar. El seu pare li diu que un món sense desacord també pot esdevenir un món on ningú no gosa parlar.",
  "ar": "في الذكرى التي يحفظها هذا الملف، لا يزال والدا جان على قيد الحياة. يعود لرؤيتهما بعد تجاربه الأولى ويعدهم بأنه سيجد يومًا طريقة لمنع المعاناة. تجيبه والدته بأنه لا يمكن حماية الناس بسلبهم حقّ الاختيار. ويقول له والده إن عالمًا بلا خلاف قد يصبح أيضًا عالمًا لا يجرؤ فيه أحد على الكلام."
 },
 "De mon frère.": {
  "en": "My brother's.",
  "es": "De mi hermano.",
  "it": "Di mio fratello.",
  "ca": "Del meu germà.",
  "ar": "أخي."
 },
 "DÉCÉDÉ — FIN DE LA SAISON 7": {
  "en": "DECEASED — END OF SEASON 7",
  "es": "FALLECIDO — FIN DE LA TEMPORADA 7",
  "it": "DECEDUTO — FINE DELLA STAGIONE 7",
  "ca": "MORT — FI DE LA TEMPORADA 7",
  "ar": "متوفّى — نهاية الموسم 7"
 },
 "DÉCODER": {
  "en": "DECODE",
  "es": "DESCIFRAR",
  "it": "DECODIFICA",
  "ca": "DESXIFRA",
  "ar": "فكّ التشفير"
 },
 "découvrir la vérité sans laisser Jean écrire l'histoire à leur place.": {
  "en": "to uncover the truth without letting Jean write history in their place.",
  "es": "descubrir la verdad sin dejar que Jean escriba la historia en su lugar.",
  "it": "scoprire la verità senza lasciare che Jean scriva la storia al loro posto.",
  "ca": "descobrir la veritat sense deixar que en Jean escrigui la història al seu lloc.",
  "ar": "كشف الحقيقة دون أن يكتب جان التاريخ بدلًا عنهم."
 },
 "Découvrir les personnages en dialogue →": {
  "en": "Meet the characters in dialogue →",
  "es": "Conocer a los personajes en diálogo →",
  "it": "Conosci i personaggi in dialogo →",
  "ca": "Coneix els personatges en diàleg →",
  "ar": "تعرَّف على الشخصيات في الحوارات →"
 },
 "déferlant": {
  "en": "rolling",
  "es": "rompiente",
  "it": "travolgente",
  "ca": "devastador",
  "ar": "متلاطم"
 },
 "DÉFILER POUR EXPLORER ↓": {
  "en": "SCROLL TO EXPLORE ↓",
  "es": "DESPLAZA PARA EXPLORAR ↓",
  "it": "SCORRI PER ESPLORARE ↓",
  "ca": "DESPLAÇA PER EXPLORAR ↓",
  "ar": "مرّر للاستكشاف ↓"
 },
 "Dernier état du dossier :": {
  "en": "Final file status:",
  "es": "Estado final del expediente:",
  "it": "Stato finale del fascicolo:",
  "ca": "Estat final de l'expedient:",
  "ar": "حالة الملف النهائية:"
 },
 "DERNIER SIGNAL": {
  "en": "LAST SIGNAL",
  "es": "ÚLTIMA SEÑAL",
  "it": "ULTIMO SEGNALE",
  "ca": "ÚLTIM SENYAL",
  "ar": "آخر إشارة"
 },
 "Des noms… des centaines de noms. Ce n'est pas une liste de coordonnées.": {
  "en": "Names… hundreds of names. This is not a list of coordinates.",
  "es": "Nombres… cientos de nombres. Esto no es una lista de coordenadas.",
  "it": "Nomi… centinaia di nomi. Questa non è una lista di coordinate.",
  "ca": "Noms… centenars de noms. Això no és una llista de coordenades.",
  "ar": "أسماء… مئات الأسماء. هذه ليست قائمة إحداثيات."
 },
 "Deux Ben différents": {
  "en": "Two different Bens",
  "es": "Dos Ben diferentes",
  "it": "Due Ben diversi",
  "ca": "Dos Ben diferents",
  "ar": "بِنان مختلفان"
 },
 "dialogues": {
  "en": "dialogues",
  "es": "diálogos",
  "it": "dialoghi",
  "ca": "diàlegs",
  "ar": "الحوارات"
 },
 "Dialogues": {
  "en": "Dialogues",
  "es": "Diálogos",
  "it": "Dialoghi",
  "ca": "Diàlegs",
  "ar": "الحوارات",
  "zh": "对话"
 },
 "Dialogues — L'Éclat du Point Zéro": {
  "en": "Dialogues — The Shard of Point Zero",
  "es": "Diálogos — El Resplandor del Punto Cero",
  "it": "Dialoghi — Lo Splendore del Punto Zero",
  "ca": "Diàlegs — L'Esclat del Punt Zero",
  "ar": "الحوارات — وهج النقطة صفر"
 },
 "Dirty Docks": {
  "en": "Dirty Docks",
  "es": "Dirty Docks",
  "it": "Dirty Docks",
  "ca": "Dirty Docks",
  "ar": "Dirty Docks"
 },
 "DIRTY DOCKS": {
  "en": "DIRTY DOCKS",
  "es": "DIRTY DOCKS",
  "it": "DIRTY DOCKS",
  "ca": "DIRTY DOCKS",
  "ar": "DIRTY DOCKS"
 },
 "DISPARU — SIGNAL INCONNU": {
  "en": "MISSING — UNKNOWN SIGNAL",
  "es": "DESAPARECIDO — SEÑAL DESCONOCIDA",
  "it": "SCOMPARSO — SEGNALE SCONOSCIUTO",
  "ca": "DESAPAREGUT — SENYAL DESCONEGUT",
  "ar": "مفقود — إشارة مجهولة"
 },
 "DOCTEUR VOSS": {
  "en": "DOCTOR VOSS",
  "es": "DOCTOR VOSS",
  "it": "DOTTOR VOSS",
  "ca": "DOCTOR VOSS",
  "ar": "الدكتور فوس"
 },
 "DOSSIER CENTRAL": {
  "en": "CENTRAL FILE",
  "es": "EXPEDIENTE CENTRAL",
  "it": "FASCICOLO CENTRALE",
  "ca": "EXPEDIENT CENTRAL",
  "ar": "الملف المركزي"
 },
 "DOSSIER CENTRAL · CHRONOLOGIE OFFICIELLE": {
  "en": "CENTRAL FILE · OFFICIAL TIMELINE",
  "es": "EXPEDIENTE CENTRAL · CRONOLOGÍA OFICIAL",
  "it": "FASCICOLO CENTRALE · CRONOLOGIA UFFICIALE",
  "ca": "EXPEDIENT CENTRAL · CRONOLOGIA OFICIAL",
  "ar": "الملف المركزي · التسلسل الزمني الرسمي"
 },
 "DOSSIER CLASSIFIÉ · SOURCE 286/265": {
  "en": "CLASSIFIED FILE · SOURCE 286/265",
  "es": "EXPEDIENTE CLASIFICADO · FUENTE 286/265",
  "it": "FASCICOLO CLASSIFICATO · SORGENTE 286/265",
  "ca": "EXPEDIENT CLASSIFICAT · FONT 286/265",
  "ar": "ملف مصنَّف · المصدر 286/265"
 },
 "DOSSIER PERSONNEL — ACCÈS AUTORISÉ": {
  "en": "PERSONAL FILE — ACCESS GRANTED",
  "es": "EXPEDIENTE PERSONAL — ACCESO AUTORIZADO",
  "it": "FASCICOLO PERSONALE — ACCESSO AUTORIZZATO",
  "ca": "EXPEDIENT PERSONAL — ACCÉS AUTORITZAT",
  "ar": "ملف شخصي — وصول مسموح"
 },
 "Dossier source — Le Fragment Zéro": {
  "en": "Source file — The Zero Fragment",
  "es": "Expediente fuente — El Fragmento Cero",
  "it": "Fascicolo sorgente — Il Frammento Zero",
  "ca": "Expedient font — El Fragment Zero",
  "ar": "الملف المصدر — الجزء صفر"
 },
 "DOSSIERS CLASSIFIÉS": {
  "en": "CLASSIFIED FILES",
  "es": "EXPEDIENTES CLASIFICADOS",
  "it": "FASCICOLI CLASSIFICATI",
  "ca": "EXPEDIENTS CLASSIFICATS",
  "ar": "ملفات مصنَّفة"
 },
 "Dr Voss": {
  "en": "Dr Voss",
  "es": "Dr. Voss",
  "it": "Dott. Voss",
  "ca": "Dr. Voss",
  "ar": "د. فوس"
 },
 "DR VOSS": {
  "en": "DR VOSS",
  "es": "DR. VOSS",
  "it": "DOTT. VOSS",
  "ca": "DR. VOSS",
  "ar": "د. فوس"
 },
 "Dr Voss ? Comment êtes-vous entré sur cette fréquence ?": {
  "en": "Dr Voss? How did you get onto this frequency?",
  "es": "¿Dr. Voss? ¿Cómo ha entrado en esta frecuencia?",
  "it": "Dott. Voss? Come è entrato su questa frequenza?",
  "ca": "Dr. Voss? Com ha entrat en aquesta freqüència?",
  "ar": "د. فوس؟ كيف دخلت على هذه الترددات؟"
 },
 "du Point Zéro": {
  "en": "of Point Zero",
  "es": "del Punto Cero",
  "it": "del Punto Zero",
  "ca": "del Punt Zero",
  "ar": "للنقطة صفر"
 },
 "Du remords.": {
  "en": "Remorse.",
  "es": "Remordimiento.",
  "it": "Rimorso.",
  "ca": "Remordiment.",
  "ar": "الندم."
 },
 "Ducky": {
  "en": "Ducky",
  "es": "Ducky",
  "it": "Ducky",
  "ca": "Ducky",
  "ar": "دكي"
 },
 "DUCKY": {
  "en": "DUCKY",
  "es": "DUCKY",
  "it": "DUCKY",
  "ca": "DUCKY",
  "ar": "دكي"
 },
 "DUCKY :": {
  "en": "DUCKY:",
  "es": "DUCKY:",
  "it": "DUCKY:",
  "ca": "DUCKY:",
  "ar": "دكي:"
 },
 "Ducky connaît les ruines, les passages oubliés et les endroits où la réalité se comporte bizarrement. Il remarque les détails que les autres négligent : une ombre qui tombe dans la mauvaise direction, un bâtiment qui semble avoir changé de place, une voix entendue avant que la radio ne s'allume. Il utilise parfois l'humour pour détendre le groupe, mais il devient très sérieux dès qu'une anomalie se répète.": {
  "en": "Ducky knows ruins, forgotten passages and places where reality behaves strangely. He notices details others overlook: a shadow falling the wrong way, a building that seems to have changed place, a voice heard before the radio switches on. He sometimes uses humour to ease the group, but he becomes very serious as soon as an anomaly repeats.",
  "es": "Ducky conoce las ruinas, los pasajes olvidados y los lugares donde la realidad se comporta de forma extraña. Se fija en detalles que otros pasan por alto: una sombra que cae en la dirección equivocada, un edificio que parece haber cambiado de lugar, una voz oída antes de que se encienda la radio. A veces usa el humor para distender al grupo, pero se vuelve muy serio en cuanto una anomalía se repite.",
  "it": "Ducky conosce le rovine, i passaggi dimenticati e i luoghi in cui la realtà si comporta in modo strano. Nota dettagli che gli altri trascurano: un'ombra che cade nella direzione sbagliata, un edificio che sembra aver cambiato posto, una voce sentita prima che la radio si accenda. A volte usa l'umorismo per allentare il gruppo, ma diventa molto serio appena un'anomalia si ripete.",
  "ca": "En Ducky coneix les ruïnes, els passatges oblidats i els llocs on la realitat es comporta d'una manera estranya. S'adona de detalls que els altres passen per alt: una ombra que cau en la direcció equivocada, un edifici que sembla haver canviat de lloc, una veu sentida abans que s'encengui la ràdio. De vegades fa servir l'humor per distendre el grup, però es torna molt seriós tan bon punt una anomalia es repeteix.",
  "ar": "يعرف دكي الأطلال والممرات المنسية والأماكن التي يتصرف فيها الواقع بغرابة. يلاحظ التفاصيل التي يغفلها الآخرون: ظلًّا يسقط في الاتجاه الخاطئ، مبنى يبدو أنه غيّر مكانه، صوتًا يُسمع قبل أن يعمل الراديو. يستخدم أحيانًا الفكاهة لتخفيف توتر المجموعة، لكنه يصبح جديًّا جدًّا بمجرد تكرار أي شذوذ."
 },
 "Ducky connaît les ruines, les passages oubliés et les endroits où la réalité se comporte bizarrement. Il remarque les détails que les autres négligent : une ombre qui tombe dans la mauvaise…": {
  "en": "Ducky knows ruins, forgotten passages and places where reality behaves strangely. He notices details others overlook: a shadow falling the wrong way…",
  "es": "Ducky conoce las ruinas, los pasajes olvidados y los lugares donde la realidad se comporta de forma extraña. Se fija en detalles que otros pasan por alto: una sombra que cae en la dirección equivocada…",
  "it": "Ducky conosce le rovine, i passaggi dimenticati e i luoghi in cui la realtà si comporta in modo strano. Nota dettagli che gli altri trascurano: un'ombra che cade nella direzione sbagliata…",
  "ca": "En Ducky coneix les ruïnes, els passatges oblidats i els llocs on la realitat es comporta d'una manera estranya. S'adona de detalls que els altres passen per alt: una ombra que cau en la direcció equivocada…",
  "ar": "يعرف دكي الأطلال والممرات المنسية والأماكن التي يتصرف فيها الواقع بغرابة. يلاحظ التفاصيل التي يغفلها الآخرون: ظلًّا يسقط في الاتجاه الخاطئ…"
 },
 "ÉCHEC : LA SOURCE A COUPÉ LA CONNEXION. NOUVELLE TENTATIVE IMPOSSIBLE.": {
  "en": "FAILURE: THE SOURCE CUT THE CONNECTION. NEW ATTEMPT IMPOSSIBLE.",
  "es": "FALLO: LA FUENTE HA CORTADO LA CONEXIÓN. NUEVO INTENTO IMPOSIBLE.",
  "it": "ERRORE: LA FONTE HA INTERROTTO LA CONNESSIONE. NUOVO TENTATIVO IMPOSSIBILE.",
  "ca": "ERROR: LA FONT HA TALLAT LA CONNEXIÓ. NOU INTENT IMPOSSIBLE.",
  "ar": "فشل: قطع المصدر الاتصال. لا يمكن المحاولة مجددًا."
 },
 "ÉCOUTER": {
  "en": "LISTEN",
  "es": "ESCUCHAR",
  "it": "ASCOLTA",
  "ca": "ESCOLTA",
  "ar": "استمع"
 },
 "elle a découvert un fichier daté du lendemain, signé par un membre du groupe qui affirme ne pas avoir survécu à cette journée.": {
  "en": "she discovered a file dated the following day, signed by a team member who claims not to have survived that day.",
  "es": "descubrió un archivo fechado al día siguiente, firmado por un miembro del grupo que afirma no haber sobrevivido a ese día.",
  "it": "ha scoperto un file datato al giorno successivo, firmato da un membro del gruppo che afferma di non essere sopravvissuto a quel giorno.",
  "ca": "va descobrir un fitxer datat l’endemà, signat per un membre del grup que afirma no haver sobreviscut a aquell dia.",
  "ar": "اكتشفت ملفًّا بتاريخ اليوم التالي، موقَّعًا من عضو في المجموعة يؤكد أنه لم ينجُ من ذلك اليوم."
 },
 "Elle accompagne Ben parce qu'elle sait qu'il ne renoncera pas à Aidan, mais elle garde une copie de chaque découverte au cas où le groupe serait séparé. Elle ne dit pas tout ce qu'elle trouve : certains fichiers pourraient briser la confiance entre les survivants avant qu'ils aient compris ce qu'ils signifient.": {
  "en": "She accompanies Ben because she knows he will not give up on Aidan, but she keeps a copy of every discovery in case the group is separated. She does not tell everything she finds: some files could shatter the trust between survivors before they understand what they mean.",
  "es": "Acompaña a Ben porque sabe que no renunciará a Aidan, pero guarda una copia de cada descubrimiento por si el grupo se separa. No cuenta todo lo que encuentra: algunos archivos podrían romper la confianza entre los supervivientes antes de que hayan comprendido lo que significan.",
  "it": "Accompagna Ben perché sa che non rinuncerà ad Aidan, ma conserva una copia di ogni scoperta nel caso il gruppo si separi. Non dice tutto ciò che trova: alcuni file potrebbero spezzare la fiducia tra i sopravvissuti prima che abbiano capito cosa significano.",
  "ca": "Acompanya en Ben perquè sap que no renunciarà a l'Aidan, però guarda una còpia de cada descoberta per si el grup es separa. No diu tot el que troba: alguns fitxers podrien trencar la confiança entre els supervivents abans que hagin entès què signifiquen.",
  "ar": "ترافق بن لأنها تعلم أنه لن يتخلى عن أيدن، لكنها تحتفظ بنسخة من كل اكتشاف في حال انفصال المجموعة. لا تقول كل ما تجده: بعض الملفات قد تهزّ الثقة بين الناجين قبل أن يفهموا معناها."
 },
 "elle connaît le véritable nom du Vide et semble être liée au même endroit mystérieux que lui.": {
  "en": "she knows the Void's true name and seems linked to the same mysterious place as him.",
  "es": "conoce el verdadero nombre del Vacío y parece estar ligada al mismo lugar misterioso que él.",
  "it": "conosce il vero nome del Vuoto e sembra legata allo stesso luogo misterioso in cui è lui.",
  "ca": "coneix el veritable nom del Buit i sembla lligada al mateix lloc misteriós que ell.",
  "ar": "تعرف الاسم الحقيقي للفراغ ويبدو أنها مرتبطة بالمكان الغامض نفسه الذي يرتبط به."
 },
 "Elle dit s’appeler Olie": {
  "en": "She says her name is Olie",
  "es": "Dice llamarse Olie",
  "it": "Dice di chiamarsi Olie",
  "ca": "Diu que es diu Olie",
  "ar": "تقول إن اسمها أولي"
 },
 "elle est plus grande que Jean, mais son arrivée n’est pas imminente.": {
  "en": "it is greater than Jean, but its arrival is not imminent.",
  "es": "es mayor que Jean, pero su llegada no es inminente.",
  "it": "è più grande di Jean, ma il suo arrivo non è imminente.",
  "ca": "és més gran que en Jean, però la seva arribada no és imminent.",
  "ar": "إنه أكبر من جان، لكن وصوله ليس وشيكًا."
 },
 "Elle revient avec un message de la part du Vide : il ne veut plus se battre et souhaite retrouver sa véritable identité. Olie ne demande pas aux survivants de lui pardonner. Elle leur demande de l'aider à retrouver Jean, toujours prisonnier d'une réalité inaccessible.": {
  "en": "She returns with a message from the Void: he no longer wants to fight and wishes to recover his true identity. Olie does not ask the survivors to forgive him. She asks them to help her find Jean, still trapped in an unreachable reality.",
  "es": "Vuelve con un mensaje del Vacío: ya no quiere luchar y desea recuperar su verdadera identidad. Olie no pide a los supervivientes que lo perdonen. Les pide que la ayuden a encontrar a Jean, aún prisionero de una realidad inaccesible.",
  "it": "Torna con un messaggio dal Vuoto: non vuole più combattere e desidera ritrovare la sua vera identità. Olie non chiede ai sopravvissuti di perdonarlo. Chiede loro di aiutarla a ritrovare Jean, ancora prigioniero di una realtà inaccessibile.",
  "ca": "Torna amb un missatge del Buit: ja no vol lluitar i desitja recuperar la seva veritable identitat. L'Olie no demana als supervivents que el perdonin. Els demana que l'ajudin a retrobar en Jean, encara presoner d'una realitat inaccessible.",
  "ar": "تعود برسالة من الفراغ: لم يعد يريد القتال ويرغب في استعادة هويته الحقيقية. لا تطلب أولي من الناجين أن يغفروا له. بل تطلب منهم مساعدتها في إيجاد جان، الذي لا يزال أسير واقع يستحيل الوصول إليه."
 },
 "Enfin, tu commences à comprendre.": {
  "en": "At last, you are starting to understand.",
  "es": "Por fin empiezas a comprender.",
  "it": "Finalmente cominci a capire.",
  "ca": "Per fi comences a comprendre.",
  "ar": "أخيرًا، بدأت تفهم."
 },
 "ENREGISTREMENT": {
  "en": "RECORDING",
  "es": "GRABACIÓN",
  "it": "REGISTRAZIONE",
  "ca": "ENREGISTRAMENT",
  "ar": "تسجيل"
 },
 "Ensemble de bâtiments dans le sud-ouest.": {
  "en": "Group of buildings in the south-west.",
  "es": "Conjunto de edificios en el suroeste.",
  "it": "Insieme di edifici a sud-ovest.",
  "ca": "Conjunt d'edificis al sud-oest.",
  "ar": "مجموعة مبانٍ في الجنوب الغربي."
 },
 "ENTENDS": {
  "en": "HEAR ME",
  "es": "ESCUCHAS",
  "it": "SENTI",
  "ca": "SENTS",
  "ar": "تسمعني"
 },
 "ENTITÉ — IDENTITÉ RESTITUÉE": {
  "en": "ENTITY — IDENTITY RESTORED",
  "es": "ENTIDAD — IDENTIDAD RESTITUIDA",
  "it": "ENTITÀ — IDENTITÀ RESTITUITA",
  "ca": "ENTITAT — IDENTITAT RESTITUÏDA",
  "ar": "كيان — هوية مُستعادة"
 },
 "Entre des commandes, retrouve les fragments et déverrouille des indices.": {
  "en": "Enter commands, find the fragments and unlock clues.",
  "es": "Introduce comandos, encuentra los fragmentos y desbloquea pistas.",
  "it": "Inserisci comandi, ritrova i frammenti e sblocca indizi.",
  "ca": "Introdueix comandes, troba els fragments i desbloqueja pistes.",
  "ar": "أدخل الأوامر، اعثر على الشظايا وافتح الأدلة."
 },
 "ENTRE-TEMPS : L'ÉQUIPE S'AGRANDIT": {
  "en": "MEANWHILE: THE TEAM GROWS",
  "es": "MIENTRAS TANTO: EL EQUIPO CRECE",
  "it": "NEL FRATTEMPO: LA SQUADRA CRESCE",
  "ca": "MENTRESTANT: L’EQUIP CREIX",
  "ar": "في الأثناء: الفريق يكبر"
 },
 "Esclate Root": {
  "en": "Esclate Root",
  "es": "Esclate Root",
  "it": "Esclate Root",
  "ca": "Esclate Root",
  "ar": "Esclate Root"
 },
 "Et DECA lui fournit les moyens de localiser les survivants entre les réalités.": {
  "en": "And DECA gives him the means to locate survivors between realities.",
  "es": "Y DECA le proporciona los medios para localizar a los supervivientes entre realidades.",
  "it": "E DECA gli fornisce i mezzi per localizzare i sopravvissuti tra le realtà.",
  "ca": "I DECA li dona els mitjans per localitzar els supervivents entre realitats.",
  "ar": "وDECA تمنحه الوسائل لتحديد مواقع الناجين بين الأواقع."
 },
 "Et Jean, dans tout ça ?": {
  "en": "And Jean, in all this?",
  "es": "¿Y Jean, en todo esto?",
  "it": "E Jean, in tutto questo?",
  "ca": "I en Jean, en tot això?",
  "ar": "وجان، في كل هذا؟"
 },
 "Et pourquoi on te ferait confiance ?": {
  "en": "And why should we trust you?",
  "es": "¿Y por qué deberíamos confiar en ti?",
  "it": "E perché dovremmo fidarci di te?",
  "ca": "I per què hauríem de confiar en tu?",
  "ar": "ولماذا يجب أن نثق بك؟"
 },
 "Et qu'est-ce qui nous attend là-bas ?": {
  "en": "And what awaits us there?",
  "es": "¿Y qué nos espera allí?",
  "it": "E che cosa ci aspetta là?",
  "ca": "I què ens espera allà?",
  "ar": "وما الذي ينتظرنا هناك؟"
 },
 "ÉTAT : LIBÉRÉ": {
  "en": "STATUS: RELEASED",
  "es": "ESTADO: LIBERADO",
  "it": "STATO: LIBERATO",
  "ca": "ESTAT: ALLIBERAT",
  "ar": "الحالة: محرَّر"
 },
 "ÉTAT ACTIF": {
  "en": "ACTIVE STATUS",
  "es": "ESTADO ACTIVO",
  "it": "STATO ATTIVO",
  "ca": "ESTAT ACTIU",
  "ar": "الحالة نشطة"
 },
 "ÉTAT DE L'ÎLE": {
  "en": "ISLAND STATUS",
  "es": "ESTADO DE LA ISLA",
  "it": "STATO DELL’ISOLA",
  "ca": "ESTAT DE L’ILLA",
  "ar": "حالة الجزيرة"
 },
 "ÉTAT DU DOSSIER :": {
  "en": "FILE STATUS:",
  "es": "ESTADO DEL EXPEDIENTE:",
  "it": "STATO DEL FASCICOLO:",
  "ca": "ESTAT DE L’EXPEDIENT:",
  "ar": "حالة الملف:"
 },
 "ÉTAT DU POINT ZÉRO": {
  "en": "POINT ZERO STATUS",
  "es": "ESTADO DEL PUNTO CERO",
  "it": "STATO DEL PUNTO ZERO",
  "ca": "ESTAT DEL PUNT ZERO",
  "ar": "حالة النقطة صفر"
 },
 "EXÉCUTER": {
  "en": "RUN",
  "es": "EJECUTAR",
  "it": "ESEGUI",
  "ca": "EXECUTA",
  "ar": "تنفيذ"
 },
 "EXPLORER L'ÎLE": {
  "en": "EXPLORE THE ISLAND",
  "es": "EXPLORAR LA ISLA",
  "it": "ESPLORA L’ISOLA",
  "ca": "EXPLORA L’ILLA",
  "ar": "استكشف الجزيرة"
 },
 "Explorer la carte S8 →": {
  "en": "Explore the S8 map →",
  "es": "Explorar el mapa T8 →",
  "it": "Esplora la mappa S8 →",
  "ca": "Explora el mapa T8 →",
  "ar": "استكشف خريطة الموسم 8 →"
 },
 "EXPLORER LES 15 SECTEURS": {
  "en": "EXPLORE THE 15 SECTORS",
  "es": "EXPLORAR LOS 15 SECTORES",
  "it": "ESPLORA I 15 SETTORI",
  "ca": "EXPLORA ELS 15 SECTORS",
  "ar": "استكشف القطاعات الـ15"
 },
 "Facile à dire, après tout ce qu'il a effacé.": {
  "en": "Easy to say, after everything he erased.",
  "es": "Fácil de decir, después de todo lo que borró.",
  "it": "Facile da dire, dopo tutto ciò che ha cancellato.",
  "ca": "Fàcil de dir, després de tot el que va esborrar.",
  "ar": "سهل القول، بعد كل ما محاه."
 },
 "FAN-FICTION NON OFFICIELLE INSPIRÉE DE FORTNITE.": {
  "en": "UNOFFICIAL FAN FICTION INSPIRED BY FORTNITE.",
  "es": "FAN FICTION NO OFICIAL INSPIRADA EN FORTNITE.",
  "it": "FAN FICTION NON UFFICIALE ISPIRATA A FORTNITE.",
  "ca": "FAN FICCIÓ NO OFICIAL INSPIRADA EN FORTNITE.",
  "ar": "قصة غير رسمية مستوحاة من فورتنايت."
 },
 "Fermer le dossier": {
  "en": "Close the file",
  "es": "Cerrar el expediente",
  "it": "Chiudi il fascicolo",
  "ca": "Tanca l’expedient",
  "ar": "إغلاق الملف"
 },
 "Fermer le menu": {
  "en": "Close menu",
  "es": "Cerrar el menú",
  "it": "Chiudi il menu",
  "ca": "Tanca el menú",
  "ar": "إغلاق القائمة"
 },
 "FICHIER 001": {
  "en": "FILE 001",
  "es": "ARCHIVO 001",
  "it": "FILE 001",
  "ca": "FITXER 001",
  "ar": "الملف 001"
 },
 "FICHIER 001 / RÉALITÉ 265": {
  "en": "FILE 001 / REALITY 265",
  "es": "ARCHIVO 001 / REALIDAD 265",
  "it": "FILE 001 / REALTÀ 265",
  "ca": "FITXER 001 / REALITAT 265",
  "ar": "الملف 001 / الواقع 265"
 },
 "Fichiers : fragment_005, fragment_006, fragment_007, fragment_008, fragment_009, fragment_010 à fragment_020. Dossier temporel : KAEL. Nouveau dossier : SIGNAL FREAKY ZERO.": {
  "en": "Files: fragment_005, fragment_006, fragment_007, fragment_008, fragment_009, fragment_010 to fragment_020. Temporal file: KAEL. New file: SIGNAL FREAKY ZERO.",
  "es": "Archivos: fragment_005, fragment_006, fragment_007, fragment_008, fragment_009, fragment_010 a fragment_020. Expediente temporal: KAEL. Nuevo expediente: SIGNAL FREAKY ZERO.",
  "it": "File: fragment_005, fragment_006, fragment_007, fragment_008, fragment_009, da fragment_010 a fragment_020. Fascicolo temporale: KAEL. Nuovo fascicolo: SIGNAL FREAKY ZERO.",
  "ca": "Fitxers: fragment_005, fragment_006, fragment_007, fragment_008, fragment_009, de fragment_010 a fragment_020. Expedient temporal: KAEL. Nou expedient: SIGNAL FREAKY ZERO.",
  "ar": "الملفات: fragment_005, fragment_006, fragment_007, fragment_008, fragment_009, من fragment_010 إلى fragment_020. الملف الزمني: KAEL. ملف جديد: SIGNAL FREAKY ZERO."
 },
 "FIN DU DOSSIER · SAISON 8 EN COURS": {
  "en": "END OF FILE · SEASON 8 IN PROGRESS",
  "es": "FIN DEL EXPEDIENTE · TEMPORADA 8 EN CURSO",
  "it": "FINE DEL FASCICOLO · STAGIONE 8 IN CORSO",
  "ca": "FI DE L’EXPEDIENT · TEMPORADA 8 EN CURS",
  "ar": "نهاية الملف · الموسم 8 جارٍ"
 },
 "FIN DU DOSSIER SOURCE · ACCÈS ENREGISTRÉ": {
  "en": "END OF SOURCE FILE · ACCESS RECORDED",
  "es": "FIN DEL EXPEDIENTE FUENTE · ACCESO REGISTRADO",
  "it": "FINE DEL FASCICOLO SORGENTE · ACCESSO REGISTRATO",
  "ca": "FI DE L'EXPEDIENT FONT · ACCÉS ENREGISTRAT",
  "ar": "نهاية الملف المصدر · تم تسجيل الوصول"
 },
 "FRAGMENT 005 — RÉALITÉ UNIQUE": {
  "en": "FRAGMENT 005 — SINGLE REALITY",
  "es": "FRAGMENTO 005 — REALIDAD ÚNICA",
  "it": "FRAMMENTO 005 — REALTÀ UNICA",
  "ca": "FRAGMENT 005 — REALITAT ÚNICA",
  "ar": "الشظية 005 — واقع واحد"
 },
 "FRAGMENT 005 : Jean veut imposer une réalité unique.": {
  "en": "FRAGMENT 005: Jean wants to impose a single reality.",
  "es": "FRAGMENTO 005: Jean quiere imponer una realidad única.",
  "it": "FRAMMENTO 005: Jean vuole imporre un’unica realtà.",
  "ca": "FRAGMENT 005: En Jean vol imposar una realitat única.",
  "ar": "الشظية 005: جان يريد فرض واقع واحد."
 },
 "FRAGMENT 006 — L'OBSERVATEUR": {
  "en": "FRAGMENT 006 — THE OBSERVER",
  "es": "FRAGMENTO 006 — EL OBSERVADOR",
  "it": "FRAMMENTO 006 — L'OSSERVATORE",
  "ca": "FRAGMENT 006 — L'OBSERVADOR",
  "ar": "الشظية 006 — المراقب"
 },
 "FRAGMENT 006 : Quelqu’un observe les survivants.": {
  "en": "FRAGMENT 006: Someone is watching the survivors.",
  "es": "FRAGMENTO 006: Alguien observa a los supervivientes.",
  "it": "FRAMMENTO 006: Qualcuno osserva i sopravvissuti.",
  "ca": "FRAGMENT 006: Algú observa els supervivents.",
  "ar": "الشظية 006: أحدهم يراقب الناجين."
 },
 "FRAGMENT 007 — SIGNAL BLEU": {
  "en": "FRAGMENT 007 — BLUE SIGNAL",
  "es": "FRAGMENTO 007 — SEÑAL AZUL",
  "it": "FRAMMENTO 007 — SEGNALE BLU",
  "ca": "FRAGMENT 007 — SENYAL BLAU",
  "ar": "الشظية 007 — الإشارة الزرقاء"
 },
 "FRAGMENT 007 : Signal bleu actif. Une transmission porte la signature d’Aidan.": {
  "en": "FRAGMENT 007: Blue signal active. A transmission carries Aidan’s signature.",
  "es": "FRAGMENTO 007: Señal azul activa. Una transmisión lleva la firma de Aidan.",
  "it": "FRAMMENTO 007: Segnale blu attivo. Una trasmissione porta la firma di Aidan.",
  "ca": "FRAGMENT 007: Senyal blau actiu. Una transmissió porta la signatura d’Aidan.",
  "ar": "الشظية 007: الإشارة الزرقاء نشطة. بثٌّ يحمل توقيع أيدن."
 },
 "FRAGMENT 008 — AIDAN EST VIVANT ?": {
  "en": "FRAGMENT 008 — AIDAN IS ALIVE?",
  "es": "FRAGMENTO 008 — ¿AIDAN ESTÁ VIVO?",
  "it": "FRAMMENTO 008 — AIDAN È VIVO?",
  "ca": "FRAGMENT 008 — L'AIDAN ÉS VIU?",
  "ar": "الشظية 008 — هل أيدن حي؟"
 },
 "FRAGMENT 008 : Une partie du système d’Aidan répond encore. Identité non confirmée.": {
  "en": "FRAGMENT 008: Part of Aidan’s system still responds. Identity unconfirmed.",
  "es": "FRAGMENTO 008: Parte del sistema de Aidan sigue respondiendo. Identidad no confirmada.",
  "it": "FRAMMENTO 008: Parte del sistema di Aidan risponde ancora. Identità non confermata.",
  "ca": "FRAGMENT 008: Part del sistema d’Aidan encara respon. Identitat no confirmada.",
  "ar": "الشظية 008: جزء من نظام أيدن لا يزال يستجيب. الهوية غير مؤكدة."
 },
 "FRAGMENT 009 — RETOUR IMPOSSIBLE": {
  "en": "FRAGMENT 009 — IMPOSSIBLE RETURN",
  "es": "FRAGMENTO 009 — RETORNO IMPOSIBLE",
  "it": "FRAMMENTO 009 — RITORNO IMPOSSIBILE",
  "ca": "FRAGMENT 009 — RETORN IMPOSSIBLE",
  "ar": "الشظية 009 — عودة مستحيلة"
 },
 "FRAGMENT 009 : Une silhouette ressemblant à Jean a été détectée dans la faille.": {
  "en": "FRAGMENT 009: A figure resembling Jean was detected in the rift.",
  "es": "FRAGMENTO 009: Se detectó una silueta parecida a Jean en la falla.",
  "it": "FRAMMENTO 009: Una sagoma simile a Jean è stata rilevata nella faglia.",
  "ca": "FRAGMENT 009: S’ha detectat una silueta semblant a en Jean a l’escletxa.",
  "ar": "الشظية 009: رُصد ظلٌّ يشبه جان في الصدع."
 },
 "FRAGMENT 010 — ARRIVÉE TEMPORELLE": {
  "en": "FRAGMENT 010 — TEMPORAL ARRIVAL",
  "es": "FRAGMENTO 010 — LLEGADA TEMPORAL",
  "it": "FRAMMENTO 010 — ARRIVO TEMPORALE",
  "ca": "FRAGMENT 010 — ARRIBADA TEMPORAL",
  "ar": "الشظية 010 — وصول زمني"
 },
 "FRAGMENT 010 : Un individu nommé KAEL est arrivé sur l’île grâce à une machine temporelle. Signature temporelle confirmée.": {
  "en": "FRAGMENT 010: An individual named KAEL arrived on the island via a time machine. Temporal signature confirmed.",
  "es": "FRAGMENTO 010: Un individuo llamado KAEL llegó a la isla mediante una máquina del tiempo. Firma temporal confirmada.",
  "it": "FRAMMENTO 010: Un individuo di nome KAEL è arrivato sull’isola grazie a una macchina del tempo. Firma temporale confermata.",
  "ca": "FRAGMENT 010: Un individu anomenat KAEL va arribar a l’illa gràcies a una màquina del temps. Signatura temporal confirmada.",
  "ar": "الشظية 010: فرد يُدعى كايل وصل إلى الجزيرة عبر آلة زمن. تم تأكيد التوقيع الزمني."
 },
 "FRAGMENT 011 — ANCIEN ALLIÉ": {
  "en": "FRAGMENT 011 — FORMER ALLY",
  "es": "FRAGMENTO 011 — ANTIGUO ALIADO",
  "it": "FRAMMENTO 011 — VECCHIO ALLEATO",
  "ca": "FRAGMENT 011 — ANTIC ALIAT",
  "ar": "الشظية 011 — حليف سابق"
 },
 "FRAGMENT 011 : KAEL et JEAN ont autrefois été des amis proches. Une dispute ancienne a mis fin à leur relation.": {
  "en": "FRAGMENT 011: KAEL and JEAN were once close friends. An old dispute ended their relationship.",
  "es": "FRAGMENTO 011: KAEL y JEAN fueron amigos cercanos. Una antigua disputa terminó su relación.",
  "it": "FRAMMENTO 011: KAEL e JEAN erano un tempo amici stretti. Un’antica lite pose fine al loro rapporto.",
  "ca": "FRAGMENT 011: KAEL i JEAN van ser amics propers. Una disputa antiga va acabar amb la seva relació.",
  "ar": "الشظية 011: كايل وجان كانا صديقين مقرَّبين. خلاف قديم أنهى علاقتهما."
 },
 "FRAGMENT 012 — LIEN AVEC OLIE": {
  "en": "FRAGMENT 012 — LINK WITH OLIE",
  "es": "FRAGMENTO 012 — VÍNCULO CON OLIE",
  "it": "FRAMMENTO 012 — LEGAME CON OLIE",
  "ca": "FRAGMENT 012 — VINCLE AMB L'OLIE",
  "ar": "الشظية 012 — الصلة بأولي"
 },
 "FRAGMENT 012 : Olie et Kael se connaissent. Ils ont partagé une aventure dont les détails ne figurent pas dans les archives.": {
  "en": "FRAGMENT 012: Olie and Kael know each other. They shared an adventure whose details appear in no archive.",
  "es": "FRAGMENTO 012: Olie y Kael se conocen. Compartieron una aventura cuyos detalles no figuran en los archivos.",
  "it": "FRAMMENTO 012: Olie e Kael si conoscono. Hanno condiviso un’avventura i cui dettagli non compaiono negli archivi.",
  "ca": "FRAGMENT 012: L’Olie i en Kael es coneixen. Van compartir una aventura els detalls de la qual no figuren als arxius.",
  "ar": "الشظية 012: أولي وكايل يعرفان بعضهما. شاركا مغامرة لا ترد تفاصيلها في الأرشيف."
 },
 "FRAGMENT 013 — LE SANCTUAIRE ROSE-VIOLET": {
  "en": "FRAGMENT 013 — THE PINK-VIOLET SANCTUARY",
  "es": "FRAGMENTO 013 — EL SANTUARIO ROSA-VIOLETA",
  "it": "FRAMMENTO 013 — IL SANTUARIO ROSA-VIOLA",
  "ca": "FRAGMENT 013 — EL SANTUARI ROSA-VIOLETA",
  "ar": "الشظية 013 — الملاذ الوردي البنفسجي"
 },
 "FRAGMENT 013 : Le fragment rose-violet est apparu au centre d’un sanctuaire circulaire bleu. Les alliés l’ont récupéré avant Jean.": {
  "en": "FRAGMENT 013: The pink-violet fragment appeared at the centre of a circular blue sanctuary. The allies recovered it before Jean.",
  "es": "FRAGMENTO 013: El fragmento rosa-violeta apareció en el centro de un santuario circular azul. Los aliados lo recuperaron antes que Jean.",
  "it": "FRAMMENTO 013: Il frammento rosa-viola è apparso al centro di un santuario circolare blu. Gli alleati lo hanno recuperato prima di Jean.",
  "ca": "FRAGMENT 013: El fragment rosa-violaci va aparèixer al centre d’un santuari circular blau. Els aliats el van recuperar abans que en Jean.",
  "ar": "الشظية 013: ظهرت الشظية الوردية البنفسجية في مركز ملاذ أزرق دائري. استرجعه الحلفاء قبل جان."
 },
 "FRAGMENT 014 — DERNIER ÉCLAT": {
  "en": "FRAGMENT 014 — LAST SHARD",
  "es": "FRAGMENTO 014 — ÚLTIMO DESTELLO",
  "it": "FRAMMENTO 014 — ULTIMO FRAMMENTO",
  "ca": "FRAGMENT 014 — ÚLTIM ESCLAT",
  "ar": "الشظية 014 — الوميض الأخير"
 },
 "FRAGMENT 014 : Le dernier fragment du deuxième Point Zéro a permis aux alliés de vaincre Jean.": {
  "en": "FRAGMENT 014: The last fragment of the second Point Zero allowed the allies to defeat Jean.",
  "es": "FRAGMENTO 014: El último fragmento del segundo Punto Cero permitió a los aliados vencer a Jean.",
  "it": "FRAMMENTO 014: L’ultimo frammento del secondo Punto Zero permise agli alleati di sconfiggere Jean.",
  "ca": "FRAGMENT 014: L’últim fragment del segon Punt Zero va permetre als aliats vèncer en Jean.",
  "ar": "الشظية 014: الشظية الأخيرة من النقطة صفر الثانية مكَّنت الحلفاء من هزيمة جان."
 },
 "FRAGMENT 015 — MACHINE DÉTRUITE": {
  "en": "FRAGMENT 015 — DESTROYED MACHINE",
  "es": "FRAGMENTO 015 — MÁQUINA DESTRUIDA",
  "it": "FRAMMENTO 015 — MACCHINA DISTRUTTA",
  "ca": "FRAGMENT 015 — MÀQUINA DESTRUÏDA",
  "ar": "الشظية 015 — الآلة المدمَّرة"
 },
 "FRAGMENT 015 : La lumière dans le ciel était la machine de Jean détruite. Jean s’est désintégré en étoile. Aucun signal de menace.": {
  "en": "FRAGMENT 015: The light in the sky was Jean’s destroyed machine. Jean disintegrated into a star. No threat signal detected.",
  "es": "FRAGMENTO 015: La luz en el cielo era la máquina destruida de Jean. Jean se desintegró en estrella. Ninguna señal de amenaza.",
  "it": "FRAMMENTO 015: La luce nel cielo era la macchina distrutta di Jean. Jean si è disintegrato in una stella. Nessun segnale di minaccia.",
  "ca": "FRAGMENT 015: La llum al cel era la màquina destruïda d’en Jean. En Jean es va desintegrar en estrella. Cap senyal d’amenaça.",
  "ar": "الشظية 015: الضوء في السماء كان آلة جان المدمَّرة. تحلَّل جان إلى نجمة. لا إشارة تهديد."
 },
 "FRAGMENT 016 — RESTAURATION": {
  "en": "FRAGMENT 016 — RESTORATION",
  "es": "FRAGMENTO 016 — RESTAURACIÓN",
  "it": "FRAMMENTO 016 — RESTAURO",
  "ca": "FRAGMENT 016 — RESTAURACIÓ",
  "ar": "الشظية 016 — الاستعادة"
 },
 "FRAGMENT 016 : Le Point Zéro a été libéré et certaines villes corrompues ont été restaurées. L’île est reconstruite.": {
  "en": "FRAGMENT 016: Point Zero was released and some corrupted cities were restored. The island has been rebuilt.",
  "es": "FRAGMENTO 016: El Punto Cero fue liberado y algunas ciudades corruptas fueron restauradas. La isla ha sido reconstruida.",
  "it": "FRAMMENTO 016: Il Punto Zero è stato liberato e alcune città corrotte sono state restaurate. L’isola è ricostruita.",
  "ca": "FRAGMENT 016: El Punt Zero va ser alliberat i algunes ciutats corruptes es van restaurar. L’illa ha estat reconstruïda.",
  "ar": "الشظية 016: حُرِّرت النقطة صفر واستُعيدت بعض المدن الفاسدة. أُعيد بناء الجزيرة."
 },
 "FRAGMENT 017 — ARRIVÉE DE KAEL": {
  "en": "FRAGMENT 017 — KAEL'S ARRIVAL",
  "es": "FRAGMENTO 017 — LLEGADA DE KAEL",
  "it": "FRAMMENTO 017 — ARRIVO DI KAEL",
  "ca": "FRAGMENT 017 — ARRIBADA D'EN KAEL",
  "ar": "الشظية 017 — وصول كايل"
 },
 "FRAGMENT 017 : Kael est arrivé par machine temporelle à la villa du lac. Ancien ami proche de Jean, il connaît aussi Olie.": {
  "en": "FRAGMENT 017: Kael arrived by time machine at the lake villa. A former close friend of Jean, he also knows Olie.",
  "es": "FRAGMENTO 017: Kael llegó en máquina del tiempo a la villa del lago. Antiguo amigo cercano de Jean, también conoce a Olie.",
  "it": "FRAMMENTO 017: Kael è arrivato con la macchina del tempo alla villa del lago. Ex amico stretto di Jean, conosce anche Olie.",
  "ca": "FRAGMENT 017: En Kael va arribar amb la màquina del temps a la vil·la del llac. Antic amic proper d’en Jean, també coneix l’Olie.",
  "ar": "الشظية 017: وصل كايل بآلة الزمن إلى فيلا البحيرة. صديق مقرَّب سابق لجان، ويعرف أولي أيضًا."
 },
 "FRAGMENT 018 : Une pulsation bleue a été détectée sous Freaky Zero. Sa signature ne correspond à aucun Point Zéro ni fragment connu.": {
  "en": "FRAGMENT 018: A blue pulse was detected beneath Freaky Zero. Its signature matches no known Point Zero or fragment.",
  "es": "FRAGMENTO 018: Se detectó una pulsación azul bajo Freaky Zero. Su firma no corresponde a ningún Punto Cero ni fragmento conocido.",
  "it": "FRAMMENTO 018: È stata rilevata una pulsazione blu sotto Freaky Zero. La sua firma non corrisponde a nessun Punto Zero né frammento noto.",
  "ca": "FRAGMENT 018: S’ha detectat una pulsació blava sota Freaky Zero. La seva signatura no correspon a cap Punt Zero ni fragment conegut.",
  "ar": "الشظية 018: رُصدت نبضة زرقاء تحت فريكي زيرو. توقيعها لا يطابق أي نقطة صفر أو شظية معروفة."
 },
 "FRAGMENT 019 : Les relevés indiquent une structure géométrique enfouie sous la forêt. Il pourrait s’agir d’un passage, mais aucune ouverture n’a été confirmée.": {
  "en": "FRAGMENT 019: The readings indicate a geometric structure buried beneath the forest. It could be a passage, but no opening has been confirmed.",
  "es": "FRAGMENTO 019: Las mediciones indican una estructura geométrica enterrada bajo el bosque. Podría ser un pasaje, pero no se ha confirmado ninguna abertura.",
  "it": "FRAMMENTO 019: Le rilevazioni indicano una struttura geometrica sepolta sotto la foresta. Potrebbe essere un passaggio, ma nessuna apertura è stata confermata.",
  "ca": "FRAGMENT 019: Els registres indiquen una estructura geomètrica enterrada sota el bosc. Podria ser un passatge, però no s’ha confirmat cap obertura.",
  "ar": "الشظية 019: تشير القياسات إلى بنية هندسية مدفونة تحت الغابة. قد تكون ممرًّا، لكن لم يُؤكَّد أي فتحة."
 },
 "FRAGMENT 020 : Le signal contient une phrase : « Vous avez libéré le Point Zéro. Mais vous n’avez jamais découvert ce qu’il retenait. » Source inconnue.": {
  "en": "FRAGMENT 020: The signal contains a sentence: « You freed Point Zero. But you never discovered what it was holding back. » Unknown source.",
  "es": "FRAGMENTO 020: La señal contiene una frase: « Habéis liberado el Punto Cero. Pero nunca descubristeis lo que retenía. » Fuente desconocida.",
  "it": "FRAMMENTO 020: Il segnale contiene una frase: « Avete liberato il Punto Zero. Ma non avete mai scoperto ciò che tratteneva. » Fonte sconosciuta.",
  "ca": "FRAGMENT 020: El senyal conté una frase: « Heu alliberat el Punt Zero. Però mai no heu descobert què retenia. » Font desconeguda.",
  "ar": "الشظية 020: تحتوي الإشارة على جملة: «لقد حرَّرتم النقطة صفر. لكنكم لم تكتشفوا قط ما كان يحتجزه.» مصدر مجهول."
 },
 "Fragment 020 · Enregistrement incomplet · Origine non déterminée": {
  "en": "Fragment 020 · Incomplete recording · Undetermined origin",
  "es": "Fragmento 020 · Grabación incompleta · Origen no determinado",
  "it": "Frammento 020 · Registrazione incompleta · Origine non determinata",
  "ca": "Fragment 020 · Enregistrament incomplet · Origen no determinat",
  "ar": "الشظية 020 · تسجيل غير كامل · أصل غير محدَّد"
 },
 "Fragments": {
  "en": "Fragments",
  "es": "Fragmentos",
  "it": "Frammenti",
  "ca": "Fragments",
  "ar": "الشظايا"
 },
 "Freaky Zero": {
  "en": "Freaky Zero",
  "es": "Freaky Zero",
  "it": "Freaky Zero",
  "ca": "Freaky Zero",
  "ar": "Freaky Zero"
 },
 "FREAKY ZERO": {
  "en": "FREAKY ZERO",
  "es": "FREAKY ZERO",
  "it": "FREAKY ZERO",
  "ca": "FREAKY ZERO",
  "ar": "FREAKY ZERO"
 },
 "Frenzy Gold": {
  "en": "Frenzy Gold",
  "es": "Frenzy Gold",
  "it": "Frenzy Gold",
  "ca": "Frenzy Gold",
  "ar": "Frenzy Gold"
 },
 "FRÉQUENCE INCONNUE": {
  "en": "UNKNOWN FREQUENCY",
  "es": "FRECUENCIA DESCONOCIDA",
  "it": "FREQUENZA SCONOSCIUTA",
  "ca": "FREQÜÈNCIA DESCONEGUDA",
  "ar": "تردد مجهول"
 },
 "Fui ? Lui ?": {
  "en": "Fled? Him?",
  "es": "¿Huyó? ¿Él?",
  "it": "Fuggito? Lui?",
  "ca": "Va fugir? Ell?",
  "ar": "هرب؟ هو؟"
 },
 "FZ": {
  "en": "FZ",
  "es": "FZ",
  "it": "FZ",
  "ca": "FZ",
  "ar": "FZ"
 },
 "Greasy Groove": {
  "en": "Greasy Groove",
  "es": "Greasy Groove",
  "it": "Greasy Groove",
  "ca": "Greasy Groove",
  "ar": "Greasy Groove"
 },
 "Hameau entouré de végétation à l’est.": {
  "en": "Hamlet surrounded by vegetation to the east.",
  "es": "Aldea rodeada de vegetación al este.",
  "it": "Borgo circondato dalla vegetazione a est.",
  "ca": "Llogaret envoltat de vegetació a l'est.",
  "ar": "قرية صغيرة تحيط بها النباتات شرقًا."
 },
 "Happy Nightmare": {
  "en": "Happy Nightmare",
  "es": "Happy Nightmare",
  "it": "Happy Nightmare",
  "ca": "Happy Nightmare",
  "ar": "Happy Nightmare"
 },
 "help": {
  "en": "help",
  "es": "help",
  "it": "help",
  "ca": "help",
  "ar": "help"
 },
 "hero.title": {
  "en": "THE FRAGMENT<br><em>ZERO</em>",
  "es": "EL FRAGMENTO<br><em>CERO</em>",
  "it": "IL FRAMMENTO<br><em>ZERO</em>",
  "ca": "EL FRAGMENT<br><em>ZERO</em>",
  "ar": "الجزء<br><em>صفر</em>"
 },
 "Histoire": {
  "en": "History",
  "es": "Historia",
  "it": "Storia",
  "ca": "Història",
  "ar": "التاريخ",
  "zh": "故事"
 },
 "Holliday Forge": {
  "en": "Holliday Forge",
  "es": "Holliday Forge",
  "it": "Holliday Forge",
  "ca": "Holliday Forge",
  "ar": "Holliday Forge"
 },
 "Holly Hedge": {
  "en": "Holly Hedge",
  "es": "Holly Hedge",
  "it": "Holly Hedge",
  "ca": "Holly Hedge",
  "ar": "Holly Hedge"
 },
 "Holy Hedge": {
  "en": "Holy Hedge",
  "es": "Holy Hedge",
  "it": "Holy Hedge",
  "ca": "Holy Hedge",
  "ar": "Holy Hedge"
 },
 "home.dir": {
  "en": "Everything begins <em>here.</em>",
  "es": "Todo empieza <em>aquí.</em>",
  "it": "Tutto comincia <em>qui.</em>",
  "ca": "Tot comença <em>aquí.</em>",
  "ar": "كل شيء يبدأ <em>هنا.</em>"
 },
 "home.event": {
  "en": "Something <br><em>answers beneath the island.</em>",
  "es": "Algo <br><em>responde bajo la isla.</em>",
  "it": "Qualcosa <br><em>risponde sotto l’isola.</em>",
  "ca": "Alguna cosa <br><em>respon sota l’illa.</em>",
  "ar": "شيءٌ ما <br><em>يجيب تحت الجزيرة.</em>"
 },
 "home.final": {
  "en": "« You freed Point Zero.<br><em>But you never discovered what it was holding back. »</em>",
  "es": "« Habéis liberado el Punto Cero.<br><em>Pero nunca descubristeis lo que retenía. »</em>",
  "it": "« Avete liberato il Punto Zero.<br><em>Ma non avete mai scoperto ciò che tratteneva. »</em>",
  "ca": "« Heu alliberat el Punt Zero.<br><em>Però mai no heu descobert què retenia. »</em>",
  "ar": "«لقد حرَّرتم النقطة صفر.<br><em>لكنكم لم تكتشفوا قط ما كان يحتجزه.»</em>"
 },
 "home.map": {
  "en": "One island. <em>Fifteen sectors.</em>",
  "es": "Una isla. <em>Quince sectores.</em>",
  "it": "Un’isola. <em>Quindici settori.</em>",
  "ca": "Una illa. <em>Quinze sectors.</em>",
  "ar": "جزيرة واحدة. <em>خمسة عشر قطاعًا.</em>"
 },
 "Hony Strip": {
  "en": "Hony Strip",
  "es": "Hony Strip",
  "it": "Hony Strip",
  "ca": "Hony Strip",
  "ar": "Hony Strip"
 },
 "Hotel Forest": {
  "en": "Hotel Forest",
  "es": "Hotel Forest",
  "it": "Hotel Forest",
  "ca": "Hotel Forest",
  "ar": "Hotel Forest"
 },
 "ici.": {
  "en": "here.",
  "es": "aquí.",
  "it": "qui.",
  "ca": "aquí.",
  "ar": "هنا."
 },
 "IDENTITÉ RÉVÉLÉE — FAMILLE": {
  "en": "IDENTITY REVEALED — FAMILY",
  "es": "IDENTIDAD REVELADA — FAMILIA",
  "it": "IDENTITÀ RIVELATA — FAMIGLIA",
  "ca": "IDENTITAT REVELADA — FAMÍLIA",
  "ar": "هوية مكشوفة — عائلة"
 },
 "Il a attaqué cette île.": {
  "en": "He attacked this island.",
  "es": "Él atacó esta isla.",
  "it": "Ha attaccato quest'isola.",
  "ca": "Ell va atacar aquesta illa.",
  "ar": "لقد هاجم هذه الجزيرة."
 },
 "Il a autrefois été un ami proche de Jean. Pourtant, leur amitié a pris fin depuis très longtemps à la suite d'une dispute dont les circonstances restent inconnues. Kael ne semble pas avoir oublié cette rupture.": {
  "en": "He was once a close friend of Jean. Yet their friendship ended a very long time ago after a dispute whose circumstances remain unknown. Kael does not seem to have forgotten that break.",
  "es": "Fue en otro tiempo un amigo cercano de Jean. Sin embargo, su amistad terminó hace muchísimo tiempo tras una disputa cuyas circunstancias siguen siendo desconocidas. Kael no parece haber olvidado esa ruptura.",
  "it": "Fu un tempo un amico stretto di Jean. Eppure la loro amicizia è finita molto tempo fa dopo una lite le cui circostanze restano sconosciute. Kael non sembra aver dimenticato quella rottura.",
  "ca": "Va ser un temps un amic proper d'en Jean. Tanmateix, la seva amistat es va acabar fa moltíssim temps després d'una disputa les circumstàncies de la qual continuen sent desconegudes. En Kael no sembla haver oblidat aquesta ruptura.",
  "ar": "كان في الماضي صديقًا مقرَّبًا لجان. ومع ذلك، انتهت صداقتهما منذ زمن بعيد جدًّا بعد خلاف لا تزال ظروفه مجهولة. لا يبدو أن كايل نسي ذلك الانقطاع."
 },
 "il a relancé des milliers de simulations et cache celle où Ben lui tend la main au lieu de le combattre.": {
  "en": "he has rerun thousands of simulations and hides the one where Ben offers him a hand instead of fighting him.",
  "es": "ha relanzado miles de simulaciones y esconde aquella en la que Ben le tiende la mano en lugar de combatirlo.",
  "it": "ha rilanciato migliaia di simulazioni e nasconde quella in cui Ben gli tende la mano invece di combatterlo.",
  "ca": "ha reprès milers de simulacions i amaga la que en Ben li ofereix la mà en lloc de combatre’l.",
  "ar": "أعاد تشغيل آلاف المحاكاات ويخفي المحاكاة التي يمدّ فيها بن يده بدلًا من قتاله."
 },
 "Il a senti quelque chose qu'il n'avait pas ressenti depuis très longtemps. Et ça l'a terrifié plus que n'importe quel ennemi.": {
  "en": "He felt something he had not felt for a very long time. And it terrified him more than any enemy.",
  "es": "Sintió algo que no había sentido desde hacía muchísimo tiempo. Y lo aterró más que cualquier enemigo.",
  "it": "Ha provato qualcosa che non provava da molto tempo. E lo ha terrorizzato più di qualsiasi nemico.",
  "ca": "Va sentir alguna cosa que no sentia des de feia moltíssim temps. I el va terroritzar més que qualsevol enemic.",
  "ar": "شعر بشيء لم يشعر به منذ زمن طويل جدًّا. وقد أرعبه أكثر من أي عدو."
 },
 "il a supprimé une partie de ses propres notes, car elles indiquaient que le signal d'Aidan avait été détecté avant sa disparition officielle.": {
  "en": "he deleted part of his own notes, because they indicated that Aidan's signal had been detected before his official disappearance.",
  "es": "eliminó parte de sus propias notas, porque indicaban que la señal de Aidan se había detectado antes de su desaparición oficial.",
  "it": "ha cancellato parte delle proprie note, perché indicavano che il segnale di Aidan era stato rilevato prima della sua scomparsa ufficiale.",
  "ca": "va eliminar part de les seves notes, perquè indicaven que el senyal d’Aidan s’havia detectat abans de la seva desaparició oficial.",
  "ar": "حذف جزءًا من ملاحظاته، لأنها كانت تشير إلى أن إشارة أيدن رُصدت قبل اختفائه الرسمي."
 },
 "Il a un nom. Il en a toujours eu un. Alyss Derimight.": {
  "en": "He has a name. He always had one. Alyss Derimight.",
  "es": "Tiene un nombre. Siempre tuvo uno. Alyss Derimight.",
  "it": "Ha un nome. Ne ha sempre avuto uno. Alyss Derimight.",
  "ca": "Té un nom. Sempre n'ha tingut un. Alyss Derimight.",
  "ar": "له اسم. لطالما كان له اسم. أليس ديرمايت."
 },
 "Il le sait. Il ne vous demande pas de pardonner. Il veut seulement reprendre sa forme. Sa vraie forme.": {
  "en": "He knows. He is not asking you to forgive. He only wants to recover his form. His true form.",
  "es": "Lo sabe. No os pide que perdonéis. Solo quiere recuperar su forma. Su verdadera forma.",
  "it": "Lo sa. Non vi chiede di perdonare. Vuole solo riprendere la sua forma. La sua vera forma.",
  "ca": "Ho sap. No us demana que perdoneu. Només vol recuperar la seva forma. La seva veritable forma.",
  "ar": "هو يعرف. لا يطلب منكم أن تغفروا. يريد فقط استعادة شكله. شكله الحقيقي."
 },
 "Il ne cherche pas à réparer le Point Zéro. Il prépare une élimination systématique.": {
  "en": "He is not trying to repair Point Zero. He is preparing a systematic elimination.",
  "es": "No intenta reparar el Punto Cero. Prepara una eliminación sistemática.",
  "it": "Non cerca di riparare il Punto Zero. Prepara un'eliminazione sistematica.",
  "ca": "No intenta reparar el Punt Zero. Prepara una eliminació sistemàtica.",
  "ar": "إنه لا يحاول إصلاح النقطة صفر. بل يعدّ تصفية منهجية."
 },
 "Il ne savait pas non plus. Pas avant qu'on le lui dise.": {
  "en": "He did not know either. Not before we told him.",
  "es": "Él tampoco lo sabía. No antes de que se lo dijéramos.",
  "it": "Neanche lui lo sapeva. Non prima che glielo dicessimo.",
  "ca": "Ell tampoc no ho sabia. No abans que li diguéssim.",
  "ar": "هو أيضًا لم يكن يعرف. ليس قبل أن نخبره."
 },
 "Il parle calmement, même lorsqu'il menace ses anciens alliés. Il ne se voit pas comme un monstre, mais comme la seule personne assez déterminée pour aller jusqu'au bout. Ben représente pour lui le dernier obstacle, mais aussi le rappel de ce qu'il était avant de perdre confiance en toute possibilité de changement.": {
  "en": "He speaks calmly, even when he threatens his former allies. He does not see himself as a monster, but as the only person determined enough to go all the way. Ben represents his last obstacle, but also a reminder of what he was before losing faith in any possibility of change.",
  "es": "Habla con calma, incluso cuando amenaza a sus antiguos aliados. No se ve como un monstruo, sino como la única persona lo bastante decidida para llegar hasta el final. Ben representa para él el último obstáculo, pero también el recuerdo de lo que era antes de perder la fe en toda posibilidad de cambio.",
  "it": "Parla con calma, anche quando minaccia i suoi vecchi alleati. Non si vede come un mostro, ma come l'unica persona abbastanza determinata ad andare fino in fondo. Ben rappresenta per lui l'ultimo ostacolo, ma anche il ricordo di ciò che era prima di perdere fiducia in ogni possibilità di cambiamento.",
  "ca": "Parla amb calma, fins i tot quan amenaça els seus antics aliats. No es veu com un monstre, sinó com l'única persona prou decidida per arribar fins al final. En Ben representa per a ell l'últim obstacle, però també el record del que era abans de perdre la fe en tota possibilitat de canvi.",
  "ar": "يتحدث بهدوء، حتى عندما يهدد حلفاءه السابقين. لا يرى نفسه وحشًا، بل الشخص الوحيد العازم بما يكفي ليصل إلى النهاية. يمثل بن بالنسبة إليه العقبة الأخيرة، لكنه أيضًا تذكير بما كان عليه قبل أن يفقد الثقة في أي احتمال للتغيير."
 },
 "il sait où chercher Jean, mais doute que celui-ci puisse encore être sauvé.": {
  "en": "he knows where to look for Jean, but doubts that Jean can still be saved.",
  "es": "sabe dónde buscar a Jean, pero duda que este pueda salvarse todavía.",
  "it": "sa dove cercare Jean, ma dubita che possa ancora essere salvato.",
  "ca": "sap on buscar en Jean, però dubta que encara es pugui salvar.",
  "ar": "يعرف أين يبحث عن جان، لكنه يشك في إمكان إنقاذه بعد."
 },
 "Il savait qu'on viendrait… On n'a pas trouvé son piège. On vient d'activer quelque chose.": {
  "en": "He knew we would come… We did not find his trap. We have just activated something.",
  "es": "Sabía que vendríamos… No encontramos su trampa. Acabamos de activar algo.",
  "it": "Sapeva che saremmo venuti… Non abbiamo trovato la sua trappola. Abbiamo appena attivato qualcosa.",
  "ca": "Sabia que vindríem… No vam trobar el seu parany. Acabem d'activar alguna cosa.",
  "ar": "كان يعرف أننا سنأتي… لم نجد فخّه. لقد فعّلنا شيئًا للتو."
 },
 "Il t'a envoyée ?": {
  "en": "He sent you?",
  "es": "¿Él te ha enviado?",
  "it": "Ti ha mandata lui?",
  "ca": "Ell t'ha enviada?",
  "ar": "هل أرسلك هو؟"
 },
 "Il voulait que quelqu'un vous parle. Quelqu'un qu'il ne pouvait pas effrayer en se montrant lui-même.": {
  "en": "He wanted someone to speak to you. Someone he could not frighten by appearing himself.",
  "es": "Quería que alguien os hablara. Alguien a quien no pudiera asustar apareciendo él mismo.",
  "it": "Voleva che qualcuno vi parlasse. Qualcuno che non poteva spaventare mostrandosi di persona.",
  "ca": "Volia que algú us parlés. Algú a qui no pogués espantar apareixent ell mateix.",
  "ar": "أراد أن يكلّمكم أحد. أحد لا يستطيع إخافته بظهوره هو."
 },
 "imposer une réalité stable, même si elle est construite sur la contrainte.": {
  "en": "to impose a stable reality, even if it is built on coercion.",
  "es": "imponer una realidad estable, aunque esté construida sobre la coacción.",
  "it": "imporre una realtà stabile, anche se costruita sulla costrizione.",
  "ca": "imposar una realitat estable, encara que estigui construïda sobre la coacció.",
  "ar": "فرض واقع مستقر، حتى لو كان مبنيًّا على الإكراه."
 },
 "inconnu.title": {
  "en": "DO YOU <span>HEAR ME</span> ?",
  "es": "¿ME <span>ESCUCHAS</span> ?",
  "it": "MI <span>SENTI</span> ?",
  "ca": "EM <span>SENTS</span> ?",
  "ar": "هل <span>تسمعني</span> ؟"
 },
 "inconnue. Si Aidan est encore conscient, il semble essayer de prévenir ses amis.": {
  "en": "unknown. If Aidan is still conscious, he seems to be trying to warn his friends.",
  "es": "desconocida. Si Aidan sigue consciente, parece intentar advertir a sus amigos.",
  "it": "sconosciuta. Se Aidan è ancora cosciente, sembra cercare di avvertire i suoi amici.",
  "ca": "desconeguda. Si l’Aidan encara és conscient, sembla que intenta avisar els seus amics.",
  "ar": "مجهول. إذا كان أيدن لا يزال واعيًا، فيبدو أنه يحاول تحذير أصدقائه."
 },
 "inconnue. Son retour semble lié au Point Zéro et à son passé avec Jean.": {
  "en": "unknown. His return seems linked to Point Zero and to his past with Jean.",
  "es": "desconocida. Su regreso parece ligado al Punto Cero y a su pasado con Jean.",
  "it": "sconosciuta. Il suo ritorno sembra legato al Punto Zero e al suo passato con Jean.",
  "ca": "desconeguda. El seu retorn sembla lligat al Punt Zero i al seu passat amb en Jean.",
  "ar": "مجهول. تبدو عودته مرتبطة بالنقطة صفر وبماضيه مع جان."
 },
 "INDEX CARTOGRAPHIQUE": {
  "en": "CARTOGRAPHIC INDEX",
  "es": "ÍNDICE CARTOGRÁFICO",
  "it": "INDICE CARTOGRAFICO",
  "ca": "ÍNDEX CARTOGRÀFIC",
  "ar": "فهرس خرائطي"
 },
 "INDEX DES SECTEURS": {
  "en": "SECTOR INDEX",
  "es": "ÍNDICE DE SECTORES",
  "it": "INDICE DEI SETTORI",
  "ca": "ÍNDEX DE SECTORS",
  "ar": "فهرس القطاعات"
 },
 "Informations inconnues :": {
  "en": "Unknown information:",
  "es": "Información desconocida:",
  "it": "Informazioni sconosciute:",
  "ca": "Informació desconeguda:",
  "ar": "معلومات مجهولة:"
 },
 "Installation au sud de l’île.": {
  "en": "Facility south of the island.",
  "es": "Instalación al sur de la isla.",
  "it": "Installazione a sud dell'isola.",
  "ca": "Instal·lació al sud de l'illa.",
  "ar": "منشأة جنوب الجزيرة."
 },
 "INSTITUT ONIRIQUE": {
  "en": "DREAM INSTITUTE",
  "es": "INSTITUTO ONÍRICO",
  "it": "ISTITUTO ONIRICO",
  "ca": "INSTITUT ONÍRIC",
  "ar": "المعهد الحالم"
 },
 "INSTITUT ONIRIQUE · ARCHIVES INTERDIMENSIONNELLES": {
  "en": "DREAM INSTITUTE · INTERDIMENSIONAL ARCHIVES",
  "es": "INSTITUTO ONÍRICO · ARCHIVOS INTERDIMENSIONALES",
  "it": "ISTITUTO ONIRICO · ARCHIVI INTERDIMENSIONALI",
  "ca": "INSTITUT ONÍRIC · ARXIUS INTERDIMENSIONALS",
  "ar": "المعهد الحالم · أرشيفات بين الأبعاد"
 },
 "INSTITUT ONIRIQUE · CONNEXION INTERDIMENSIONNELLE": {
  "en": "DREAM INSTITUTE · INTERDIMENSIONAL CONNECTION",
  "es": "INSTITUTO ONÍRICO · CONEXIÓN INTERDIMENSIONAL",
  "it": "ISTITUTO ONIRICO · CONNESSIONE INTERDIMENSIONALE",
  "ca": "INSTITUT ONÍRIC · CONNEXIÓ INTERDIMENSIONAL",
  "ar": "المعهد الحالم · اتصال بين الأبعاد"
 },
 "INTÉGRITÉ DU SIGNAL · 100%": {
  "en": "SIGNAL INTEGRITY · 100%",
  "es": "INTEGRIDAD DE LA SEÑAL · 100%",
  "it": "INTEGRITÀ DEL SEGNALE · 100%",
  "ca": "INTEGRITAT DEL SENYAL · 100%",
  "ar": "سلامة الإشارة · 100%"
 },
 "J'ai ouvert le dossier verrouillé. Ben, tu dois voir ça.": {
  "en": "I opened the locked file. Ben, you need to see this.",
  "es": "He abierto el expediente bloqueado. Ben, tienes que ver esto.",
  "it": "Ho aperto il fascicolo bloccato. Ben, devi vedere questo.",
  "ca": "He obert l'expedient bloquejat. Ben, has de veure això.",
  "ar": "فتحت الملف المقفل. بن، عليك أن ترى هذا."
 },
 "J'ai récupéré un fichier audio de DECA. La date est postérieure à la mort d'Aidan.": {
  "en": "I recovered an audio file from DECA. The date is later than Aidan's death.",
  "es": "He recuperado un archivo de audio de DECA. La fecha es posterior a la muerte de Aidan.",
  "it": "Ho recuperato un file audio da DECA. La data è successiva alla morte di Aidan.",
  "ca": "He recuperat un fitxer d'àudio de DECA. La data és posterior a la mort de l'Aidan.",
  "ar": "استعدت ملفًا صوتيًّا من DECA. تاريخه لاحق لموت أيدن."
 },
 "J'ai vu ce qui arrive quand on laisse le choix à tout le monde. Chaque choix crée une autre possibilité. Chaque possibilité crée un autre conflit.": {
  "en": "I have seen what happens when everyone is allowed to choose. Every choice creates another possibility. Every possibility creates another conflict.",
  "es": "He visto lo que ocurre cuando se deja elegir a todo el mundo. Cada elección crea otra posibilidad. Cada posibilidad crea otro conflicto.",
  "it": "Ho visto cosa succede quando si lascia scegliere a tutti. Ogni scelta crea un'altra possibilità. Ogni possibilità crea un altro conflitto.",
  "ca": "He vist què passa quan es deixa triar tothom. Cada elecció crea una altra possibilitat. Cada possibilitat crea un altre conflicte.",
  "ar": "رأيت ما يحدث حين يُترك الجميع يختارون. كل خيار يخلق احتمالًا آخر. وكل احتمال يخلق نزاعًا آخر."
 },
 "J'aimerais signaler que les portes viennent de se verrouiller. Je crois que notre petite visite est terminée.": {
  "en": "I would like to point out that the doors have just locked. I believe our little visit is over.",
  "es": "Me gustaría señalar que las puertas acaban de bloquearse. Creo que nuestra pequeña visita ha terminado.",
  "it": "Vorrei far notare che le porte si sono appena bloccate. Credo che la nostra piccola visita sia finita.",
  "ca": "M'agradaria assenyalar que les portes s'acaben de bloquejar. Crec que la nostra petita visita s'ha acabat.",
  "ar": "أودّ الإشارة إلى أن الأبواب أُغلقت للتو. أظن أن زيارتنا الصغيرة انتهت."
 },
 "J'appelle ça une chance. Une seule réalité. Une seule histoire. Et tous ceux qui pourraient s'opposer à moi disparaîtront.": {
  "en": "I call that a chance. One single reality. One single story. And all those who might oppose me will disappear.",
  "es": "Yo a eso lo llamo una oportunidad. Una sola realidad. Una sola historia. Y todos los que puedan oponerse a mí desaparecerán.",
  "it": "Io la chiamo un'opportunità. Una sola realtà. Una sola storia. E tutti coloro che potrebbero opporsi a me scompariranno.",
  "ca": "Jo en dic una oportunitat. Una sola realitat. Una sola història. I tots els qui puguin oposar-se a mi desapareixeran.",
  "ar": "أنا أسمّي ذلك فرصة. واقع واحد فقط. قصة واحدة فقط. وكل من قد يعارضني سيختفي."
 },
 "J'avais dit que je ne viendrais pas devant eux.": {
  "en": "I said I would not come before them.",
  "es": "Dije que no vendría delante de ellos.",
  "it": "Ho detto che non sarei venuto davanti a loro.",
  "ca": "Vaig dir que no vindria davant d'ells.",
  "ar": "قلت إنني لن آتي أمامهم."
 },
 "Je crois qu'on vient d'ouvrir un tout nouveau tiroir.": {
  "en": "I think we have just opened a brand-new drawer.",
  "es": "Creo que acabamos de abrir un cajón completamente nuevo.",
  "it": "Credo che abbiamo appena aperto un cassetto nuovissimo.",
  "ca": "Crec que acabem d'obrir un calaix tot nou.",
  "ar": "أظننا فتحنا للتو درجًا جديدًا تمامًا."
 },
 "Je l'ai conçue. Et si vous voulez survivre à cette nuit, cessez de croire que DECA est simplement un laboratoire.": {
  "en": "I designed it. And if you want to survive this night, stop believing that DECA is simply a laboratory.",
  "es": "Yo lo diseñé. Y si queréis sobrevivir a esta noche, dejad de creer que DECA es simplemente un laboratorio.",
  "it": "L'ho progettata io. E se volete sopravvivere a questa notte, smettete di credere che DECA sia semplicemente un laboratorio.",
  "ca": "Jo el vaig dissenyar. I si voleu sobreviure a aquesta nit, deixeu de creure que DECA és simplement un laboratori.",
  "ar": "أنا صمّمتها. وإن أردتم النجاة من هذه الليلة، فتوقفوا عن الاعتقاد بأن DECA مجرد مختبر."
 },
 "Je n'en attendais pas moins de vous.": {
  "en": "I expected no less from you.",
  "es": "No esperaba menos de vosotros.",
  "it": "Non mi aspettavo di meno da voi.",
  "ca": "No esperava menys de vosaltres.",
  "ar": "لم أتوقع أقل منكم."
 },
 "Je n'espère rien. Je suis venu parce que vous avez le droit de connaître la vérité.": {
  "en": "I expect nothing. I came because you have the right to know the truth.",
  "es": "No espero nada. He venido porque tenéis derecho a saber la verdad.",
  "it": "Non mi aspetto nulla. Sono venuto perché avete il diritto di sapere la verità.",
  "ca": "No m'espero res. He vingut perquè teniu dret a saber la veritat.",
  "ar": "لا أتوقع شيئًا. جئت لأن لكم الحق في معرفة الحقيقة."
 },
 "Je ne l'affronte pas. Pas encore. Je veux que le monde sache ce qu'il a fait.": {
  "en": "I am not facing him. Not yet. I want the world to know what he has done.",
  "es": "No me enfrento a él. Todavía no. Quiero que el mundo sepa lo que ha hecho.",
  "it": "Non lo affronto. Non ancora. Voglio che il mondo sappia ciò che ha fatto.",
  "ca": "No m'hi enfronto. Encara no. Vull que el món sàpiga què ha fet.",
  "ar": "أنا لا أواجهه. ليس بعد. أريد أن يعرف العالم ما فعله."
 },
 "Je ne sais pas s'il est encore possible de le sauver.": {
  "en": "I do not know whether it is still possible to save him.",
  "es": "No sé si todavía es posible salvarlo.",
  "it": "Non so se sia ancora possibile salvarlo.",
  "ca": "No sé si encara és possible salvar-lo.",
  "ar": "لا أعرف إن كان لا يزال ممكنًا إنقاذه."
 },
 "Je ne suis pas Jean.": {
  "en": "I am not Jean.",
  "es": "No soy Jean.",
  "it": "Non sono Jean.",
  "ca": "No sóc en Jean.",
  "ar": "أنا لست جان."
 },
 "Je ne suis pas venue pour ça. Pas seulement.": {
  "en": "I did not come for that. Not only for that.",
  "es": "No he venido por eso. No solo por eso.",
  "it": "Non sono venuta per questo. Non solo per questo.",
  "ca": "No he vingut per això. No només per això.",
  "ar": "لم آتِ من أجل ذلك. ليس فقط من أجل ذلك."
 },
 "Je ne vous aide pas. J'essaie de corriger une erreur que j'aurais dû empêcher avant la mort d'Aidan.": {
  "en": "I am not helping you. I am trying to correct a mistake I should have prevented before Aidan's death.",
  "es": "No os estoy ayudando. Intento corregir un error que debería haber evitado antes de la muerte de Aidan.",
  "it": "Non vi sto aiutando. Cerco di correggere un errore che avrei dovuto impedire prima della morte di Aidan.",
  "ca": "No us estic ajudant. Intento corregir un error que hauria d'haver evitat abans de la mort de l'Aidan.",
  "ar": "أنا لا أساعدكم. إنني أحاول تصحيح خطأ كان عليّ منعه قبل موت أيدن."
 },
 "Je sais. C'est justement pour ça que j'ai peur.": {
  "en": "I know. That is precisely why I am afraid.",
  "es": "Lo sé. Es precisamente por eso por lo que tengo miedo.",
  "it": "Lo so. È proprio per questo che ho paura.",
  "ca": "Ho sé. És precisament per això que tinc por.",
  "ar": "أعرف. ولهذا بالضبط أخاف."
 },
 "Je sais. Mais écoute : le fichier contient des détails qui ne figurent dans aucune archive publique.": {
  "en": "I know. But listen: the file contains details that appear in no public archive.",
  "es": "Lo sé. Pero escucha: el archivo contiene detalles que no figuran en ningún archivo público.",
  "it": "Lo so. Ma ascolta: il file contiene dettagli che non figurano in nessun archivio pubblico.",
  "ca": "Ho sé. Però escolta: el fitxer conté detalls que no figuren en cap arxiu públic.",
  "ar": "أعرف. لكن استمع: يحتوي الملف على تفاصيل لا ترد في أي أرشيف عام."
 },
 "Je suis en train de vous dire qu'il ne veut plus se battre.": {
  "en": "I am telling you that he no longer wants to fight.",
  "es": "Te estoy diciendo que ya no quiere luchar.",
  "it": "Ti sto dicendo che non vuole più combattere.",
  "ca": "T'estic dient que ja no vol lluitar.",
  "ar": "أنا أقول لكم إنه لم يعد يريد القتال."
 },
 "Je t'ai caché des choses, oui. Mais pas pour les raisons que tu imagines.": {
  "en": "I hid things from you, yes. But not for the reasons you imagine.",
  "es": "Te oculté cosas, sí. Pero no por las razones que imaginas.",
  "it": "Ti ho nascosto delle cose, sì. Ma non per i motivi che immagini.",
  "ca": "Et vaig amagar coses, sí. Però no per les raons que imagines.",
  "ar": "أخفيت عنك أشياء، نعم. لكن ليس للأسباب التي تتخيلها."
 },
 "Je t'ai promis que j'essaierais.": {
  "en": "I promised you I would try.",
  "es": "Te prometí que lo intentaría.",
  "it": "Ti ho promesso che ci avrei provato.",
  "ca": "Et vaig prometre que ho intentaria.",
  "ar": "وعدتك أنني سأحاول."
 },
 "Je t'entends depuis le début, Ben. C'est toi qui refuses d'écouter.": {
  "en": "I have been hearing you all along, Ben. You are the one who refuses to listen.",
  "es": "Te llevo oyendo desde el principio, Ben. Eres tú quien se niega a escuchar.",
  "it": "Ti sento fin dall'inizio, Ben. Sei tu che rifiuti di ascoltare.",
  "ca": "T'estic sentint des del principi, Ben. Ets tu qui es nega a escoltar.",
  "ar": "أسمعك منذ البداية، بن. أنت من يرفض الإنصات."
 },
 "Je vais entrer chez DECA. Je trouverai tes dossiers et je montrerai à tout le monde ce que tu prépares.": {
  "en": "I am going into DECA. I will find your files and show everyone what you are preparing.",
  "es": "Voy a entrar en DECA. Encontraré tus expedientes y mostraré a todo el mundo lo que preparas.",
  "it": "Entrerò nella DECA. Troverò i tuoi fascicoli e mostrerò a tutti ciò che stai preparando.",
  "ca": "Entraré a DECA. Trobaré els teus expedients i mostraré a tothom el que prepares.",
  "ar": "سأدخل إلى DECA. سأجد ملفاتك وأُظهر للجميع ما تحضّره."
 },
 "Jean": {
  "en": "Jean",
  "es": "Jean",
  "it": "Jean",
  "ca": "Jean",
  "ar": "جان"
 },
 "JEAN": {
  "en": "JEAN",
  "es": "JEAN",
  "it": "JEAN",
  "ca": "JEAN",
  "ar": "جان"
 },
 "Jean ? Réponds-moi. Je sais que tu captes cette fréquence.": {
  "en": "Jean? Answer me. I know you can pick up this frequency.",
  "es": "¿Jean? Respóndeme. Sé que captas esta frecuencia.",
  "it": "Jean? Rispondimi. So che capti questa frequenza.",
  "ca": "Jean? Respon-me. Sé que captes aquesta freqüència.",
  "ar": "جان؟ أجبني. أعرف أنك تلتقط هذه الترددات."
 },
 "Jean est introuvable. L'éclat inconnu n'a pas été identifié. Les parents vivants appartiennent au passé révélé par ce fichier, mais leur place exacte dans les réalités actuelles reste un mystère. Le code ouvre l'histoire cachée ; il ne résout pas encore ses dernières énigmes.": {
  "en": "Jean is nowhere to be found. The unknown shard has not been identified. The living parents belong to the past revealed by this file, but their exact place in current realities remains a mystery. The code opens the hidden story; it does not yet solve its final enigmas.",
  "es": "Jean está en paradero desconocido. El destello desconocido no ha sido identificado. Los padres vivos pertenecen al pasado revelado por este expediente, pero su lugar exacto en las realidades actuales sigue siendo un misterio. El código abre la historia oculta; todavía no resuelve sus últimos enigmas.",
  "it": "Jean è introvabile. Il frammento sconosciuto non è stato identificato. I genitori vivi appartengono al passato rivelato da questo fascicolo, ma il loro posto esatto nelle realtà attuali resta un mistero. Il codice apre la storia nascosta; non risolve ancora i suoi ultimi enigmi.",
  "ca": "En Jean no es troba enlloc. L'esclat desconegut no s'ha identificat. Els pares vius pertanyen al passat revelat per aquest expedient, però el seu lloc exacte en les realitats actuals continua sent un misteri. El codi obre la història oculta; encara no resol els seus últims enigmes.",
  "ar": "جان غير موجود. لم يُعرَّف الوميض المجهول. ينتمي الوالدان الحيان إلى الماضي الذي كشفه هذا الملف، لكن مكانهما الدقيق في الأواقع الحالية يبقى لغزًا. يفتح الرمز القصة المخفية؛ لكنه لا يحلّ ألغازها الأخيرة بعد."
 },
 "Jean est mort à la fin de la Saison 7. Il n'est pas devenu dangereux parce qu'il aimait le chaos. C'est précisément le chaos qu'il ne supporte plus. Après avoir vu les mêmes conflits se répéter dans d'innombrables réalités, il a fini par croire que la seule paix durable serait un monde où personne ne pourrait choisir de faire la guerre. Son rêve semble presque raisonnable jusqu'à ce qu'on comprenne son prix : pour obtenir une réalité parfaite, Jean est prêt à effacer toutes celles qui lui résistent.": {
  "en": "Jean died at the end of Season 7. He did not become dangerous because he loved chaos. It is precisely chaos that he can no longer bear. After seeing the same conflicts repeat across countless realities, he came to believe that the only lasting peace would be a world where no one could choose to wage war. His dream seems almost reasonable until one understands its price: to obtain a perfect reality, Jean is ready to erase every reality that resists him.",
  "es": "Jean murió al final de la Temporada 7. No se volvió peligroso porque amara el caos. Es precisamente el caos lo que ya no soporta. Tras ver los mismos conflictos repetirse en innumerables realidades, acabó creyendo que la única paz duradera sería un mundo donde nadie pudiera elegir hacer la guerra. Su sueño parece casi razonable hasta que se comprende su precio: para obtener una realidad perfecta, Jean está dispuesto a borrar todas las que se le resisten.",
  "it": "Jean è morto alla fine della Stagione 7. Non è diventato pericoloso perché amava il caos. È proprio il caos che non sopporta più. Dopo aver visto gli stessi conflitti ripetersi in innumerevoli realtà, ha finito per credere che l'unica pace duratura sarebbe un mondo in cui nessuno potesse scegliere di fare la guerra. Il suo sogno sembra quasi ragionevole finché non se ne comprende il prezzo: per ottenere una realtà perfetta, Jean è pronto a cancellare tutte quelle che gli resistono.",
  "ca": "En Jean va morir al final de la Temporada 7. No es va tornar perillós perquè estimés el caos. És precisament el caos el que ja no suporta. Després de veure els mateixos conflictes repetir-se en innombrables realitats, va acabar creient que l'única pau duradora seria un món on ningú no pogués triar fer la guerra. El seu somni sembla gairebé raonable fins que se'n comprèn el preu: per obtenir una realitat perfecta, en Jean està disposat a esborrar totes les que se li resisteixen.",
  "ar": "مات جان في نهاية الموسم 7. لم يصبح خطيرًا لأنه أحبّ الفوضى. بل الفوضى تحديدًا ما لم يعد يحتمله. بعد أن رأى النزاعات نفسها تتكرر في أواقع لا تُحصى، انتهى إلى الاعتقاد بأن السلام الدائم الوحيد سيكون عالمًا لا يستطيع فيه أحد اختيار شنّ الحرب. يبدو حلمه معقولًا تقريبًا حتى نفهم ثمنه: للحصول على واقع مثالي، جان مستعد لمحو كل الأواقع التي تقاومه."
 },
 "Jean est mort à la fin de la Saison 7. Il n'est pas devenu dangereux parce qu'il aimait le chaos. C'est précisément le chaos qu'il ne supporte plus. Après avoir vu les mêmes conflits se répéter dans d'innombrables réalités, il a…": {
  "en": "Jean died at the end of Season 7. He did not become dangerous because he loved chaos. It is precisely chaos that he can no longer bear. After seeing the same conflicts repeat across countless realities, he…",
  "es": "Jean murió al final de la Temporada 7. No se volvió peligroso porque amara el caos. Es precisamente el caos lo que ya no soporta. Tras ver los mismos conflictos repetirse en innumerables realidades, ha…",
  "it": "Jean è morto alla fine della Stagione 7. Non è diventato pericoloso perché amava il caos. È proprio il caos che non sopporta più. Dopo aver visto gli stessi conflitti ripetersi in innumerevoli realtà, ha…",
  "ca": "En Jean va morir al final de la Temporada 7. No es va tornar perillós perquè estimés el caos. És precisament el caos el que ja no suporta. Després de veure els mateixos conflictes repetir-se en innombrables realitats, ha…",
  "ar": "مات جان في نهاية الموسم 7. لم يصبح خطيرًا لأنه أحبّ الفوضى. بل الفوضى تحديدًا ما لم يعد يحتمله. بعد أن رأى النزاعات نفسها تتكرر في أواقع لا تُحصى،…"
 },
 "Jean et Ben ne se rencontrèrent pas dans leur enfance. Ils grandirent séparément, sans savoir que leurs réalités se frôlaient déjà. Jean cherchait des règles capables d'empêcher les catastrophes. Ben apprenait qu'on ne pouvait pas protéger tout le monde, mais qu'on pouvait choisir de ne pas abandonner ceux qui restaient.": {
  "en": "Jean and Ben did not meet in childhood. They grew up separately, unaware that their realities were already brushing against each other. Jean sought rules capable of preventing catastrophes. Ben learned that one cannot protect everyone, but that one can choose not to abandon those who remain.",
  "es": "Jean y Ben no se conocieron en la infancia. Crecieron por separado, sin saber que sus realidades ya se rozaban. Jean buscaba reglas capaces de evitar las catástrofes. Ben aprendía que no se puede proteger a todo el mundo, pero que se puede elegir no abandonar a los que quedan.",
  "it": "Jean e Ben non si incontrarono durante l'infanzia. Crebbero separatamente, senza sapere che le loro realtà si sfioravano già. Jean cercava regole capaci di impedire le catastrofi. Ben imparava che non si può proteggere tutti, ma che si può scegliere di non abbandonare chi resta.",
  "ca": "En Jean i en Ben no es van conèixer durant la infància. Van créixer separats, sense saber que les seves realitats ja es fregaven. En Jean buscava regles capaces d'evitar les catàstrofes. En Ben aprenia que no es pot protegir tothom, però que es pot triar de no abandonar els qui queden.",
  "ar": "لم يلتقِ جان وبن في طفولتهما. نشآ منفصلين، دون أن يعرفا أن أواقعهما كانت تتلامس مسبقًا. كان جان يبحث عن قواعد تمنع الكوارث. وكان بن يتعلّم أنه لا يمكن حماية الجميع، لكن يمكن اختيار عدم التخلي عن الباقين."
 },
 "Jean et Kael :": {
  "en": "Jean and Kael:",
  "es": "Jean y Kael:",
  "it": "Jean e Kael:",
  "ca": "Jean i Kael:",
  "ar": "جان وكايل:"
 },
 "Jean lance son plan final avec un nouveau morceau du Point Zéro. Les monolithes atteignent leur pleine puissance et l’énergie devient incontrôlable. Mais les alliés possèdent le dernier fragment du deuxième Point Zéro. Ils s’en servent pour retourner la situation et vaincre Jean.": {
  "en": "Jean launches his final plan with a new piece of Point Zero. The monoliths reach full power and the energy becomes uncontrollable. But the allies hold the last fragment of the second Point Zero. They use it to turn the tide and defeat Jean.",
  "es": "Jean lanza su plan final con un nuevo trozo del Punto Cero. Los monolitos alcanzan su máxima potencia y la energía se vuelve incontrolable. Pero los aliados poseen el último fragmento del segundo Punto Cero. Lo usan para dar la vuelta a la situación y vencer a Jean.",
  "it": "Jean lancia il suo piano finale con un nuovo pezzo del Punto Zero. I monoliti raggiungono la piena potenza e l’energia diventa incontrollabile. Ma gli alleati possiedono l’ultimo frammento del secondo Punto Zero. Se ne servono per ribaltare la situazione e sconfiggere Jean.",
  "ca": "En Jean llança el seu pla final amb un nou tros del Punt Zero. Els monòlits arriben a la plena potència i l’energia es torna incontrolable. Però els aliats posseeixen l’últim fragment del segon Punt Zero. Se’n serveixen per capgirar la situació i vèncer en Jean.",
  "ar": "يطلق جان خطته الأخيرة بقطعة جديدة من النقطة صفر. تبلغ المسلّات ذروة قوتها وتصبح الطاقة غير قابلة للسيطرة. لكن الحلفاء يملكون الشظية الأخيرة من النقطة صفر الثانية. يستخدمونها لقلب الموازين وهزيمة جان."
 },
 "Jean meurt au terme de l’affrontement. La lumière dans le ciel est celle de sa machine détruite : Jean se désintègre en étoile. Elle ne représente pas une nouvelle menace. Les débris et les bords de la carte sont simplement ceux d’une île reconstruite depuis longtemps.": {
  "en": "Jean dies at the end of the confrontation. The light in the sky is that of his destroyed machine: Jean disintegrates into a star. It does not represent a new threat. The debris and the edges of the map are simply those of an island rebuilt long ago.",
  "es": "Jean muere al final del enfrentamiento. La luz en el cielo es la de su máquina destruida: Jean se desintegra en estrella. No representa una nueva amenaza. Los restos y los bordes del mapa son simplemente los de una isla reconstruida hace mucho tiempo.",
  "it": "Jean muore al termine dello scontro. La luce nel cielo è quella della sua macchina distrutta: Jean si disintegra in una stella. Non rappresenta una nuova minaccia. I detriti e i bordi della mappa sono semplicemente quelli di un’isola ricostruita da molto tempo.",
  "ca": "En Jean mor al final de l’enfrontament. La llum al cel és la de la seva màquina destruïda: en Jean es desintegra en estrella. No representa una nova amenaça. Les restes i les vores del mapa són simplement les d’una illa reconstruïda fa molt de temps.",
  "ar": "يموت جان في نهاية المواجهة. الضوء في السماء هو ضوء آلته المدمَّرة: يتحلَّل جان إلى نجمة. وهو لا يمثل تهديدًا جديدًا. أما الحطام وحواف الخريطة فهي ببساطة لجزيرة أُعيد بناؤها منذ زمن طويل."
 },
 "Jean n'a pas de sœur. Il n'en a jamais parlé.": {
  "en": "Jean has no sister. He never spoke of one.",
  "es": "Jean no tiene hermana. Nunca habló de ninguna.",
  "it": "Jean non ha una sorella. Non ne ha mai parlato.",
  "ca": "En Jean no té germana. No en va parlar mai.",
  "ar": "جان ليس له أخت. لم يتحدث عنها قط."
 },
 "Jean ne leur répond pas. Il les aime sincèrement. C'est justement ce qui rend sa dérive tragique : il finit par confondre aimer quelqu'un avec décider à sa place. Son rêve de silence n'est pas né d'un désir simple de faire le mal. Il naît de sa peur du chaos, puis devient une obsession qui lui permet de justifier l'injustifiable.": {
  "en": "Jean does not answer them. He loves them sincerely. That is precisely what makes his drift tragic: he ends up confusing loving someone with deciding in their place. His dream of silence was not born from a simple desire to do evil. It is born of his fear of chaos, then becomes an obsession that allows him to justify the unjustifiable.",
  "es": "Jean no les responde. Los quiere sinceramente. Es precisamente eso lo que hace trágica su deriva: acaba confundiendo querer a alguien con decidir en su lugar. Su sueño de silencio no nació de un simple deseo de hacer el mal. Nace de su miedo al caos y luego se convierte en una obsesión que le permite justificar lo injustificable.",
  "it": "Jean non risponde loro. Li ama sinceramente. È proprio questo che rende tragica la sua deriva: finisce per confondere l'amare qualcuno con il decidere al suo posto. Il suo sogno di silenzio non è nato dal semplice desiderio di fare il male. Nasce dalla sua paura del caos, poi diventa un'ossessione che gli permette di giustificare l'ingiustificabile.",
  "ca": "En Jean no els respon. Els estima sincerament. És precisament això que fa tràgica la seva deriva: acaba confonent estimar algú amb decidir al seu lloc. El seu somni de silenci no va néixer d'un simple desig de fer el mal. Neix de la seva por al caos i després es converteix en una obsessió que li permet justificar l'injustificable.",
  "ar": "لا يجيبهم جان. إنه يحبهم بصدق. وهذا بالضبط ما يجعل انحرافه مأساويًّا: ينتهي إلى الخلط بين محبة أحدهم وتقرير مصيره. لم يُولد حلمه بالصمت من رغبة بسيطة في فعل الشر. بل وُلد من خوفه من الفوضى، ثم صار هوسًا يسمح له بتبرير ما لا يُبرَّر."
 },
 "Jean pense qu'une seule réalité peut mettre fin aux guerres. Il a cessé de voir les mondes comme des vies distinctes : pour lui, ce sont des variables qu'il peut supprimer.": {
  "en": "Jean believes that a single reality can end wars. He has stopped seeing worlds as distinct lives: for him, they are variables he can delete.",
  "es": "Jean cree que una sola realidad puede acabar con las guerras. Ha dejado de ver los mundos como vidas distintas: para él son variables que puede suprimir.",
  "it": "Jean crede che una sola realtà possa porre fine alle guerre. Ha smesso di vedere i mondi come vite distinte: per lui sono variabili che può cancellare.",
  "ca": "En Jean creu que una sola realitat pot acabar amb les guerres. Ha deixat de veure els mons com a vides diferents: per a ell són variables que pot suprimir.",
  "ar": "يعتقد جان أن واقعًا واحدًا يمكنه إنهاء الحروب. لم يعد يرى العوالم كحياةٍ منفصلة: بل يراها بالنسبة إليه متغيّرات يمكنه محوها."
 },
 "Jean réunit les éclats de ce second Point Zéro. Son vrai but se révèle : non pas sauver cette réalité, mais en obtenir une totalement silencieuse, sans guerre, quitte à tout détruire pour y parvenir. Lors d'un dîner en apparence tranquille, il déclenche un éclat et tue Voss, Vanny et Ducky. Il installe un virus dans les systèmes d'Aidan, qui disparaît lui aussi. Seul Ben survit. Jean ramène alors son propre royaume sur l'île, fait de bâtiments sombres aux néons roses, et s'adresse directement aux habitants, puis aux spectateurs, en transmission.": {
  "en": "Jean gathers the shards of this second Point Zero. His true goal is revealed: not to save this reality, but to obtain one that is utterly silent, without war, even if it means destroying everything to get there. At a seemingly peaceful dinner, he triggers a shard and kills Voss, Vanny and Ducky. He installs a virus in Aidan's systems, and Aidan vanishes too. Only Ben survives. Jean then brings his own kingdom onto the island, made of dark buildings with pink neon, and addresses the inhabitants directly, then the viewers, in a transmission.",
  "es": "Jean reúne los destellos de ese segundo Punto Cero. Su verdadero objetivo se revela: no salvar esta realidad, sino obtener una totalmente silenciosa, sin guerra, aunque para ello deba destruirlo todo. Durante una cena aparentemente tranquila, activa un destello y mata a Voss, Vanny y Ducky. Instala un virus en los sistemas de Aidan, que también desaparece. Solo Ben sobrevive. Jean trae entonces su propio reino a la isla, hecho de edificios oscuros con neones rosas, y se dirige directamente a los habitantes, y luego a los espectadores, en una transmisión.",
  "it": "Jean raduna i frammenti di questo secondo Punto Zero. Il suo vero scopo si rivela: non salvare questa realtà, ma ottenerne una del tutto silenziosa, senza guerra, anche a costo di distruggere tutto. Durante una cena all’apparenza tranquilla, attiva un frammento e uccide Voss, Vanny e Ducky. Installa un virus nei sistemi di Aidan, che scompare anch’egli. Solo Ben sopravvive. Jean porta allora il proprio regno sull’isola, fatto di edifici scuri con neon rosa, e si rivolge direttamente agli abitanti, poi agli spettatori, in una trasmissione.",
  "ca": "En Jean reuneix els esclats d’aquest segon Punt Zero. El seu veritable objectiu es revela: no salvar aquesta realitat, sinó obtenir-ne una totalment silenciosa, sense guerra, encara que calgui destruir-ho tot per aconseguir-ho. Durant un sopar aparentment tranquil, activa un esclat i mata en Voss, en Vanny i en Ducky. Instal·la un virus en els sistemes d’Aidan, que també desapareix. Només en Ben sobreviu. En Jean porta llavors el seu propi regne a l’illa, fet d’edificis foscos amb neons roses, i s’adreça directament als habitants, i després als espectadors, en una transmissió.",
  "ar": "يجمع جان شظايا النقطة صفر الثانية هذه. يتكشّف هدفه الحقيقي: ليس إنقاذ هذا الواقع، بل الحصول على واقع صامت تمامًا، بلا حرب، حتى لو اقتضى ذلك تدمير كل شيء. في عشاء يبدو هادئًا، يُفعّل شظية ويقتل فوس وفاني ودكي. يزرع فيروسًا في أنظمة أيدن، فيختفي أيدن أيضًا. لا ينجو سوى بن. ثم يجلب جان مملكته إلى الجزيرة، المبنية من مبانٍ داكنة بأضواء نيون وردية، ويخاطب السكان مباشرة، ثم المشاهدين، عبر بث."
 },
 "Jean soupçonne Ben d'en savoir trop. Il le plaque contre un mur et lui demande, en chuchotant, comment il connaît son plan. Ben répond une phrase au passé qui trahit sa connaissance du futur : « pas encore ». Pendant cette seconde de confusion, le Docteur Voss pousse Jean dans le portail.": {
  "en": "Jean suspects Ben of knowing too much. He pins him against a wall and whispers, asking how he knows his plan. Ben answers with a sentence in the past tense that betrays his knowledge of the future: « not yet ». In that second of confusion, Doctor Voss pushes Jean into the portal.",
  "es": "Jean sospecha que Ben sabe demasiado. Lo empuja contra una pared y le pregunta, susurrando, cómo conoce su plan. Ben responde con una frase en pasado que delata su conocimiento del futuro: « todavía no ». En ese segundo de confusión, el doctor Voss empuja a Jean al portal.",
  "it": "Jean sospetta che Ben sappia troppo. Lo sbatte contro un muro e gli chiede, sussurrando, come conosca il suo piano. Ben risponde con una frase al passato che tradisce la sua conoscenza del futuro: « non ancora ». In quel secondo di confusione, il Dottor Voss spinge Jean nel portale.",
  "ca": "En Jean sospita que en Ben sap massa. L’empeny contra una paret i li pregunta, xiuxiuejant, com coneix el seu pla. En Ben respon amb una frase en passat que delata el seu coneixement del futur: « encara no ». En aquest segon de confusió, el doctor Voss empeny en Jean dins del portal.",
  "ar": "يشك جان في أن بن يعرف أكثر من اللازم. يدفعه إلى الحائط ويسأله همسًا كيف يعرف خطته. يجيب بن بجملة بالماضي تفضح معرفته بالمستقبل: «ليس بعد». وفي تلك اللحظة من الارتباك، يدفع الدكتور فوس جان داخل البوابة."
 },
 "Jean, le Docteur Voss et Ben — celui de la Réalité 286, bien vivant, à ne pas confondre avec le frère de Jean mort en Réalité 265 — arrivent sur une nouvelle île. Ils forment un trio qui deviendra bientôt La Garde Zéro. L'île abrite son propre Point Zéro et des signes d'une force militaire organisée : l'Ordre, qui impose sa discipline sur le territoire.": {
  "en": "Jean, Doctor Voss and Ben — the Ben of Reality 286, very much alive, not to be confused with Jean's brother who died in Reality 265 — arrive on a new island. They form a trio that will soon become the Zero Guard. The island harbours its own Point Zero and the signs of an organised military force: the Order, which imposes its discipline on the territory.",
  "es": "Jean, el doctor Voss y Ben — el de la Realidad 286, muy vivo, que no debe confundirse con el hermano de Jean muerto en la Realidad 265 — llegan a una nueva isla. Forman un trío que pronto se convertirá en la Guardia Cero. La isla alberga su propio Punto Cero y los indicios de una fuerza militar organizada: el Orden, que impone su disciplina en el territorio.",
  "it": "Jean, il Dottor Voss e Ben — quello della Realtà 286, vivo e vegeto, da non confondere con il fratello di Jean morto nella Realtà 265 — arrivano su una nuova isola. Formano un trio che diventerà presto la Guardia Zero. L’isola ospita il proprio Punto Zero e i segni di una forza militare organizzata: l’Ordine, che impone la sua disciplina sul territorio.",
  "ca": "En Jean, el doctor Voss i en Ben — el de la Realitat 286, ben viu, que no s’ha de confondre amb el germà d’en Jean mort a la Realitat 265 — arriben a una illa nova. Formen un trio que aviat esdevindrà la Guàrdia Zero. L’illa allotja el seu propi Punt Zero i els senyals d’una força militar organitzada: l’Ordre, que imposa la seva disciplina al territori.",
  "ar": "يصل جان والدكتور فوس وبن — بن الواقع 286، الحي، الذي لا يجب الخلط بينه وبين شقيق جان الذي مات في الواقع 265 — إلى جزيرة جديدة. يشكّلون ثلاثيًّا سرعان ما سيصبح حرس الصفر. تحتضن الجزيرة نقطتها صفر الخاصة، وعلامات قوة عسكرية منظَّمة: النظام، الذي يفرض انضباطه على الإقليم."
 },
 "Jean.": {
  "en": "Jean.",
  "es": "Jean.",
  "it": "Jean.",
  "ca": "Jean.",
  "ar": "جان."
 },
 "Kael": {
  "en": "Kael",
  "es": "Kael",
  "it": "Kael",
  "ca": "Kael",
  "ar": "كايل"
 },
 "KAEL": {
  "en": "KAEL",
  "es": "KAEL",
  "it": "KAEL",
  "ca": "KAEL",
  "ar": "كايل"
 },
 "Kael :": {
  "en": "Kael:",
  "es": "Kael:",
  "it": "Kael:",
  "ca": "Kael:",
  "ar": "كايل:"
 },
 "Kael Base": {
  "en": "Kael Base",
  "es": "Base de Kael",
  "it": "Base di Kael",
  "ca": "Base d'en Kael",
  "ar": "قاعدة كايل"
 },
 "KAEL BASE": {
  "en": "KAEL BASE",
  "es": "BASE DE KAEL",
  "it": "BASE DI KAEL",
  "ca": "BASE DE KAEL",
  "ar": "قاعدة كايل"
 },
 "Kael est arrivé dans la villa au milieu du lac grâce à une machine temporelle. Il connaît le Point Zéro et a été un ami proche de Jean. Olie et lui partagent une aventure passée dont les détails restent classifiés.": {
  "en": "Kael arrived at the villa in the middle of the lake by time machine. He knows Point Zero and was a close friend of Jean. He and Olie share a past adventure whose details remain classified.",
  "es": "Kael llegó a la villa en medio del lago mediante una máquina del tiempo. Conoce el Punto Cero y fue un amigo cercano de Jean. Él y Olie comparten una aventura pasada cuyos detalles siguen clasificados.",
  "it": "Kael è arrivato alla villa in mezzo al lago con una macchina del tempo. Conosce il Punto Zero ed è stato un amico stretto di Jean. Lui e Olie condividono un'avventura passata i cui dettagli restano classificati.",
  "ca": "En Kael va arribar a la vil·la al mig del llac amb una màquina del temps. Coneix el Punt Zero i va ser un amic proper d'en Jean. Ell i l'Olie comparteixen una aventura passada els detalls de la qual continuen classificats.",
  "ar": "وصل كايل إلى الفيلا وسط البحيرة بآلة زمن. يعرف النقطة صفر وكان صديقًا مقرَّبًا لجان. وهو وأولي يشتركان في مغامرة ماضية لا تزال تفاصيلها مصنَّفة."
 },
 "Kael est arrivé sur la nouvelle île grâce à une machine temporelle. À son arrivée, il parle seul et évoque le Point Zéro, comme s'il retrouvait un endroit qu'il connaît déjà ou qu'il redoutait de revoir.": {
  "en": "Kael arrived on the new island by time machine. On arrival, he talks to himself and mentions Point Zero, as if returning to a place he already knows or dreaded seeing again.",
  "es": "Kael llegó a la nueva isla mediante una máquina del tiempo. Al llegar, habla solo y evoca el Punto Cero, como si regresara a un lugar que ya conoce o que temía volver a ver.",
  "it": "Kael è arrivato sulla nuova isola con una macchina del tempo. Al suo arrivo, parla da solo ed evoca il Punto Zero, come se tornasse in un luogo che già conosce o che temeva di rivedere.",
  "ca": "En Kael va arribar a l'illa nova amb una màquina del temps. En arribar, parla sol i evoca el Punt Zero, com si tornés a un lloc que ja coneix o que temia tornar a veure.",
  "ar": "وصل كايل إلى الجزيرة الجديدة بآلة زمن. عند وصوله، يتحدث مع نفسه ويذكر النقطة صفر، كأنه يعود إلى مكان يعرفه مسبقًا أو كان يخشى رؤيته مجددًا."
 },
 "L'ARRIVÉE DANS UNE RÉALITÉ TROIS FOIS PLUS GRANDE": {
  "en": "ARRIVAL IN A REALITY THREE TIMES LARGER",
  "es": "LA LLEGADA A UNA REALIDAD TRES VECES MÁS GRANDE",
  "it": "L’ARRIVO IN UNA REALTÀ TRE VOLTE PIÙ GRANDE",
  "ca": "L’ARRIBADA A UNA REALITAT TRES VEGADES MÉS GRAN",
  "ar": "الوصول إلى واقع أكبر بثلاث مرات"
 },
 "L'équipe traverse vers une nouvelle réalité, bien plus vaste que la précédente. Point Zéro s'y trouve à Deca Zero, au centre de la carte. Une fracture du ciel laisse voir un cube du Vide apparaître près de The Prison, plus inquiétant que le Cube Originel. Peu après, un portail violet s'ouvre au-dessus de Deca Zero : Point Zéro ramène un second Point Zéro, celui de l'île originelle de Jean, qui revient chercher son gardien, le Cube Originel, et pour ne plus être seul.": {
  "en": "The team crosses into a new reality, far vaster than the previous one. Point Zero is there at Deca Zero, at the centre of the map. A tear in the sky reveals a Void cube appearing near The Prison, more unsettling than the Original Cube. Soon after, a violet portal opens above Deca Zero: Point Zero brings back a second Point Zero, the one from Jean's original island, returning to find its guardian, the Original Cube, and to no longer be alone.",
  "es": "El equipo cruza hacia una nueva realidad, mucho más vasta que la anterior. El Punto Cero se encuentra allí en Deca Zero, en el centro del mapa. Una fractura del cielo deja ver un cubo del Vacío que aparece cerca de The Prison, más inquietante que el Cubo Original. Poco después, un portal violeta se abre sobre Deca Zero: el Punto Cero trae un segundo Punto Cero, el de la isla original de Jean, que vuelve a buscar a su guardián, el Cubo Original, y para no estar solo.",
  "it": "La squadra attraversa verso una nuova realtà, molto più vasta della precedente. Il Punto Zero si trova lì a Deca Zero, al centro della mappa. Una frattura nel cielo lascia vedere un cubo del Vuoto apparire vicino a The Prison, più inquietante del Cubo Originale. Poco dopo, un portale viola si apre sopra Deca Zero: il Punto Zero riporta un secondo Punto Zero, quello dell’isola originaria di Jean, che torna a cercare il suo guardiano, il Cubo Originale, e per non essere più solo.",
  "ca": "L’equip travessa cap a una realitat nova, molt més vasta que l’anterior. El Punt Zero hi és a Deca Zero, al centre del mapa. Una fractura del cel deixa veure un cub del Buit que apareix prop de The Prison, més inquietant que el Cub Original. Poc després, un portal violeta s’obre sobre Deca Zero: el Punt Zero torna un segon Punt Zero, el de l’illa originària d’en Jean, que torna a buscar el seu guardià, el Cub Original, i per no estar mai més sol.",
  "ar": "يعبر الفريق إلى واقع جديد، أوسع بكثير من السابق. تقع النقطة صفر هناك في Deca Zero، وسط الخريطة. يشقّ السماءَ تصدُّعٌ يكشف عن مكعب للفراغ يظهر قرب The Prison، أكثر إقلاقًا من المكعب الأصلي. بعد ذلك بقليل، تُفتح بوابة بنفسجية فوق Deca Zero: تعيد النقطة صفر نقطةً صفر ثانية، تلك الخاصة بجزيرة جان الأصلية، عائدةً للبحث عن حارسها، المكعب الأصلي، ولكي لا تبقى وحدها."
 },
 "L’homme arrivé par la machine temporelle se nomme Kael. À peine arrivé, il parle seul et évoque le Point Zéro comme s’il connaissait déjà son histoire. Kael était autrefois un ami proche de Jean, mais leur amitié s’est terminée depuis très longtemps après une dispute dont les détails restent inconnus.": {
  "en": "The man who arrived by time machine is named Kael. Barely there, he talks to himself and speaks of Point Zero as if he already knew its story. Kael was once a close friend of Jean, but their friendship ended long ago after a dispute whose details remain unknown.",
  "es": "El hombre llegado por la máquina del tiempo se llama Kael. Apenas llegar, habla solo y evoca el Punto Cero como si ya conociera su historia. Kael fue en otro tiempo un amigo cercano de Jean, pero su amistad terminó hace muchísimo tiempo tras una disputa cuyos detalles siguen siendo desconocidos.",
  "it": "L’uomo arrivato con la macchina del tempo si chiama Kael. Appena arrivato, parla da solo ed evoca il Punto Zero come se ne conoscesse già la storia. Kael era un tempo un amico stretto di Jean, ma la loro amicizia è finita molto tempo fa dopo una lite i cui dettagli restano sconosciuti.",
  "ca": "L’home arribat amb la màquina del temps es diu Kael. Només arribar, parla sol i evoca el Punt Zero com si ja en conegués la història. En Kael havia estat un amic proper d’en Jean, però la seva amistat es va acabar fa molt de temps després d’una disputa els detalls de la qual continuen sent desconeguts.",
  "ar": "الرجل الذي وصل بآلة الزمن اسمه كايل. بمجرد وصوله، يتحدث مع نفسه ويذكر النقطة صفر كأنه يعرف قصتها مسبقًا. كان كايل صديقًا مقرَّبًا لجان في الماضي، لكن صداقتهما انتهت منذ زمن بعيد بعد خلاف لا تزال تفاصيله مجهولة."
 },
 "La carte du Chapitre 2, Saison 1 vient d’être ajoutée aux archives. Au centre de l’île, Freaky Zero attire l’attention de l’Institut Onirique : depuis plusieurs nuits, une pulsation bleue traverse la forêt. Elle ne ressemble ni à l’énergie du Point Zéro libéré, ni à la signature des fragments déjà connus.": {
  "en": "The Chapter 2, Season 1 map has just been added to the archives. At the centre of the island, Freaky Zero draws the attention of the Dream Institute: for several nights, a blue pulse has been crossing the forest. It resembles neither the energy of the released Point Zero nor the signature of the fragments already known.",
  "es": "El mapa del Capítulo 2, Temporada 1 acaba de añadirse a los archivos. En el centro de la isla, Freaky Zero atrae la atención del Instituto Onírico: desde hace varias noches, una pulsación azul atraviesa el bosque. No se parece ni a la energía del Punto Cero liberado ni a la firma de los fragmentos ya conocidos.",
  "it": "La mappa del Capitolo 2, Stagione 1 è appena stata aggiunta agli archivi. Al centro dell’isola, Freaky Zero attira l’attenzione dell’Istituto Onirico: da diverse notti, una pulsazione blu attraversa la foresta. Non somiglia né all’energia del Punto Zero liberato né alla firma dei frammenti già noti.",
  "ca": "El mapa del Capítol 2, Temporada 1 acaba d’afegir-se als arxius. Al centre de l’illa, Freaky Zero atrau l’atenció de l’Institut Oníric: des de fa diverses nits, una pulsació blava travessa el bosc. No s’assembla ni a l’energia del Punt Zero alliberat ni a la signatura dels fragments ja coneguts.",
  "ar": "أُضيفت خريطة الفصل 2، الموسم 1 للتو إلى الأرشيف. في وسط الجزيرة، يسترعي Freaky Zero انتباه المعهد الحالم: منذ عدة ليالٍ، تعبر نبضة زرقاء الغابة. وهي لا تشبه طاقة النقطة صفر المحرَّرة ولا توقيع الشظايا المعروفة."
 },
 "La carte précédente est conservée ici pour garder une trace de l’île reconstruite après la libération du Point Zéro.": {
  "en": "The previous map is kept here to preserve a record of the island rebuilt after the liberation of Point Zero.",
  "es": "El mapa anterior se conserva aquí para guardar constancia de la isla reconstruida tras la liberación del Punto Cero.",
  "it": "La mappa precedente è conservata qui per mantenere traccia dell'isola ricostruita dopo la liberazione del Punto Zero.",
  "ca": "El mapa anterior es conserva aquí per guardar constància de l'illa reconstruïda després de l'alliberament del Punt Zero.",
  "ar": "تُحفظ الخريطة السابقة هنا للحفاظ على أثر الجزيرة المُعاد بناؤها بعد تحرير النقطة صفر."
 },
 "La clé de toute l'histoire": {
  "en": "The key to the whole story",
  "es": "La clave de toda la historia",
  "it": "La chiave di tutta la storia",
  "ca": "La clau de tota la història",
  "ar": "مفتاح القصة كلها"
 },
 "LA DERNIÈRE BATAILLE CONTRE JEAN": {
  "en": "THE LAST BATTLE AGAINST JEAN",
  "es": "LA ÚLTIMA BATALLA CONTRA JEAN",
  "it": "L’ULTIMA BATTAGLIA CONTRO JEAN",
  "ca": "LA DARRERA BATALLA CONTRA EN JEAN",
  "ar": "المعركة الأخيرة ضد جان"
 },
 "LA DESTRUCTION DU PORTAIL ET L'ÉCLAT MYSTÉRIEUX": {
  "en": "THE DESTRUCTION OF THE PORTAL AND THE MYSTERIOUS SHARD",
  "es": "LA DESTRUCCIÓN DEL PORTAL Y EL DESTELLO MISTERIOSO",
  "it": "LA DISTRUZIONE DEL PORTALE E IL FRAMMENTO MISTERIOSO",
  "ca": "LA DESTRUCCIÓ DEL PORTAL I L’ESCLAT MISTERIÓS",
  "ar": "تدمير البوابة والوميض الغامض"
 },
 "La lumière dans le ciel après la bataille provenait de la machine de Jean détruite. Jean s’est désintégré en étoile. Aucun signal hostile n’a été associé à cette lumière.": {
  "en": "The light in the sky after the battle came from Jean's destroyed machine. Jean disintegrated into a star. No hostile signal was associated with that light.",
  "es": "La luz en el cielo tras la batalla provenía de la máquina destruida de Jean. Jean se desintegró en estrella. Ninguna señal hostil se asoció a esa luz.",
  "it": "La luce nel cielo dopo la battaglia proveniva dalla macchina distrutta di Jean. Jean si è disintegrato in una stella. Nessun segnale ostile è stato associato a quella luce.",
  "ca": "La llum al cel després de la batalla provenia de la màquina destruïda d'en Jean. En Jean es va desintegrar en estrella. Cap senyal hostil no es va associar a aquesta llum.",
  "ar": "الضوء في السماء بعد المعركة كان من آلة جان المدمَّرة. تحلَّل جان إلى نجمة. ولم تُربط أي إشارة معادية بذلك الضوء."
 },
 "La machine qui permet à Jean de retrouver ceux qu'il veut faire disparaître. J'ai contribué à sa création, et je ne pourrai jamais effacer cette faute.": {
  "en": "The machine that allows Jean to find those he wants to make disappear. I helped create it, and I will never be able to erase that fault.",
  "es": "La máquina que permite a Jean encontrar a quienes quiere hacer desaparecer. Contribuí a crearla y nunca podré borrar esa culpa.",
  "it": "La macchina che permette a Jean di trovare coloro che vuole far sparire. Ho contribuito a crearla e non potrò mai cancellare quella colpa.",
  "ca": "La màquina que permet a en Jean trobar aquells que vol fer desaparèixer. Vaig contribuir a crear-la i mai no podré esborrar aquesta culpa.",
  "ar": "الآلة التي تتيح لجان إيجاد من يريد إخفاءهم. ساهمت في صنعها، ولن أستطيع أبدًا محو ذلك الذنب."
 },
 "La menace future :": {
  "en": "The future threat:",
  "es": "La amenaza futura:",
  "it": "La minaccia futura:",
  "ca": "L’amenaça futura:",
  "ar": "التهديد المستقبلي:"
 },
 "LA MORT DE JEAN ET LA LIBÉRATION DU POINT ZÉRO": {
  "en": "JEAN'S DEATH AND THE RELEASE OF POINT ZERO",
  "es": "LA MUERTE DE JEAN Y LA LIBERACIÓN DEL PUNTO CERO",
  "it": "LA MORTE DI JEAN E LA LIBERAZIONE DEL PUNTO ZERO",
  "ca": "LA MORT D’EN JEAN I L’ALLIBERAMENT DEL PUNT ZERO",
  "ar": "موت جان وتحرير النقطة صفر"
 },
 "La première rencontre": {
  "en": "The first meeting",
  "es": "El primer encuentro",
  "it": "Il primo incontro",
  "ca": "La primera trobada",
  "ar": "اللقاء الأول"
 },
 "la raison exacte de sa venue, les circonstances de sa dispute avec Jean et le contenu de son aventure avec Olie.": {
  "en": "the exact reason for his arrival, the circumstances of his dispute with Jean and the content of his adventure with Olie.",
  "es": "la razón exacta de su llegada, las circunstancias de su disputa con Jean y el contenido de su aventura con Olie.",
  "it": "la ragione esatta del suo arrivo, le circostanze della sua lite con Jean e il contenuto della sua avventura con Olie.",
  "ca": "la raó exacta de la seva arribada, les circumstàncies de la seva disputa amb en Jean i el contingut de la seva aventura amb l’Olie.",
  "ar": "السبب الدقيق لحضوره، وظروف خلافه مع جان، ومضمون مغامرته مع أولي."
 },
 "LA RÉALITÉ 0": {
  "en": "REALITY 0",
  "es": "REALIDAD 0",
  "it": "REALTÀ 0",
  "ca": "REALITAT 0",
  "ar": "الواقع 0"
 },
 "La réalité a été reconstruite.": {
  "en": "Reality has been rebuilt.",
  "es": "La realidad ha sido reconstruida.",
  "it": "La realtà è stata ricostruita.",
  "ca": "La realitat s’ha reconstruït.",
  "ar": "أُعيد بناء الواقع."
 },
 "LA RÉALITÉ N'EST JAMAIS UNIQUE.": {
  "en": "REALITY IS NEVER UNIQUE.",
  "es": "LA REALIDAD NUNCA ES ÚNICA.",
  "it": "LA REALTÀ NON È MAI UNICA.",
  "ca": "LA REALITAT MAI NO ÉS ÚNICA.",
  "ar": "الواقع ليس فريدًا أبدًا."
 },
 "La Saison 8 se déroule sur une île reconstruite. La nouvelle carte présente notamment Esclate Root, The Prison, Greasy Groove, Holy Hedge, Campagn Liberty, Burd, Boulevard Cinema, Risky Reels, Tilted Jool, Frenzy Gold, Happy Nightmare, Base de Ben, Lavish Tools, le Point Zéro — désormais sur une petite île au milieu de la rivière — et le Sanctuaire Sampiternel.": {
  "en": "Season 8 takes place on a rebuilt island. The new map features Esclate Root, The Prison, Greasy Groove, Holy Hedge, Campagn Liberty, Burd, Boulevard Cinema, Risky Reels, Tilted Jool, Frenzy Gold, Happy Nightmare, Ben's Base, Lavish Tools, Point Zero — now on a small island in the middle of the river — and the Sampiternel Sanctuary.",
  "es": "La Temporada 8 se desarrolla en una isla reconstruida. El nuevo mapa presenta, entre otros, Esclate Root, The Prison, Greasy Groove, Holy Hedge, Campagn Liberty, Burd, Boulevard Cinema, Risky Reels, Tilted Jool, Frenzy Gold, Happy Nightmare, la Base de Ben, Lavish Tools, el Punto Cero — ahora en una pequeña isla en medio del río — y el Santuario Sampiternel.",
  "it": "La Stagione 8 si svolge su un’isola ricostruita. La nuova mappa presenta tra gli altri Esclate Root, The Prison, Greasy Groove, Holy Hedge, Campagn Liberty, Burd, Boulevard Cinema, Risky Reels, Tilted Jool, Frenzy Gold, Happy Nightmare, la Base di Ben, Lavish Tools, il Punto Zero — ora su una piccola isola in mezzo al fiume — e il Santuario Sampiternel.",
  "ca": "La Temporada 8 es desenvolupa en una illa reconstruïda. El nou mapa presenta, entre d’altres, Esclate Root, The Prison, Greasy Groove, Holy Hedge, Campagn Liberty, Burd, Boulevard Cinema, Risky Reels, Tilted Jool, Frenzy Gold, Happy Nightmare, la Base d’en Ben, Lavish Tools, el Punt Zero — ara en una petita illa al mig del riu — i el Santuari Sampiternel.",
  "ar": "يحدث الموسم 8 على جزيرة أُعيد بناؤها. تعرض الخريطة الجديدة أماكن مثل Esclate Root وThe Prison وGreasy Groove وHoly Hedge وCampagn Liberty وBurd وBoulevard Cinema وRisky Reels وTilted Jool وFrenzy Gold وHappy Nightmare وقاعدة بن وLavish Tools والنقطة صفر — الآن على جزيرة صغيرة وسط النهر — وملاذ Sampiternel."
 },
 "La sécurité a détecté notre accès. Ben, il nous reste moins d'une minute.": {
  "en": "Security has detected our access. Ben, we have less than a minute left.",
  "es": "La seguridad ha detectado nuestro acceso. Ben, nos queda menos de un minuto.",
  "it": "La sicurezza ha rilevato il nostro accesso. Ben, ci resta meno di un minuto.",
  "ca": "La seguretat ha detectat el nostre accés. Ben, ens queda menys d'un minut.",
  "ar": "رصدت الأمن عملية وصولنا. بن، لم يتبقَّ لنا سوى أقل من دقيقة."
 },
 "La transmission s’interrompt. Sur la carte, un nouveau signal apparaît sous Freaky Zero. Il ne vient pas du ciel. Il vient de sous l’île.": {
  "en": "The transmission cuts out. On the map, a new signal appears beneath Freaky Zero. It does not come from the sky. It comes from beneath the island.",
  "es": "La transmisión se interrumpe. En el mapa, aparece una nueva señal bajo Freaky Zero. No viene del cielo. Viene de debajo de la isla.",
  "it": "La trasmissione si interrompe. Sulla mappa appare un nuovo segnale sotto Freaky Zero. Non viene dal cielo. Viene da sotto l’isola.",
  "ca": "La transmissió s’interromp. Al mapa, apareix un nou senyal sota Freaky Zero. No ve del cel. Ve de sota l’illa.",
  "ar": "ينقطع البث. على الخريطة، تظهر إشارة جديدة تحت فريكي زيرو. لا تأتي من السماء. إنها تأتي من تحت الجزيرة."
 },
 "LANCER LE TERMINAL": {
  "en": "LAUNCH THE TERMINAL",
  "es": "ABRIR LA TERMINAL",
  "it": "AVVIA IL TERMINALE",
  "ca": "OBRE LA TERMINAL",
  "ar": "تشغيل الطرفية"
 },
 "LAT 00.265": {
  "en": "LAT 00.265",
  "es": "LAT 00.265",
  "it": "LAT 00.265",
  "ca": "LAT 00.265",
  "ar": "LAT 00.265"
 },
 "Lavish Rools": {
  "en": "Lavish Rools",
  "es": "Lavish Rools",
  "it": "Lavish Rools",
  "ca": "Lavish Rools",
  "ar": "Lavish Rools"
 },
 "Lavish Tools": {
  "en": "Lavish Tools",
  "es": "Lavish Tools",
  "it": "Lavish Tools",
  "ca": "Lavish Tools",
  "ar": "Lavish Tools"
 },
 "Lazy Lake": {
  "en": "Lazy Lake",
  "es": "Lazy Lake",
  "it": "Lazy Lake",
  "ca": "Lazy Lake",
  "ar": "Lazy Lake"
 },
 "LAZY LAKE": {
  "en": "LAZY LAKE",
  "es": "LAZY LAKE",
  "it": "LAZY LAKE",
  "ca": "LAZY LAKE",
  "ar": "LAZY LAKE"
 },
 "LE BASCULEMENT DE JEAN": {
  "en": "JEAN'S TURNING POINT",
  "es": "EL GIRO DE JEAN",
  "it": "LA SVOLTA DI JEAN",
  "ca": "EL GIR D’EN JEAN",
  "ar": "تحوُّل جان"
 },
 "LE COMPLOT CONTRE JEAN": {
  "en": "THE PLOT AGAINST JEAN",
  "es": "LA CONSPIRACIÓN CONTRA JEAN",
  "it": "LA CONGIURA CONTRO JEAN",
  "ca": "LA CONSPIRACIÓ CONTRA EN JEAN",
  "ar": "المؤامرة ضد جان"
 },
 "Le dernier avertissement": {
  "en": "The last warning",
  "es": "La última advertencia",
  "it": "L'ultimo avvertimento",
  "ca": "L'últim advertiment",
  "ar": "التحذير الأخير"
 },
 "Le dernier fragment du deuxième Point Zéro était entre les mains des alliés au moment où Jean a déclenché son plan final. Il a permis de le vaincre.": {
  "en": "The last fragment of the second Point Zero was in the allies' hands when Jean triggered his final plan. It allowed them to defeat him.",
  "es": "El último fragmento del segundo Punto Cero estaba en manos de los aliados cuando Jean activó su plan final. Permitió vencerlo.",
  "it": "L'ultimo frammento del secondo Punto Zero era nelle mani degli alleati quando Jean ha attivato il suo piano finale. Ha permesso di sconfiggerlo.",
  "ca": "L'últim fragment del segon Punt Zero era a les mans dels aliats quan en Jean va activar el seu pla final. Va permetre vèncer-lo.",
  "ar": "كانت الشظية الأخيرة من النقطة صفر الثانية في أيدي الحلفاء حين أطلق جان خطته الأخيرة. وقد مكَّنتهم من هزيمته."
 },
 "Le dîner fatal, la disparition d'Aidan, la survie de Ben, le retour en arrière, la Réalité 0 et le piège tendu à Frenzy Gold conduisent à la fin connue : Voss pousse Jean dans le portail, puis détruit celui-ci. L'énergie se disperse et un éclat inconnu s'écrase sur plusieurs points de la réalité.": {
  "en": "The fatal dinner, Aidan's disappearance, Ben's survival, the flashback, Reality 0 and the trap set for Frenzy Gold lead to the known ending: Voss pushes Jean into the portal, then destroys it. The energy disperses and an unknown shard crashes down on several points of reality.",
  "es": "La cena fatal, la desaparición de Aidan, la supervivencia de Ben, el retroceso, la Realidad 0 y la trampa tendida a Frenzy Gold conducen al final conocido: Voss empuja a Jean al portal y luego lo destruye. La energía se dispersa y un destello desconocido se estrella en varios puntos de la realidad.",
  "it": "La cena fatale, la scomparsa di Aidan, la sopravvivenza di Ben, il ritorno indietro, la Realtà 0 e la trappola tesa a Frenzy Gold conducono al finale noto: Voss spinge Jean nel portale, poi lo distrugge. L'energia si disperde e un frammento sconosciuto si schianta su diversi punti della realtà.",
  "ca": "El sopar fatal, la desaparició de l'Aidan, la supervivència d'en Ben, el retorn enrere, la Realitat 0 i el parany parat a Frenzy Gold condueixen al final conegut: en Voss empeny en Jean dins del portal i després el destrueix. L'energia es dispersa i un esclat desconegut s'estavella en diversos punts de la realitat.",
  "ar": "العشاء القاتل، واختفاء أيدن، ونجاة بن، والعودة إلى الماضي، والواقع 0، والفخّ المنصوب لفرينزي غولد، تقود كلها إلى النهاية المعروفة: يدفع فوس جان داخل البوابة ثم يدمّرها. تتناثر الطاقة ويسقط وميض مجهول على عدة نقاط من الواقع."
 },
 "Le dossier ne prétend pas que ces parents sont morts, ni qu'ils sont présents dans la chronologie actuelle. Il conserve seulement une version de leur passé dans laquelle ils sont vivants. La manière dont ce souvenir a été préservé — ou fabriqué — reste à découvrir.": {
  "en": "The file does not claim that these parents are dead, nor that they are present in the current timeline. It preserves only a version of their past in which they are alive. How this memory was preserved — or fabricated — remains to be discovered.",
  "es": "El expediente no afirma que estos padres estén muertos, ni que estén presentes en la cronología actual. Solo conserva una versión de su pasado en la que están vivos. Cómo se preservó — o se fabricó — este recuerdo está aún por descubrir.",
  "it": "Il fascicolo non afferma che questi genitori siano morti, né che siano presenti nella cronologia attuale. Conserva solo una versione del loro passato in cui sono vivi. Come questo ricordo sia stato preservato — o fabbricato — resta da scoprire.",
  "ca": "L'expedient no afirma que aquests pares siguin morts, ni que siguin presents a la cronologia actual. Només conserva una versió del seu passat en què són vius. Com es va preservar — o es va fabricar — aquest record encara s'ha de descobrir.",
  "ar": "لا يدّعي الملف أن هذين الوالدين ماتا، ولا أنهما حاضرين في التسلسل الزمني الحالي. إنه يحفظ فقط نسخة من ماضيهما كانا فيها أحياء. أما كيفية حفظ هذه الذكرى — أو اختلاقها — فما زالت مجهولة."
 },
 "Le Dr Voss est un spécialiste des phénomènes interdimensionnels qui a étudié le Point Zéro bien avant son effondrement. Méthodique, exigeant et difficile à lire, il a passé des années à mesurer les variations d'énergie, à enregistrer les anomalies et à tenter de comprendre pourquoi certaines réalités semblaient se rapprocher les unes des autres. Il parle rarement de ses émotions : il préfère les graphiques, les hypothèses et les résultats vérifiables.": {
  "en": "Dr Voss is a specialist in interdimensional phenomena who studied Point Zero long before its collapse. Methodical, demanding and hard to read, he spent years measuring energy variations, recording anomalies and trying to understand why certain realities seemed to draw closer to one another. He rarely speaks of his emotions: he prefers graphs, hypotheses and verifiable results.",
  "es": "El Dr. Voss es un especialista en fenómenos interdimensionales que estudió el Punto Cero mucho antes de su colapso. Metódico, exigente y difícil de leer, pasó años midiendo las variaciones de energía, registrando las anomalías e intentando comprender por qué ciertas realidades parecían acercarse unas a otras. Rara vez habla de sus emociones: prefiere los gráficos, las hipótesis y los resultados verificables.",
  "it": "Il Dott. Voss è uno specialista di fenomeni inter-dimensionali che ha studiato il Punto Zero molto prima del suo collasso. Metodico, esigente e difficile da leggere, ha passato anni a misurare le variazioni di energia, a registrare le anomalie e a cercare di capire perché certe realtà sembrassero avvicinarsi le une alle altre. Parla raramente delle sue emozioni: preferisce i grafici, le ipotesi e i risultati verificabili.",
  "ca": "El Dr. Voss és un especialista en fenòmens interdimensionales que va estudiar el Punt Zero molt abans del seu col·lapse. Metòdic, exigent i difícil de llegir, va passar anys mesurant les variacions d'energia, enregistrant les anomalies i intentant comprendre per què certes realitats semblaven apropar-se les unes a les altres. Poques vegades parla de les seves emocions: prefereix els gràfics, les hipòtesis i els resultats verificables.",
  "ar": "الدكتور فوس متخصص في الظواهر بين الأبعاد، درس النقطة صفر قبل انهيارها بزمن طويل. منهجي ومتشدّد وصعب القراءة، أمضى سنوات في قياس تغيّرات الطاقة، وتسجيل الشذوذات، ومحاولة فهم سبب اقتراب بعض الأواقع من بعضها. نادرًا ما يتحدث عن مشاعره: يفضّل الرسوم البيانية والفرضيات والنتائج القابلة للتحقق."
 },
 "Le Dr Voss est un spécialiste des phénomènes interdimensionnels qui a étudié le Point Zéro bien avant son effondrement. Méthodique, exigeant et difficile à lire, il a passé des années à…": {
  "en": "Dr Voss is a specialist in interdimensional phenomena who studied Point Zero long before its collapse. Methodical, demanding and hard to read, he spent years…",
  "es": "El Dr. Voss es un especialista en fenómenos interdimensionales que estudió el Punto Cero mucho antes de su colapso. Metódico, exigente y difícil de leer, pasó años…",
  "it": "Il Dott. Voss è uno specialista di fenomeni inter-dimensionali che ha studiato il Punto Zero molto prima del suo collasso. Metodico, esigente e difficile da leggere, ha passato anni…",
  "ca": "El Dr. Voss és un especialista en fenòmens interdimensionales que va estudiar el Punt Zero molt abans del seu col·lapse. Metòdic, exigent i difícil de llegir, va passar anys…",
  "ar": "الدكتور فوس متخصص في الظواهر بين الأبعاد، درس النقطة صفر قبل انهيارها بزمن طويل. منهجي ومتشدّد وصعب القراءة، أمضى سنوات في…"
 },
 "Le fichier a été créé à partir de données récupérées pendant les expériences de DECA. Quelqu'un peut l'avoir fabriqué.": {
  "en": "The file was created from data recovered during DECA's experiments. Someone may have fabricated it.",
  "es": "El archivo se creó a partir de datos recuperados durante los experimentos de DECA. Alguien puede haberlo fabricado.",
  "it": "Il file è stato creato da dati recuperati durante gli esperimenti della DECA. Qualcuno potrebbe averlo fabbricato.",
  "ca": "El fitxer es va crear a partir de dades recuperades durant els experiments de DECA. Algú pot haver-lo fabricat.",
  "ar": "أُنشئ الملف من بيانات استُعيدت خلال تجارب DECA. ربما اختلقه أحدهم."
 },
 "LE FRAGMENT": {
  "en": "THE FRAGMENT",
  "es": "EL FRAGMENTO",
  "it": "IL FRAMMENTO",
  "ca": "EL FRAGMENT",
  "ar": "الجزء"
 },
 "LE FRAGMENT ZÉRO": {
  "en": "THE ZERO FRAGMENT",
  "es": "EL FRAGMENTO CERO",
  "it": "IL FRAMMENTO ZERO",
  "ca": "EL FRAGMENT ZERO",
  "ar": "الجزء صفر",
  "zh": "零点碎片"
 },
 "Le Fragment Zéro — accueil": {
  "en": "The Zero Fragment — home",
  "es": "El Fragmento Cero — inicio",
  "it": "Il Frammento Zero — home",
  "ca": "El Fragment Zero — inici",
  "ar": "الجزء صفر — الرئيسية"
 },
 "Le Fragment Zéro — Centre de contrôle": {
  "en": "The Zero Fragment — Control Centre",
  "es": "El Fragmento Cero — Centro de control",
  "it": "Il Frammento Zero — Centro di controllo",
  "ca": "El Fragment Zero — Centre de control",
  "ar": "الجزء صفر — مركز التحكم"
 },
 "Le passé n'efface rien de ce qui arrivera ensuite. Le Point Zéro se fracture, le Voyageur Noir tente d'imposer l'Ultime Réalité, les Zapoteurs interviennent, l'équipe s'agrandit, et la Garde Zéro traverse vers une réalité plus vaste. Jean rassemble les éclats du second Point Zéro et révèle son véritable objectif : une réalité silencieuse, même si elle doit être obtenue par la destruction.": {
  "en": "The past erases nothing of what comes next. Point Zero fractures, the Black Traveller attempts to impose the Ultimate Reality, the Zapoteurs intervene, the team grows, and the Zero Guard crosses into a vaster reality. Jean gathers the shards of the second Point Zero and reveals his true goal: a silent reality, even if it must be obtained through destruction.",
  "es": "El pasado no borra nada de lo que vendrá después. El Punto Cero se fractura, el Viajero Negro intenta imponer la Realidad Última, los Zapoteurs intervienen, el equipo crece y la Guardia Cero cruza hacia una realidad más vasta. Jean reúne los destellos del segundo Punto Cero y revela su verdadero objetivo: una realidad silenciosa, aunque deba obtenerse mediante la destrucción.",
  "it": "Il passato non cancella nulla di ciò che verrà dopo. Il Punto Zero si frattura, il Viaggiatore Nero tenta di imporre la Realtà Ultima, gli Zapoteurs intervengono, la squadra cresce e la Guardia Zero attraversa verso una realtà più vasta. Jean raduna i frammenti del secondo Punto Zero e rivela il suo vero scopo: una realtà silenziosa, anche se dovrà essere ottenuta con la distruzione.",
  "ca": "El passat no esborra res del que vindrà després. El Punt Zero es fractura, el Viatger Negre intenta imposar la Realitat Última, els Zapoteurs intervenen, l'equip creix i la Guàrdia Zero travessa cap a una realitat més vasta. En Jean reuneix els esclats del segon Punt Zero i revela el seu veritable objectiu: una realitat silenciosa, encara que s'hagi d'obtenir mitjançant la destrucció.",
  "ar": "الماضي لا يمحو شيئًا مما سيأتي بعد ذلك. تتصدّع النقطة صفر، ويحاول المسافر الأسود فرض الواقع الأقصى، ويتدخل الزابوتور، وتكبر المجموعة، ويعبر حرس الصفر إلى واقع أوسع. يجمع جان شظايا النقطة صفر الثانية ويكشف هدفه الحقيقي: واقع صامت، حتى لو تحقّق عبر الدمار."
 },
 "LE PIÈGE À FRENZY GOLD": {
  "en": "THE FRENZY GOLD TRAP",
  "es": "LA TRAMPA DE FRENZY GOLD",
  "it": "LA TRAPPOLA DI FRENZY GOLD",
  "ca": "El parany de FRENZY GOLD",
  "ar": "فخّ فرينزي غولد"
 },
 "Le Point Zéro a fait apparaître un fragment rose et violet au centre d’une structure circulaire bleue. Les alliés l’ont récupéré avant Jean. La signature du fragment est liée au deuxième Point Zéro.": {
  "en": "Point Zero brought forth a pink and violet fragment at the centre of a circular blue structure. The allies recovered it before Jean. The fragment's signature is linked to the second Point Zero.",
  "es": "El Punto Cero hizo aparecer un fragmento rosa y violeta en el centro de una estructura circular azul. Los aliados lo recuperaron antes que Jean. La firma del fragmento está ligada al segundo Punto Cero.",
  "it": "Il Punto Zero ha fatto apparire un frammento rosa e viola al centro di una struttura circolare blu. Gli alleati lo hanno recuperato prima di Jean. La firma del frammento è legata al secondo Punto Zero.",
  "ca": "El Punt Zero va fer aparèixer un fragment rosa i violeta al centre d'una estructura circular blava. Els aliats el van recuperar abans que en Jean. La signatura del fragment està lligada al segon Punt Zero.",
  "ar": "أظهرت النقطة صفر شظية وردية بنفسجية في مركز بنية دائرية زرقاء. استرجعها الحلفاء قبل جان. وتوقيع الشظية مرتبط بالنقطة صفر الثانية."
 },
 "Le Point Zéro fait apparaître un fragment rose et violet au centre d’une structure circulaire bleue, semblable à un sanctuaire. Olie, Ben et leurs alliés récupèrent le fragment avant que Jean puisse s’en emparer. Les monolithes violets sont visibles depuis la carte et depuis le sol : leur présence devient un élément majeur de la bataille.": {
  "en": "Point Zero brings forth a pink and violet fragment at the centre of a circular blue structure resembling a sanctuary. Olie, Ben and their allies recover the fragment before Jean can seize it. The violet monoliths are visible from the map and from the ground: their presence becomes a major element of the battle.",
  "es": "El Punto Cero hace aparecer un fragmento rosa y violeta en el centro de una estructura circular azul, semejante a un santuario. Olie, Ben y sus aliados recuperan el fragmento antes de que Jean pueda apoderarse de él. Los monolitos violetas son visibles desde el mapa y desde el suelo: su presencia se convierte en un elemento clave de la batalla.",
  "it": "Il Punto Zero fa apparire un frammento rosa e viola al centro di una struttura circolare blu, simile a un santuario. Olie, Ben e i loro alleati recuperano il frammento prima che Jean possa impadronirsene. I monoliti viola sono visibili dalla mappa e dal suolo: la loro presenza diventa un elemento centrale della battaglia.",
  "ca": "El Punt Zero fa aparèixer un fragment rosa i violeta al centre d’una estructura circular blava, semblant a un santuari. L’Olie, en Ben i els seus aliats recuperen el fragment abans que en Jean se’n pugui apoderar. Els monòlits violeta són visibles des del mapa i des del terra: la seva presència esdevé un element clau de la batalla.",
  "ar": "تُظهر النقطة صفر شظية وردية بنفسجية في مركز بنية دائرية زرقاء تشبه ملاذًا. يسترجع أولي وبن وحلفاؤهم الشظية قبل أن يتمكن جان من الاستيلاء عليها. المسلّات البنفسجية مرئية من الخريطة ومن الأرض: ويصبح حضورها عنصرًا رئيسيًا في المعركة."
 },
 "Le récit complet, depuis l'arrivée de Jean, du Docteur Voss et de Ben jusqu'à la chute de Jean dans le portail et l'apparition de l'éclat mystérieux. Les mystères encore ouverts restent volontairement sans réponse.": {
  "en": "The complete story, from the arrival of Jean, Doctor Voss and Ben to Jean's fall into the portal and the appearance of the mysterious shard. The mysteries still open are deliberately left unanswered.",
  "es": "El relato completo, desde la llegada de Jean, el doctor Voss y Ben hasta la caída de Jean en el portal y la aparición del destello misterioso. Los misterios aún abiertos quedan deliberadamente sin respuesta.",
  "it": "Il racconto completo, dall’arrivo di Jean, del Dottor Voss e di Ben fino alla caduta di Jean nel portale e all’apparizione del frammento misterioso. I misteri ancora aperti restano volutamente senza risposta.",
  "ca": "El relat complet, des de l’arribada d’en Jean, el doctor Voss i en Ben fins a la caiguda d’en Jean al portal i l’aparició de l’esclat misteriós. Els misteris encara oberts queden deliberadament sense resposta.",
  "ar": "السرد الكامل، من وصول جان والدكتور فوس وبن إلى سقوط جان في البوابة وظهور الوميض الغامض. الألغاز التي لم تُحَلّ تُركت عمدًا بلا إجابة."
 },
 "LE RETOUR EN ARRIÈRE": {
  "en": "THE FLASHBACK",
  "es": "EL RETROCESO",
  "it": "IL RITORNO INDIETRO",
  "ca": "EL RETORN ENRERE",
  "ar": "العودة إلى الوراء"
 },
 "le signal contient deux signatures différentes : l'une ressemble à Aidan, l'autre ne correspond à aucun fichier connu.": {
  "en": "the signal contains two different signatures: one resembles Aidan, the other matches no known file.",
  "es": "la señal contiene dos firmas diferentes: una se parece a Aidan, la otra no corresponde a ningún archivo conocido.",
  "it": "il segnale contiene due firme diverse: una somiglia ad Aidan, l’altra non corrisponde a nessun file noto.",
  "ca": "el senyal conté dues signatures diferents: una s’assembla a Aidan, l’altra no correspon a cap fitxer conegut.",
  "ar": "تحتوي الإشارة على توقيعين مختلفين: أحدهما يشبه أيدن، والآخر لا يطابق أي ملف معروف."
 },
 "LE SIGNAL SOUS FREAKY ZERO": {
  "en": "THE SIGNAL BENEATH FREAKY ZERO",
  "es": "LA SEÑAL BAJO FREAKY ZERO",
  "it": "IL SEGNALE SOTTO FREAKY ZERO",
  "ca": "EL SENYAL SOTA FREAKY ZERO",
  "ar": "الإشارة تحت فريكي زيرو"
 },
 "Le souvenir qui n'aurait jamais dû exister": {
  "en": "The memory that should never have existed",
  "es": "El recuerdo que nunca debería haber existido",
  "it": "Il ricordo che non sarebbe mai dovuto esistere",
  "ca": "El record que no hauria d'haver existit mai",
  "ar": "الذكرى التي ما كان يجب أن توجد قط"
 },
 "Le terminal de l’équipe s’allume tout seul. Une voix filtrée traverse les haut-parleurs. Elle ne donne aucun nom. Elle prononce seulement une phrase :": {
  "en": "The team's terminal switches on by itself. A filtered voice comes through the speakers. It gives no name. It speaks only one sentence:",
  "es": "El terminal del equipo se enciende solo. Una voz filtrada atraviesa los altavoces. No da ningún nombre. Solo pronuncia una frase:",
  "it": "Il terminale della squadra si accende da solo. Una voce filtrata attraversa gli altoparlanti. Non dice alcun nome. Pronuncia solo una frase:",
  "ca": "El terminal de l’equip s’encén tot sol. Una veu filtrada travessa els altaveus. No dona cap nom. Només pronuncia una frase:",
  "ar": "تُشغَّل طرفية الفريق من تلقاء نفسها. يعبر صوتٌ مُرشَّح مكبّرات الصوت. لا يذكر أي اسم. ينطق جملة واحدة فقط:"
 },
 "Le Vide…": {
  "en": "The Void…",
  "es": "El Vacío…",
  "it": "Il Vuoto…",
  "ca": "El Buit…",
  "ar": "الفراغ…"
 },
 "Le Voyageur Noir prend le contrôle total de Point Zéro. Les défenses de la Garde Zéro s'effondrent. Jean commence, en secret, à soupçonner un lien personnel avec le Vide.": {
  "en": "The Black Traveller takes total control of Point Zero. The Zero Guard's defences collapse. In secret, Jean begins to suspect a personal link to the Void.",
  "es": "El Viajero Negro toma el control total del Punto Cero. Las defensas de la Guardia Cero se derrumban. Jean empieza a sospechar en secreto un vínculo personal con el Vacío.",
  "it": "Il Viaggiatore Nero prende il controllo totale del Punto Zero. Le difese della Guardia Zero crollano. Jean comincia a sospettare in segreto un legame personale con il Vuoto.",
  "ca": "El Viatger Negre pren el control total del Punt Zero. Les defenses de la Guàrdia Zero s’enfonsen. En Jean comença a sospitar en secret un vincle personal amb el Buit.",
  "ar": "يستولي المسافر الأسود على النقطة صفر بالكامل. تنهار دفاعات حرس الصفر. ويبدأ جان سرًّا في الشك بوجود صلة شخصية بينه وبين الفراغ."
 },
 "Le Voyageur Noir tente de faire advenir l'Ultime Réalité. Les Zapoteurs, inconnus de l'équipe mais influents à travers de nombreuses réalités, interviennent et le tranchent en deux avec son propre véhicule, grâce à la puissance du Point Zéro. En privé, loin de Ben et Voss, ils révèlent à Jean que le Vide est son père. Il porte ce secret seul.": {
  "en": "The Black Traveller attempts to bring about the Ultimate Reality. The Zapoteurs, unknown to the team but influential across many realities, intervene and slice him in two with his own vehicle, thanks to the power of Point Zero. In private, far from Ben and Voss, they reveal to Jean that the Void is his father. He bears that secret alone.",
  "es": "El Viajero Negro intenta hacer advenir la Realidad Última. Los Zapoteurs, desconocidos para el equipo pero influyentes en muchas realidades, intervienen y lo parten en dos con su propio vehículo, gracias al poder del Punto Cero. En privado, lejos de Ben y Voss, revelan a Jean que el Vacío es su padre. Él carga con ese secreto solo.",
  "it": "Il Viaggiatore Nero tenta di far avvenire la Realtà Ultima. Gli Zapoteurs, sconosciuti alla squadra ma influenti attraverso molte realtà, intervengono e lo tagliano in due con il suo stesso veicolo, grazie alla potenza del Punto Zero. In privato, lontano da Ben e Voss, rivelano a Jean che il Vuoto è suo padre. Lui porta quel segreto da solo.",
  "ca": "El Viatger Negre intenta fer advenir la Realitat Última. Els Zapoteurs, desconeguts per a l’equip però influents en moltes realitats, intervenen i el parteixen en dos amb el seu propi vehicle, gràcies a la potència del Punt Zero. En privat, lluny d’en Ben i en Voss, revelen a en Jean que el Buit és son pare. Ell carrega aquest secret tot sol.",
  "ar": "يحاول المسافر الأسود إحلال الواقع الأقصى. يتدخل الزابوتور، وهم مجهولون للفريق لكنهم مؤثرون في realities كثيرة، ويشقّونه إلى نصفين بمركبته نفسها، بفضل قوة النقطة صفر. وفي الخفاء، بعيدًا عن بن وفوس، يكشفون لجان أن الفراغ هو والده. ويحمل جان هذا السر وحده."
 },
 "Les": {
  "en": "The",
  "es": "Los",
  "it": "I",
  "ca": "Els",
  "ar": "الـ"
 },
 "Les années passent. Jean devient un homme capable de lire les failles et de voir des motifs que les autres ne remarquent pas. Ben devient un survivant qui cherche d'abord à comprendre avant de frapper. Le Docteur Voss, les recherches sur Point Zéro et les premières menaces de l'Ordre finissent par les conduire sur la même île.": {
  "en": "The years pass. Jean becomes a man able to read rifts and see patterns others do not notice. Ben becomes a survivor who seeks first to understand before striking. Doctor Voss, the research on Point Zero and the first threats of the Order eventually lead them to the same island.",
  "es": "Pasan los años. Jean se convierte en un hombre capaz de leer las fallas y ver patrones que otros no advierten. Ben se convierte en un superviviente que busca primero comprender antes de golpear. El doctor Voss, las investigaciones sobre el Punto Cero y las primeras amenazas del Orden acaban llevándolos a la misma isla.",
  "it": "Gli anni passano. Jean diventa un uomo capace di leggere le faglie e vedere schemi che gli altri non notano. Ben diventa un sopravvissuto che cerca prima di capire, poi di colpire. Il Dottor Voss, le ricerche sul Punto Zero e le prime minacce dell'Ordine finiscono per condurli sulla stessa isola.",
  "ca": "Passen els anys. En Jean es converteix en un home capaç de llegir les fractures i veure patrons que els altres no noten. En Ben es converteix en un supervivent que primer busca comprendre abans de colpejar. El doctor Voss, les recerques sobre el Punt Zero i les primeres amenaces de l'Orde acaben conduint-los a la mateixa illa.",
  "ar": "تمرّ السنوات. يصبح جان رجلًا قادرًا على قراءة التصدُّعات ورؤية أنماط لا يلاحظها الآخرون. ويصبح بن ناجيًا يسعى أولًا إلى الفهم قبل الضرب. الدكتور فوس، وأبحاث النقطة صفر، والتهديدات الأولى للنظام، تقودهم في النهاية إلى الجزيرة نفسها."
 },
 "Les archives ne prouvent pas que ces deux anomalies étaient liées. Elles portent toutefois une signature proche de celle que les chercheurs identifieraient bien plus tard autour du Point Zéro. Le lien exact demeure inconnu.": {
  "en": "The archives do not prove that these two anomalies were linked. They nevertheless carry a signature close to the one researchers would identify much later around Point Zero. The exact link remains unknown.",
  "es": "Los archivos no prueban que estas dos anomalías estuvieran ligadas. Sin embargo, llevan una firma cercana a la que los investigadores identificarían mucho más tarde alrededor del Punto Cero. El vínculo exacto sigue siendo desconocido.",
  "it": "Gli archivi non provano che queste due anomalie fossero legate. Portano tuttavia una firma vicina a quella che i ricercatori avrebbero identificato molto più tardi intorno al Punto Zero. Il legame esatto resta sconosciuto.",
  "ca": "Els arxius no proven que aquestes dues anomalies estiguessin lligades. Tanmateix, porten una signatura propera a la que els investigadors identificarien molt més tard al voltant del Punt Zero. El vincle exacte continua sent desconegut.",
  "ar": "لا تُثبت الأرشيفات أن هذين الشذوذين كانا مرتبطين. لكنهما يحملان توقيعًا قريبًا من ذلك الذي سيتعرّف عليه الباحثون لاحقًا بزمن طويل حول النقطة صفر. الصلة الدقيقة لا تزال مجهولة."
 },
 "Les bords de la carte et les débris visibles ne signalent pas une nouvelle anomalie : l’île a été reconstruite depuis longtemps. La lumière aperçue dans le ciel après la bataille était celle de la machine de Jean détruite, pas l’annonce d’une attaque.": {
  "en": "The edges of the map and the visible debris do not signal a new anomaly: the island was rebuilt long ago. The light seen in the sky after the battle was that of Jean's destroyed machine, not the announcement of an attack.",
  "es": "Los bordes del mapa y los restos visibles no señalan una nueva anomalía: la isla fue reconstruida hace mucho tiempo. La luz vista en el cielo tras la batalla era la de la máquina destruida de Jean, no el anuncio de un ataque.",
  "it": "I bordi della mappa e i detriti visibili non segnalano una nuova anomalia: l'isola è stata ricostruita molto tempo fa. La luce vista nel cielo dopo la battaglia era quella della macchina distrutta di Jean, non l'annuncio di un attacco.",
  "ca": "Les vores del mapa i les restes visibles no assenyalen una nova anomalia: l'illa va ser reconstruïda fa molt de temps. La llum vista al cel després de la batalla era la de la màquina destruïda d'en Jean, no l'anunci d'un atac.",
  "ar": "حواف الخريطة والحطام الظاهر لا تشير إلى شذوذ جديد: فقد أُعيد بناء الجزيرة منذ زمن طويل. والضوء الذي رُئي في السماء بعد المعركة كان ضوء آلة جان المدمَّرة، لا إعلان هجوم."
 },
 "Les chemins se rejoignent": {
  "en": "The paths converge",
  "es": "Los caminos se unen",
  "it": "Le strade si incontrano",
  "ca": "Els camins es troben",
  "ar": "تلتقي الدروب"
 },
 "Les enfants": {
  "en": "The children",
  "es": "Los niños",
  "it": "I bambini",
  "ca": "Els nens",
  "ar": "الأطفال"
 },
 "Les événements, de la naissance de la Garde Zéro au signal actuel.": {
  "en": "The events, from the birth of the Zero Guard to the current signal.",
  "es": "Los acontecimientos, desde el nacimiento de la Guardia Cero hasta la señal actual.",
  "it": "Gli eventi, dalla nascita della Guardia Zero al segnale attuale.",
  "ca": "Els esdeveniments, del naixement de la Guàrdia Zero al senyal actual.",
  "ar": "الأحداث، من ولادة حرس الصفر إلى الإشارة الحالية."
 },
 "Les membres de l'équipe, leurs liens et les secrets qui les entourent.": {
  "en": "The team members, their bonds and the secrets around them.",
  "es": "Los miembros del equipo, sus vínculos y los secretos que los rodean.",
  "it": "I membri della squadra, i loro legami e i segreti che li circondano.",
  "ca": "Els membres de l’equip, els seus vincles i els secrets que els envolten.",
  "ar": "أعضاء الفريق، روابطهم والأسرار المحيطة بهم."
 },
 "Les premières mesures ne ressemblent à aucune énergie connue. Le signal apparaît sous la forêt de Freaky Zero, puis disparaît dès qu'une équipe approche. Voss refuse de conclure à une nouvelle menace sans preuve. Ben, lui, reconnaît un détail dans les impulsions.": {
  "en": "The first readings match no known energy. The signal appears beneath the Freaky Zero forest, then vanishes as soon as a team approaches. Voss refuses to call it a new threat without proof. Ben, however, recognises a detail in the pulses.",
  "es": "Las primeras mediciones no se parecen a ninguna energía conocida. La señal aparece bajo el bosque de Freaky Zero y desaparece en cuanto un equipo se acerca. Voss se niega a concluir que sea una nueva amenaza sin pruebas. Ben, en cambio, reconoce un detalle en las pulsaciones.",
  "it": "Le prime misurazioni non somigliano a nessuna energia conosciuta. Il segnale appare sotto la foresta di Freaky Zero, poi svanisce appena una squadra si avvicina. Voss rifiuta di concludere che sia una nuova minaccia senza prove. Ben, invece, riconosce un dettaglio nelle pulsazioni.",
  "ca": "Les primeres mesures no s’assemblen a cap energia coneguda. El senyal apareix sota el bosc de Freaky Zero i desapareix tan bon punt un equip s’hi acosta. Voss es nega a concloure que sigui una nova amenaça sense proves. En Ben, en canvi, reconeix un detall en les pulsacions.",
  "ar": "القياسات الأولى لا تشبه أي طاقة معروفة. تظهر الإشارة تحت غابة فريكي زيرو، ثم تختفي بمجرد اقتراب فريق. يرفض فوس اعتبارها تهديدًا جديدًا دون دليل. أما بن فيلاحظ تفصيلًا في النبضات."
 },
 "Les questions encore ouvertes": {
  "en": "The questions still open",
  "es": "Las preguntas aún abiertas",
  "it": "Le domande ancora aperte",
  "ca": "Les preguntes encara obertes",
  "ar": "الأسئلة التي لم تُحَلّ بعد"
 },
 "Les scènes sont fictives et font partie de cette fan-fiction.": {
  "en": "The scenes are fictional and part of this fan fiction.",
  "es": "Las escenas son ficticias y forman parte de este fan-fiction.",
  "it": "Le scene sono fittizie e fanno parte di questa fan-fiction.",
  "ca": "Les escenes són fictícies i formen part d'aquest fan-fiction.",
  "ar": "المشاهد خيالية وجزء من هذه القصة غير الرسمية."
 },
 "Les yeux de qui ?": {
  "en": "Whose eyes?",
  "es": "¿Los ojos de quién?",
  "it": "Gli occhi di chi?",
  "ca": "Els ulls de qui?",
  "ar": "عيون من؟"
 },
 "LIBÉRÉ": {
  "en": "RELEASED",
  "es": "LIBERADO",
  "it": "LIBERATO",
  "ca": "ALLIBERAT",
  "ar": "محرَّر"
 },
 "Libéré de toute sa puissance, le Point Zéro restaure certaines villes qui étaient encore corrompues. L’île retrouve un équilibre. L’histoire n’est pourtant pas terminée : une menace plus grande que Jean existe, mais elle ne se manifestera pas tout de suite.": {
  "en": "Freed of all its power, Point Zero restores some cities that were still corrupted. The island finds its balance again. The story is not over, however: a threat greater than Jean exists, but it will not show itself straight away.",
  "es": "Liberado de todo su poder, el Punto Cero restaura algunas ciudades que aún estaban corrompidas. La isla recupera un equilibrio. La historia, sin embargo, no ha terminado: existe una amenaza mayor que Jean, pero no se manifestará de inmediato.",
  "it": "Liberato di tutta la sua potenza, il Punto Zero ripristina alcune città ancora corrotte. L’isola ritrova un equilibrio. La storia però non è finita: esiste una minaccia più grande di Jean, ma non si manifesterà subito.",
  "ca": "Alliberat de tot el seu poder, el Punt Zero restaura algunes ciutats que encara estaven corruptes. L’illa recupera un equilibri. La història, però, no s’ha acabat: existeix una amenaça més gran que en Jean, però no es manifestarà de seguida.",
  "ar": "بعد تحرُّره من كل قوته، يعيد النقطة صفر بعض المدن التي كانت لا تزال فاسدة. تستعيد الجزيرة توازنها. لكن القصة لم تنتهِ: هناك تهديد أكبر من جان، لكنه لن يظهر فورًا."
 },
 "Liens connus :": {
  "en": "Known links:",
  "es": "Vínculos conocidos:",
  "it": "Legami noti:",
  "ca": "Vincles coneguts:",
  "ar": "الروابط المعروفة:"
 },
 "Lieu au centre de l’île.": {
  "en": "Location at the centre of the island.",
  "es": "Lugar en el centro de la isla.",
  "it": "Luogo al centro dell'isola.",
  "ca": "Lloc al centre de l'illa.",
  "ar": "موقع في وسط الجزيرة."
 },
 "Lieu implanté dans les bois à l’est.": {
  "en": "Place set in the woods to the east.",
  "es": "Lugar enclavado en los bosques al este.",
  "it": "Luogo immerso nei boschi a est.",
  "ca": "Lloc situat als boscos a l'est.",
  "ar": "مكان وسط الغابات شرقًا."
 },
 "Lieux identifiés": {
  "en": "Identified locations",
  "es": "Lugares identificados",
  "it": "Luoghi identificati",
  "ca": "Llocs identificats",
  "ar": "مواقع محدَّدة"
 },
 "Lire « Celui qui se souvient du Point Zéro » (.txt)": {
  "en": "Read « The One Who Remembers Point Zero » (.txt)",
  "es": "Leer « El que recuerda el Punto Cero » (.txt)",
  "it": "Leggi « Colui che ricorda il Punto Zero » (.txt)",
  "ca": "Llegeix « El qui recorda el Punt Zero » (.txt)",
  "ar": "اقرأ «من يتذكّر النقطة صفر» (.txt)"
 },
 "Lire la fiche complète": {
  "en": "Read the full sheet",
  "es": "Leer la ficha completa",
  "it": "Leggi la scheda completa",
  "ca": "Llegeix la fitxa completa",
  "ar": "اقرأ البطاقة الكاملة"
 },
 "Lire le contexte de l'histoire": {
  "en": "Read the story context",
  "es": "Leer el contexto de la historia",
  "it": "Leggi il contesto della storia",
  "ca": "Llegeix el context de la història",
  "ar": "اقرأ سياق القصة"
 },
 "LIRE LE RAPPORT COMPLET": {
  "en": "READ THE FULL REPORT",
  "es": "LEER EL INFORME COMPLETO",
  "it": "LEGGI IL RAPPORTO COMPLETO",
  "ca": "LLEGEIX L’INFORME COMPLET",
  "ar": "اقرأ التقرير الكامل"
 },
 "LOCALISER FREAKY ZERO →": {
  "en": "LOCATE FREAKY ZERO →",
  "es": "LOCALIZAR FREAKY ZERO →",
  "it": "LOCALIZZA FREAKY ZERO →",
  "ca": "LOCALITZA FREAKY ZERO →",
  "ar": "حدِّد موقع فريكي زيرو →"
 },
 "LON 0X.000": {
  "en": "LON 0X.000",
  "es": "LON 0X.000",
  "it": "LON 0X.000",
  "ca": "LON 0X.000",
  "ar": "LON 0X.000"
 },
 "Lorsque Ben et les autres cherchent des réponses, Voss devient une source d'informations essentielle, mais pas forcément un allié facile. Il pense que la vérité doit être découverte dans le bon ordre et redoute qu'une révélation trop précoce provoque une nouvelle catastrophe. Ses avertissements peuvent sembler froids, surtout quand Ben veut agir immédiatement pour sauver Aidan.": {
  "en": "When Ben and the others seek answers, Voss becomes an essential source of information, but not necessarily an easy ally. He believes the truth must be discovered in the right order and fears that too early a revelation will cause another catastrophe. His warnings can seem cold, especially when Ben wants to act immediately to save Aidan.",
  "es": "Cuando Ben y los demás buscan respuestas, Voss se convierte en una fuente de información esencial, pero no necesariamente en un aliado fácil. Cree que la verdad debe descubrirse en el orden correcto y teme que una revelación demasiado temprana provoque otra catástrofe. Sus advertencias pueden parecer frías, sobre todo cuando Ben quiere actuar de inmediato para salvar a Aidan.",
  "it": "Quando Ben e gli altri cercano risposte, Voss diventa una fonte di informazioni essenziale, ma non necessariamente un alleato facile. Ritiene che la verità debba essere scoperta nell'ordine giusto e teme che una rivelazione troppo precoce provochi un'altra catastrofe. I suoi avvertimenti possono sembrare freddi, soprattutto quando Ben vuole agire subito per salvare Aidan.",
  "ca": "Quan en Ben i els altres busquen respostes, en Voss es converteix en una font d'informació essencial, però no necessàriament en un aliat fàcil. Creu que la veritat s'ha de descobrir en l'ordre correcte i tem que una revelació massa primerenca provoqui una altra catàstrofe. Els seus advertiments poden semblar freds, sobretot quan en Ben vol actuar de seguida per salvar l'Aidan.",
  "ar": "عندما يبحث بن والآخرون عن إجابات، يصبح فوس مصدر معلومات أساسيًّا، لكنه ليس بالضرورة حليفًا سهلًا. يعتقد أن الحقيقة يجب اكتشافها بالترتيب الصحيح، ويخشى أن يؤدي كشفٌ مبكر جدًّا إلى كارثة جديدة. قد تبدو تحذيراته باردة، خصوصًا عندما يريد بن التحرك فورًا لإنقاذ أيدن."
 },
 "Lorsque les Zapoteurs révèlent à Jean que le Vide est son père, une part de son identité se fissure. Il garde cette vérité pour lui. Le dossier ne confirme pas que le Vide a élevé Jean ou qu'il a influencé directement son enfance ; il confirme seulement la révélation faite à Jean par les Zapoteurs.": {
  "en": "When the Zapoteurs reveal to Jean that the Void is his father, part of his identity cracks. He keeps that truth to himself. The file does not confirm that the Void raised Jean or directly influenced his childhood; it confirms only the revelation made to Jean by the Zapoteurs.",
  "es": "Cuando los Zapoteurs revelan a Jean que el Vacío es su padre, una parte de su identidad se resquebraja. Guarda esa verdad para sí. El expediente no confirma que el Vacío criara a Jean ni que influyera directamente en su infancia; solo confirma la revelación que los Zapoteurs hicieron a Jean.",
  "it": "Quando gli Zapoteurs rivelano a Jean che il Vuoto è suo padre, una parte della sua identità si incrina. Tiene quella verità per sé. Il fascicolo non conferma che il Vuoto abbia cresciuto Jean o influenzato direttamente la sua infanzia; conferma solo la rivelazione fatta a Jean dagli Zapoteurs.",
  "ca": "Quan els Zapoteurs revelen a en Jean que el Buit és son pare, una part de la seva identitat es trenca. Guarda aquesta veritat per a ell. L'expedient no confirma que el Buit criés en Jean o influís directament en la seva infància; només confirma la revelació que els Zapoteurs van fer a en Jean.",
  "ar": "عندما يكشف الزابوتور لجان أن الفراغ هو والده، يتصدّع جزء من هويته. يحتفظ بهذه الحقيقة لنفسه. لا يؤكد الملف أن الفراغ ربّى جان أو أثّر مباشرة في طفولته؛ بل يؤكد فقط الكشف الذي قدّمه الزابوتور لجان."
 },
 "Lui.": {
  "en": "Him.",
  "es": "Él.",
  "it": "Lui.",
  "ca": "Ell.",
  "ar": "هو."
 },
 "Mais le silence n'a pas duré.": {
  "en": "But the silence did not last.",
  "es": "Pero el silencio no duró.",
  "it": "Ma il silenzio non è durato.",
  "ca": "Però el silenci no va durar.",
  "ar": "لكن الصمت لم يدم."
 },
 "Mais vous n'avez jamais découvert ce qu'il retenait. »": {
  "en": "But you never discovered what it was holding back. »",
  "es": "Pero nunca descubristeis lo que retenía. »",
  "it": "Ma non avete mai scoperto ciò che tratteneva. »",
  "ca": "Però mai no heu descobert què retenia. »",
  "ar": "لكنكم لم تكتشفوا قط ما كان يحتجزه.»"
 },
 "MESSAGE PRIORITAIRE : « L'intrusion était prévue. Merci d'avoir ouvert le dernier dossier. »": {
  "en": "PRIORITY MESSAGE: « The intrusion was expected. Thank you for opening the last file. »",
  "es": "MENSAJE PRIORITARIO: « La intrusión estaba prevista. Gracias por abrir el último expediente. »",
  "it": "MESSAGGIO PRIORITARIO: « L'intrusione era prevista. Grazie per aver aperto l'ultimo fascicolo. »",
  "ca": "MISSATGE PRIORITARI: « La intrusió estava prevista. Gràcies per obrir l'últim expedient. »",
  "ar": "رسالة ذات أولوية: «كان التسلل متوقعًا. شكرًا لفتحكم الملف الأخير.»"
 },
 "Misty Seven": {
  "en": "Misty Seven",
  "es": "Misty Seven",
  "it": "Misty Seven",
  "ca": "Misty Seven",
  "ar": "Misty Seven"
 },
 "MISTY SEVEN": {
  "en": "MISTY SEVEN",
  "es": "MISTY SEVEN",
  "it": "MISTY SEVEN",
  "ca": "MISTY SEVEN",
  "ar": "MISTY SEVEN"
 },
 "Motivation :": {
  "en": "Motivation:",
  "es": "Motivación:",
  "it": "Motivazione:",
  "ca": "Motivació:",
  "ar": "الدافع:"
 },
 "Navigation principale": {
  "en": "Main navigation",
  "es": "Navegación principal",
  "it": "Navigazione principale",
  "ca": "Navegació principal",
  "ar": "التنقل الرئيسي"
 },
 "NON IDENTIFIÉ": {
  "en": "UNIDENTIFIED",
  "es": "NO IDENTIFICADO",
  "it": "NON IDENTIFICATO",
  "ca": "NO IDENTIFICAT",
  "ar": "غير محدَّد"
 },
 "Non. Il a fui cette île.": {
  "en": "No. He fled this island.",
  "es": "No. Huyó de esta isla.",
  "it": "No. È fuggito da quest'isola.",
  "ca": "No. Va fugir d'aquesta illa.",
  "ar": "لا. لقد هرب من هذه الجزيرة."
 },
 "Non. Je ne l'ai jamais vue.": {
  "en": "No. I have never seen her.",
  "es": "No. Nunca la he visto.",
  "it": "No. Non l'ho mai vista.",
  "ca": "No. No l'he vista mai.",
  "ar": "لا. لم أرها قط."
 },
 "Non… Ce n'est pas possible.": {
  "en": "No… It is not possible.",
  "es": "No… No es posible.",
  "it": "No… Non è possibile.",
  "ca": "No… No és possible.",
  "ar": "لا… هذا غير ممكن."
 },
 "NOTE DE CARTOGRAPHIE": {
  "en": "CARTOGRAPHY NOTE",
  "es": "NOTA DE CARTOGRAFÍA",
  "it": "NOTA DI CARTOGRAFIA",
  "ca": "NOTA DE CARTOGRAFIA",
  "ar": "ملاحظة خرائطية"
 },
 "NOTE DE CONTINUITÉ": {
  "en": "CONTINUITY NOTE",
  "es": "NOTA DE CONTINUIDAD",
  "it": "NOTA DI CONTINUITÀ",
  "ca": "NOTA DE CONTINUÏTAT",
  "ar": "ملاحظة استمرارية"
 },
 "NOUVEAU RÉCIT · CHAPITRE 2 · SAISON 1": {
  "en": "NEW NARRATIVE · CHAPTER 2 · SEASON 1",
  "es": "NUEVO RELATO · CAPÍTULO 2 · TEMPORADA 1",
  "it": "NUOVO RACCONTO · CAPITOLO 2 · STAGIONE 1",
  "ca": "NOU RELAT · CAPÍTOL 2 · TEMPORADA 1",
  "ar": "سرد جديد · الفصل 2 · الموسم 1"
 },
 "NOUVEL ARRIVANT — SAISON 8": {
  "en": "NEW ARRIVAL — SEASON 8",
  "es": "NUEVO LLEGADO — TEMPORADA 8",
  "it": "NUOVO ARRIVO — STAGIONE 8",
  "ca": "NOU ARRIBAT — TEMPORADA 8",
  "ar": "قادم جديد — الموسم 8"
 },
 "NOUVELLE CARTOGRAPHIE // CHAPITRE 2 · SAISON 1": {
  "en": "NEW CARTOGRAPHY // CHAPTER 2 · SEASON 1",
  "es": "NUEVA CARTOGRAFÍA // CAPÍTULO 2 · TEMPORADA 1",
  "it": "NUOVA CARTOGRAFIA // CAPITOLO 2 · STAGIONE 1",
  "ca": "NOVA CARTOGRAFIA // CAPÍTOL 2 · TEMPORADA 1",
  "ar": "خرائط جديدة // الفصل 2 · الموسم 1"
 },
 "Nouvelle zone cartographiée. Les secteurs forestiers, les rivières et les installations autour du Freaky Zero sont désormais répertoriés dans les archives de l’Institut Onirique.": {
  "en": "New area mapped. The forest sectors, rivers and facilities around Freaky Zero are now listed in the archives of the Dream Institute.",
  "es": "Nueva zona cartografiada. Los sectores forestales, los ríos y las instalaciones alrededor de Freaky Zero ya figuran en los archivos del Instituto Onírico.",
  "it": "Nuova zona cartografata. I settori forestali, i fiumi e le installazioni intorno a Freaky Zero sono ora registrati negli archivi dell'Istituto Onirico.",
  "ca": "Nova zona cartografiada. Els sectors forestals, els rius i les instal·lacions al voltant de Freaky Zero ja figuren als arxius de l'Institut Oníric.",
  "ar": "منطقة جديدة مُخرَّطة. أصبحت القطاعات الحرجية والأنهار والمنشآت حول Freaky Zero مدرجة في أرشيف المعهد الحالم."
 },
 "NOYAU CENTRAL": {
  "en": "CENTRAL CORE",
  "es": "NÚCLEO CENTRAL",
  "it": "NUCLEO CENTRALE",
  "ca": "NUCLI CENTRAL",
  "ar": "النواة المركزية"
 },
 "NOYAU FZ": {
  "en": "FZ CORE",
  "es": "NÚCLEO FZ",
  "it": "NUCLEO FZ",
  "ca": "NUCLI FZ",
  "ar": "نواة FZ"
 },
 "OBSERVATEUR — ÉCLaireur": {
  "en": "OBSERVER — SCOUT",
  "es": "OBSERVADOR — EXPLORADOR",
  "it": "OSSERVATORE — ESPLORATORE",
  "ca": "OBSERVADOR — EXPLORADOR",
  "ar": "مراقب — كشّاف"
 },
 "OBSERVATION ACTIVE": {
  "en": "ACTIVE OBSERVATION",
  "es": "OBSERVACIÓN ACTIVA",
  "it": "OSSERVAZIONE ATTIVA",
  "ca": "OBSERVACIÓ ACTIVA",
  "ar": "مراقبة نشطة"
 },
 "Olie": {
  "en": "Olie",
  "es": "Olie",
  "it": "Olie",
  "ca": "Olie",
  "ar": "أولي"
 },
 "OLIE": {
  "en": "OLIE",
  "es": "OLIE",
  "it": "OLIE",
  "ca": "OLIE",
  "ar": "أولي"
 },
 "Olie ? Qu'est-ce qu'il y a ?": {
  "en": "Olie? What is it?",
  "es": "¿Olie? ¿Qué ocurre?",
  "it": "Olie? Che cosa succede?",
  "ca": "Olie? Què passa?",
  "ar": "أولي؟ ما الأمر؟"
 },
 "Olie apparaît après une mystérieuse fracture de réalité. Malgré son état et la confusion qui l'entoure, elle reconnaît immédiatement Ben et affirme être sa sœur, ainsi que celle de Jean. Selon elle, cette parenté leur a été cachée et Jean lui-même ignorait son existence.": {
  "en": "Olie appears after a mysterious reality fracture. Despite her state and the confusion around her, she immediately recognises Ben and claims to be his sister, as well as Jean's. According to her, this kinship was hidden from them and Jean himself was unaware of her existence.",
  "es": "Olie aparece tras una misteriosa fractura de realidad. A pesar de su estado y de la confusión que la rodea, reconoce de inmediato a Ben y afirma ser su hermana, así como la de Jean. Según ella, este parentesco les fue ocultado y el propio Jean ignoraba su existencia.",
  "it": "Olie appare dopo una misteriosa frattura di realtà. Nonostante il suo stato e la confusione che la circonda, riconosce subito Ben e afferma di essere sua sorella, oltre che di Jean. Secondo lei, questa parentela è stata nascosta loro e Jean stesso ignorava la sua esistenza.",
  "ca": "L'Olie apareix després d'una misteriosa fractura de realitat. Malgrat el seu estat i la confusió que l'envolta, reconeix immediatament en Ben i afirma ser la seva germana, així com la d'en Jean. Segons ella, aquest parentiu els va ser amagat i el mateix Jean ignorava la seva existència.",
  "ar": "تظهر أولي بعد تصدُّع غامض في الواقع. رغم حالتها والارتباك المحيط بها، تتعرّف فورًا على بن وتؤكد أنها أخته، وأخت جان أيضًا. وبحسبها، أُخفيت عنهم هذه القرابة، وكان جان نفسه يجهل وجودها."
 },
 "Olie et Kael :": {
  "en": "Olie and Kael:",
  "es": "Olie y Kael:",
  "it": "Olie e Kael:",
  "ca": "Olie i Kael:",
  "ar": "أولي وكايل:"
 },
 "Olie et Kael se connaissent déjà : ils ont vécu une aventure ensemble avant son arrivée sur l'île. Les détails de cette aventure seront révélés plus tard.": {
  "en": "Olie and Kael already know each other: they lived an adventure together before her arrival on the island. The details of that adventure will be revealed later.",
  "es": "Olie y Kael ya se conocen: vivieron una aventura juntos antes de su llegada a la isla. Los detalles de esa aventura se revelarán más adelante.",
  "it": "Olie e Kael si conoscono già: hanno vissuto un'avventura insieme prima del suo arrivo sull'isola. I dettagli di quell'avventura saranno rivelati più avanti.",
  "ca": "L'Olie i en Kael ja es coneixen: van viure una aventura junts abans de la seva arribada a l'illa. Els detalls d'aquesta aventura es revelaran més endavant.",
  "ar": "أولي وكايل يعرفان بعضهما مسبقًا: عاشا مغامرة معًا قبل وصولها إلى الجزيرة. ستُكشف تفاصيل تلك المغامرة لاحقًا."
 },
 "Olie et Kael se connaissent également : ils ont vécu une aventure ensemble. Cette histoire sera racontée plus tard. Pour le moment, les raisons exactes du retour de Kael et ce qu’il sait du Point Zéro restent à découvrir.": {
  "en": "Olie and Kael also know each other: they lived through an adventure together. That story will be told later. For now, the exact reasons for Kael's return and what he knows about Point Zero remain to be discovered.",
  "es": "Olie y Kael también se conocen: vivieron una aventura juntos. Esa historia se contará más adelante. Por ahora, las razones exactas del regreso de Kael y lo que sabe del Punto Cero están por descubrir.",
  "it": "Anche Olie e Kael si conoscono: hanno vissuto un’avventura insieme. Quella storia sarà raccontata più avanti. Per ora, le ragioni esatte del ritorno di Kael e ciò che sa del Punto Zero restano da scoprire.",
  "ca": "L’Olie i en Kael també es coneixen: van viure una aventura junts. Aquesta història es contarà més endavant. Per ara, les raons exactes del retorn d’en Kael i què sap del Punt Zero encara s’han de descobrir.",
  "ar": "أولي وكايل يعرفان بعضهما أيضًا: عاشا مغامرة معًا. ستُروى تلك القصة لاحقًا. أما الآن، فالأسباب الدقيقة لعودة كايل وما يعرفه عن النقطة صفر لا تزال مجهولة."
 },
 "Olie surgit d'un cratère au milieu d'une forêt brûlée. Elle affirme être la sœur de Ben et de Jean, une vérité qu'aucun des deux frères ne connaissait.": {
  "en": "Olie emerges from a crater in the middle of a burnt forest. She claims to be the sister of Ben and Jean, a truth neither of the two brothers knew.",
  "es": "Olie surge de un cráter en medio de un bosque quemado. Afirma ser la hermana de Ben y de Jean, una verdad que ninguno de los dos hermanos conocía.",
  "it": "Olie emerge da un cratere nel mezzo di una foresta bruciata. Afferma di essere la sorella di Ben e di Jean, una verità che nessuno dei due fratelli conosceva.",
  "ca": "L'Olie sorgeix d'un cràter al mig d'un bosc cremat. Afirma ser la germana d'en Ben i d'en Jean, una veritat que cap dels dos germans no coneixia.",
  "ar": "تظهر أولي من فوهة بركان وسط غابة محروقة. تؤكد أنها أخت بن وجان، حقيقة لم يعرفها أيٌّ من الشقيقين."
 },
 "Olie.": {
  "en": "Olie.",
  "es": "Olie.",
  "it": "Olie.",
  "ca": "Olie.",
  "ar": "أولي."
 },
 "origine du signal inconnue. Aucun lien confirmé avec Jean, Kael ou le Vide. L’équipe prépare une exploration souterraine.": {
  "en": "signal origin unknown. No confirmed link to Jean, Kael or the Void. The team is preparing an underground expedition.",
  "es": "origen de la señal desconocido. Ningún vínculo confirmado con Jean, Kael o el Vacío. El equipo prepara una exploración subterránea.",
  "it": "origine del segnale sconosciuta. Nessun legame confermato con Jean, Kael o il Vuoto. La squadra prepara un’esplorazione sotterranea.",
  "ca": "origen del senyal desconegut. Cap vincle confirmat amb en Jean, en Kael o el Buit. L’equip prepara una exploració subterrània.",
  "ar": "أصل الإشارة مجهول. لا صلة مؤكدة بجان أو كايل أو الفراغ. يستعد الفريق لاستكشاف تحت الأرض."
 },
 "origine286": {
  "en": "origine286",
  "es": "origine286",
  "it": "origine286",
  "ca": "origine286",
  "ar": "origine286"
 },
 "Origines secrètes": {
  "en": "Secret origins",
  "es": "Orígenes secretos",
  "it": "Origini segrete",
  "ca": "Orígens secrets",
  "ar": "الأصول السرية",
  "zh": "秘密起源"
 },
 "Ou Jean veut que je croie Aidan vivant pour me faire sortir de ma cachette.": {
  "en": "Or Jean wants me to believe Aidan is alive to draw me out of hiding.",
  "es": "O Jean quiere que crea que Aidan está vivo para sacarme de mi escondite.",
  "it": "O Jean vuole che io creda Aidan vivo per farmi uscire dal nascondiglio.",
  "ca": "O en Jean vol que cregui que l'Aidan és viu per fer-me sortir de l'amagatall.",
  "ar": "أو أن جان يريد أن أعتقد أن أيدن حي ليُخرجني من مخبئي."
 },
 "OUVRIR": {
  "en": "OPEN",
  "es": "ABRIR",
  "it": "APRI",
  "ca": "OBRE",
  "ar": "فتح"
 },
 "OUVRIR LA CARTE ↗": {
  "en": "OPEN THE MAP ↗",
  "es": "ABRIR EL MAPA ↗",
  "it": "APRI LA MAPPA ↗",
  "ca": "OBRE EL MAPA ↗",
  "ar": "افتح الخريطة ↗"
 },
 "Ouvrir la carte de la Saison 8 en grand": {
  "en": "Open the Season 8 map full size",
  "es": "Abrir el mapa de la Temporada 8 en grande",
  "it": "Apri la mappa della Stagione 8 a schermo intero",
  "ca": "Obre el mapa de la Temporada 8 en gran",
  "ar": "افتح خريطة الموسم 8 بالحجم الكامل"
 },
 "Ouvrir la carte du Chapitre 2 Saison 1 en grand": {
  "en": "Open the Chapter 2 Season 1 map full size",
  "es": "Abrir el mapa del Capítulo 2 Temporada 1 en grande",
  "it": "Apri la mappa del Capitolo 2 Stagione 1 a schermo intero",
  "ca": "Obre el mapa del Capítol 2 Temporada 1 en gran",
  "ar": "افتح خريطة الفصل 2 الموسم 1 بالحجم الكامل"
 },
 "Ouvrir le dossier complet": {
  "en": "Open the full file",
  "es": "Abrir el expediente completo",
  "it": "Apri il fascicolo completo",
  "ca": "Obre l’expedient complet",
  "ar": "افتح الملف الكامل"
 },
 "OUVRIR LE DOSSIER SECRET — LE PASSÉ DE JEAN ET BEN": {
  "en": "OPEN THE SECRET FILE — THE PAST OF JEAN AND BEN",
  "es": "ABRIR EL EXPEDIENTE SECRETO — EL PASADO DE JEAN Y BEN",
  "it": "APRI IL FASCICOLO SEGRETO — IL PASSATO DI JEAN E BEN",
  "ca": "OBRE L’EXPEDIENT SECRET — EL PASSAT D’EN JEAN I EN BEN",
  "ar": "افتح الملف السري — ماضي جان وبين"
 },
 "Ouvrir le menu": {
  "en": "Open menu",
  "es": "Abrir el menú",
  "it": "Apri il menu",
  "ca": "Obre el menú",
  "ar": "فتح القائمة"
 },
 "OUVRIR LE TERMINAL →": {
  "en": "OPEN THE TERMINAL →",
  "es": "ABRIR LA TERMINAL →",
  "it": "APRI IL TERMINALE →",
  "ca": "OBRE LA TERMINAL →",
  "ar": "افتح الطرفية →"
 },
 "OUVRIR LE TERMINAL ↗": {
  "en": "OPEN THE TERMINAL ↗",
  "es": "ABRIR LA TERMINAL ↗",
  "it": "APRI IL TERMINALE ↗",
  "ca": "OBRE LA TERMINAL ↗",
  "ar": "افتح الطرفية ↗"
 },
 "page.dialogues": {
  "en": "The <span>dialogues</span>",
  "es": "Los <span>diálogos</span>",
  "it": "I <span>dialoghi</span>",
  "ca": "Els <span>diàlegs</span>",
  "ar": "<span>الحوارات</span>"
 },
 "page.personnages": {
  "en": "The <span>characters</span>",
  "es": "Los <span>personajes</span>",
  "it": "I <span>personaggi</span>",
  "ca": "Els <span>personatges</span>",
  "ar": "<span>الشخصيات</span>"
 },
 "Paradise Palm": {
  "en": "Paradise Palm",
  "es": "Paradise Palm",
  "it": "Paradise Palm",
  "ca": "Paradise Palm",
  "ar": "Paradise Palm"
 },
 "Parce qu'il a peur que vous ne compreniez jamais pourquoi il est parti, le jour où il est arrivé sur l'île 268.": {
  "en": "Because he fears you will never understand why he left, the day he arrived on island 268.",
  "es": "Porque teme que nunca comprendáis por qué se fue, el día en que llegó a la isla 268.",
  "it": "Perché teme che non capirete mai perché è partito, il giorno in cui è arrivato sull'isola 268.",
  "ca": "Perquè tem que no entengueu mai per què se'n va anar, el dia que va arribar a l'illa 268.",
  "ar": "لأنه يخشى ألا تفهموا أبدًا سبب رحيله، يوم وصل إلى الجزيرة 268."
 },
 "Parce que certaines vérités attendent que le monde soit prêt à s'effondrer un peu, avant de se reconstruire autrement.": {
  "en": "Because some truths wait for the world to be ready to collapse a little, before rebuilding itself differently.",
  "es": "Porque algunas verdades esperan a que el mundo esté listo para derrumbarse un poco, antes de reconstruirse de otra manera.",
  "it": "Perché alcune verità aspettano che il mondo sia pronto a crollare un po', prima di ricostruirsi diversamente.",
  "ca": "Perquè algunes veritats esperen que el món estigui a punt de caure una mica, abans de reconstruir-se d'una altra manera.",
  "ar": "لأن بعض الحقائق تنتظر أن يصبح العالم مستعدًّا لينهار قليلًا، قبل أن يُعاد بناؤه على نحو مختلف."
 },
 "Parce que je suis sortie du même endroit que lui. Et que je suis revenue pour le ramener. Pas pour vous mentir.": {
  "en": "Because I came out of the same place as him. And I came back to bring him home. Not to lie to you.",
  "es": "Porque salí del mismo lugar que él. Y he vuelto para traerlo a casa. No para mentiros.",
  "it": "Perché sono uscita dallo stesso luogo di lui. E sono tornata per riportarlo a casa. Non per mentirvi.",
  "ca": "Perquè vaig sortir del mateix lloc que ell. I he tornat per portar-lo a casa. No per mentir-vos.",
  "ar": "لأنني خرجت من المكان نفسه الذي خرج منه. وعدت لأعيده إلى البيت. لا لأكذب عليكم."
 },
 "Parce que toi aussi, tu as ses yeux. Les mêmes que les siens.": {
  "en": "Because you have his eyes too. The same as his.",
  "es": "Porque tú también tienes sus ojos. Los mismos que los suyos.",
  "it": "Perché anche tu hai i suoi occhi. Gli stessi che ha lui.",
  "ca": "Perquè tu també tens els seus ulls. Els mateixos que ell.",
  "ar": "لأنك أنت أيضًا لديك عيناه. نفس عينيه."
 },
 "Parce que tu mens. Tu as toujours menti sur ce qui s'est passé dans cette station.": {
  "en": "Because you are lying. You always lied about what happened in that station.",
  "es": "Porque mientes. Siempre mentiste sobre lo que ocurrió en esa estación.",
  "it": "Perché menti. Hai sempre mentito su ciò che è successo in quella stazione.",
  "ca": "Perquè menteixes. Sempre vas mentir sobre què va passar en aquella estació.",
  "ar": "لأنك تكذب. لطالما كذبت بشأن ما حدث في تلك المحطة."
 },
 "PARCOURIR": {
  "en": "BROWSE",
  "es": "EXPLORAR",
  "it": "SFOGLIA",
  "ca": "EXPLORA",
  "ar": "تصفّح"
 },
 "Pas seule. Pas sans vous.": {
  "en": "Not alone. Not without you.",
  "es": "No sola. No sin vosotros.",
  "it": "Non da sola. Non senza di voi.",
  "ca": "No sola. No sense vosaltres.",
  "ar": "ليس وحدي. لا من دونكم."
 },
 "personnages": {
  "en": "characters",
  "es": "personajes",
  "it": "personaggi",
  "ca": "personatges",
  "ar": "الشخصيات"
 },
 "Personnages": {
  "en": "Characters",
  "es": "Personajes",
  "it": "Personaggi",
  "ca": "Personatges",
  "ar": "الشخصيات",
  "zh": "角色"
 },
 "Personnages — L'Éclat du Point Zéro": {
  "en": "Characters — The Shard of Point Zero",
  "es": "Personajes — El Resplandor del Punto Cero",
  "it": "Personaggi — Lo Splendore del Punto Zero",
  "ca": "Personatges — L’Esclat del Punt Zero",
  "ar": "الشخصيات — وهج النقطة صفر"
 },
 "Personne n'avance.": {
  "en": "Nobody moves.",
  "es": "Que nadie se mueva.",
  "it": "Nessuno si muova.",
  "ca": "Que ningú es mogui.",
  "ar": "لا يتقدم أحد."
 },
 "Petit secteur sur l’île à l’ouest.": {
  "en": "Small sector on the island to the west.",
  "es": "Pequeño sector en la isla al oeste.",
  "it": "Piccolo settore sull'isola a ovest.",
  "ca": "Petit sector a l'illa a l'oest.",
  "ar": "قطاع صغير في الجزيرة غربًا."
 },
 "Petite île au milieu de la rivière.": {
  "en": "Small island in the middle of the river.",
  "es": "Pequeña isla en medio del río.",
  "it": "Piccola isola in mezzo al fiume.",
  "ca": "Petita illa al mig del riu.",
  "ar": "جزيرة صغيرة وسط النهر."
 },
 "Point central de l’île, au milieu des bois bleutés.": {
  "en": "Central point of the island, amid the bluish woods.",
  "es": "Punto central de la isla, entre los bosques azulados.",
  "it": "Punto centrale dell'isola, tra i boschi bluastri.",
  "ca": "Punt central de l'illa, entre els boscos blavosos.",
  "ar": "النقطة المركزية للجزيرة، بين الغابات المائلة إلى الزرقة."
 },
 "Point d’intérêt à l’ouest du centre.": {
  "en": "Point of interest west of the centre.",
  "es": "Punto de interés al oeste del centro.",
  "it": "Punto di interesse a ovest del centro.",
  "ca": "Punt d'interès a l'oest del centre.",
  "ar": "نقطة اهتمام غرب المركز."
 },
 "Point d’intérêt au sud-ouest.": {
  "en": "Point of interest to the south-west.",
  "es": "Punto de interés al suroeste.",
  "it": "Punto di interesse a sud-ovest.",
  "ca": "Punt d'interès al sud-oest.",
  "ar": "نقطة اهتمام في الجنوب الغربي."
 },
 "Point Zéro": {
  "en": "Point Zero",
  "es": "Punto Cero",
  "it": "Punto Zero",
  "ca": "Punt Zero",
  "ar": "النقطة صفر",
  "zh": "零点"
 },
 "POINT ZÉRO": {
  "en": "POINT ZERO",
  "es": "PUNTO CERO",
  "it": "PUNTO ZERO",
  "ca": "PUNT ZERO",
  "ar": "النقطة صفر"
 },
 "POINT ZERO : LIBÉRÉ // ÎLE : RECONSTRUITE // CHAPITRE : 02 / SAISON : 01 // SIGNAL : ACTIF SOUS FREAKY ZERO": {
  "en": "POINT ZERO: RELEASED // ISLAND: REBUILT // CHAPTER: 02 / SEASON: 01 // SIGNAL: ACTIVE UNDER FREAKY ZERO",
  "es": "PUNTO CERO: LIBERADO // ISLA: RECONSTRUIDA // CAPÍTULO: 02 / TEMPORADA: 01 // SEÑAL: ACTIVA BAJO FREAKY ZERO",
  "it": "PUNTO ZERO: LIBERATO // ISOLA: RICOSTRUITA // CAPITOLO: 02 / STAGIONE: 01 // SEGNALE: ATTIVO SOTTO FREAKY ZERO",
  "ca": "PUNT ZERO: ALLIBERAT // ILLA: RECONSTRUÏDA // CAPÍTOL: 02 / TEMPORADA: 01 // SENYAL: ACTIU SOTA FREAKY ZERO",
  "ar": "النقطة صفر: محرَّرة // الجزيرة: أُعيد بناؤها // الفصل: 02 / الموسم: 01 // الإشارة: نشطة تحت فريكي زيرو"
 },
 "Point Zéro animé, noyau d'énergie bleu et violet": {
  "en": "Animated Point Zero, blue and violet energy core",
  "es": "Punto Cero animado, núcleo de energía azul y violeta",
  "it": "Punto Zero animato, nucleo di energia blu e viola",
  "ca": "Punt Zero animat, nucli d’energia blau i violeta",
  "ar": "النقطة صفر المتحركة، نواة طاقة زرقاء وبنفسجية"
 },
 "Point Zéro disparaît en se mettant lui-même à l'abri. Une île immense fonce droit sur la réalité de la Garde Zéro. L'équipe construit une base commune, Olympic Future, et Ben lance la construction d'une fusée à Dusty Depot pour aller à la rencontre de cette île ou lui échapper.": {
  "en": "Point Zero vanishes, taking itself out of harm's way. A huge island hurtles straight towards the Zero Guard's reality. The team builds a shared base, Olympic Future, and Ben starts building a rocket at Dusty Depot to meet that island — or escape it.",
  "es": "El Punto Cero desaparece poniéndose a sí mismo a salvo. Una isla inmensa se lanza directamente hacia la realidad de la Guardia Cero. El equipo construye una base común, Olympic Future, y Ben inicia la construcción de un cohete en Dusty Depot para ir al encuentro de esa isla o escapar de ella.",
  "it": "Il Punto Zero scompare mettendosi al riparo. Un’isola immensa punta dritta verso la realtà della Guardia Zero. La squadra costruisce una base comune, Olympic Future, e Ben avvia la costruzione di un razzo a Dusty Depot per andare incontro a quell’isola o sfuggirle.",
  "ca": "El Punt Zero desapareix posant-se ell mateix fora de perill. Una illa immensa es dirigeix directament cap a la realitat de la Guàrdia Zero. L’equip construeix una base comuna, Olympic Future, i en Ben inicia la construcció d’un coet a Dusty Depot per anar a l’encontre d’aquesta illa o escapar-ne.",
  "ar": "تختفي النقطة صفر وتُخرج نفسها من مرمى الخطر. جزيرة هائلة تتجه مباشرة نحو واقع حرس الصفر. يبني الفريق قاعدة مشتركة باسم Olympic Future، ويبدأ بن تشييد صاروخ في Dusty Depot لملاقاة تلك الجزيرة أو الهرب منها."
 },
 "POINT ZERO OS // BUILD 10.0.0 — SAISON 08": {
  "en": "POINT ZERO OS // BUILD 10.0.0 — SEASON 08",
  "es": "POINT ZERO OS // BUILD 10.0.0 — TEMPORADA 08",
  "it": "POINT ZERO OS // BUILD 10.0.0 — STAGIONE 08",
  "ca": "POINT ZERO OS // BUILD 10.0.0 — TEMPORADA 08",
  "ar": "POINT ZERO OS // BUILD 10.0.0 — الموسم 08"
 },
 "Point Zéro se fracture. Une ancienne ville engloutie refait surface, le Roi des Glaces se réveille près d'Onegura Tiles, et une silhouette encore inconnue observe l'équipe de loin : le Voyageur Noir.": {
  "en": "Point Zero fractures. An ancient sunken city resurfaces, the Ice King wakes near Onegura Tiles, and a still-unknown figure watches the team from afar: the Black Traveller.",
  "es": "El Punto Cero se fractura. Una antigua ciudad sumergida vuelve a la superficie, el Rey de Hielo despierta cerca de Onegura Tiles y una silueta aún desconocida observa al equipo desde lejos: el Viajero Negro.",
  "it": "Il Punto Zero si frattura. Un’antica città sommersa riemerge, il Re di Ghiaccio si risveglia vicino a Onegura Tiles e una sagoma ancora sconosciuta osserva la squadra da lontano: il Viaggiatore Nero.",
  "ca": "El Punt Zero es fractura. Una antiga ciutat submergida torna a la superfície, el Rei de Gel es desperta a prop d’Onegura Tiles i una silueta encara desconeguda observa l’equip de lluny: el Viatger Negre.",
  "ar": "تتشقق النقطة صفر. تعود مدينة قديمة غارقة إلى السطح، يستيقظ ملك الجليد قرب Onegura Tiles، ويراقب الفريق من بعيد ظلٌّ لا يزال مجهولًا: المسافر الأسود."
 },
 "Points d’intérêt": {
  "en": "Points of interest",
  "es": "Puntos de interés",
  "it": "Punti di interesse",
  "ca": "Punts d'interès",
  "ar": "نقاط الاهتمام"
 },
 "Pour Ben, cette voix est une preuve qu'Aidan peut encore être sauvé. Pour Vanny, elle n'est qu'un indice à vérifier. Le plus inquiétant est que certaines phrases semblent avoir été assemblées à partir de plusieurs souvenirs différents, comme si quelque chose apprenait à imiter Aidan à mesure qu'il parle.": {
  "en": "For Ben, this voice is proof that Aidan can still be saved. For Vanny, it is only a clue to verify. Most unsettling is that some sentences seem assembled from several different memories, as if something were learning to imitate Aidan as he speaks.",
  "es": "Para Ben, esta voz es una prueba de que Aidan aún puede salvarse. Para Vanny, no es más que un indicio que verificar. Lo más inquietante es que algunas frases parecen ensambladas a partir de varios recuerdos distintos, como si algo aprendiera a imitar a Aidan a medida que habla.",
  "it": "Per Ben, questa voce è la prova che Aidan può ancora essere salvato. Per Vanny, è solo un indizio da verificare. La cosa più inquietante è che alcune frasi sembrano assemblate da diversi ricordi differenti, come se qualcosa stesse imparando a imitare Aidan mentre parla.",
  "ca": "Per a en Ben, aquesta veu és una prova que l'Aidan encara es pot salvar. Per a la Vanny, només és un indici a verificar. El més inquietant és que algunes frases semblen muntades a partir de diversos records diferents, com si alguna cosa aprengués a imitar l'Aidan a mesura que parla.",
  "ar": "بالنسبة إلى بن، هذا الصوت دليل على أن أيدن يمكن إنقاذه بعد. أما بالنسبة إلى فاني، فهو مجرد قرينة يجب التحقق منها. الأكثر إقلاقًا أن بعض الجمل تبدو مركَّبة من عدة ذكريات مختلفة، كأن شيئًا ما يتعلّم تقليد أيدن كلما تكلّم."
 },
 "Pour une fois, je suis d'accord sans même faire de blague.": {
  "en": "For once, I agree without even making a joke.",
  "es": "Por una vez, estoy de acuerdo sin siquiera hacer un chiste.",
  "it": "Per una volta, sono d'accordo senza nemmeno fare una battuta.",
  "ca": "Per una vegada, hi estic d'acord sense ni tan sols fer una broma.",
  "ar": "لمرة واحدة، أوافق دون أن أطلق حتى نكتة."
 },
 "pourquoi a-t-il utilisé une machine temporelle pour rejoindre l’île ?": {
  "en": "why did he use a time machine to reach the island?",
  "es": "¿por qué usó una máquina del tiempo para llegar a la isla?",
  "it": "perché ha usato una macchina del tempo per raggiungere l’isola?",
  "ca": "per què va fer servir una màquina del temps per arribar a l’illa?",
  "ar": "لماذا استخدم آلة زمن للوصول إلى الجزيرة؟"
 },
 "Pourquoi maintenant ?": {
  "en": "Why now?",
  "es": "¿Por qué ahora?",
  "it": "Perché ora?",
  "ca": "Per què ara?",
  "ar": "لماذا الآن؟"
 },
 "Pourquoi nous aider maintenant ?": {
  "en": "Why help us now?",
  "es": "¿Por qué ayudarnos ahora?",
  "it": "Perché aiutarci ora?",
  "ca": "Per què ajudar-nos ara?",
  "ar": "لماذا تساعدنا الآن؟"
 },
 "Prends le dossier principal. Je vais détourner les caméras.": {
  "en": "Take the main file. I will divert the cameras.",
  "es": "Toma el expediente principal. Yo desviaré las cámaras.",
  "it": "Prendi il fascicolo principale. Io devierò le telecamere.",
  "ca": "Pren l'expedient principal. Jo desviaré les càmeres.",
  "ar": "خذ الملف الرئيسي. سأحوّل الكاميرات."
 },
 "PROTAGONISTE": {
  "en": "PROTAGONIST",
  "es": "PROTAGONISTA",
  "it": "PROTAGONISTA",
  "ca": "PROTAGONISTA",
  "ar": "البطل"
 },
 "protéger le groupe et trouver un chemin sûr à travers les zones instables.": {
  "en": "to protect the group and find a safe path through the unstable zones.",
  "es": "proteger al grupo y encontrar un camino seguro a través de las zonas inestables.",
  "it": "proteggere il gruppo e trovare un percorso sicuro attraverso le zone instabili.",
  "ca": "protegir el grup i trobar un camí segur per les zones inestables.",
  "ar": "حماية المجموعة وإيجاد طريق آمن عبر المناطق غير المستقرة."
 },
 "Qu'est-ce que c'est, alors ?": {
  "en": "Then what is it?",
  "es": "¿Qué es, entonces?",
  "it": "Che cos'è, allora?",
  "ca": "Què és, llavors?",
  "ar": "ما هو إذًا؟"
 },
 "Qu'est-ce que tu racontes ?": {
  "en": "What are you talking about?",
  "es": "¿De qué estás hablando?",
  "it": "Di che cosa stai parlando?",
  "ca": "De què estàs parlant?",
  "ar": "عمّ تتحدث؟"
 },
 "Quartier à l’ouest de l’île.": {
  "en": "District to the west of the island.",
  "es": "Barrio al oeste de la isla.",
  "it": "Quartiere a ovest dell'isola.",
  "ca": "Barri a l'oest de l'illa.",
  "ar": "حي غرب الجزيرة."
 },
 "Quartier au nord-est de la zone centrale.": {
  "en": "District north-east of the central zone.",
  "es": "Barrio al noreste de la zona central.",
  "it": "Quartiere a nord-est della zona centrale.",
  "ca": "Barri al nord-est de la zona central.",
  "ar": "حي شمال شرق المنطقة المركزية."
 },
 "Quartier proche de la rivière centrale.": {
  "en": "District near the central river.",
  "es": "Barrio cerca del río central.",
  "it": "Quartiere vicino al fiume centrale.",
  "ca": "Barri a prop del riu central.",
  "ar": "حي قريب من النهر المركزي."
 },
 "Quartier situé dans la partie nord.": {
  "en": "District located in the northern part.",
  "es": "Barrio situado en la parte norte.",
  "it": "Quartiere situato nella parte nord.",
  "ca": "Barri situat a la part nord.",
  "ar": "حي يقع في الجزء الشمالي."
 },
 "quelle aventure ont-ils vécue ensemble ?": {
  "en": "what adventure did they live through together?",
  "es": "¿qué aventura vivieron juntos?",
  "it": "quale avventura hanno vissuto insieme?",
  "ca": "quina aventura van viure junts?",
  "ar": "أي مغامرة عاشاها معًا؟"
 },
 "quelle dispute a brisé leur amitié ?": {
  "en": "what dispute broke their friendship?",
  "es": "¿qué disputa rompió su amistad?",
  "it": "quale lite ha spezzato la loro amicizia?",
  "ca": "quina disputa va trencar la seva amistat?",
  "ar": "أي خلاف كسر صداقتهما؟"
 },
 "Quelque chose": {
  "en": "Something",
  "es": "Algo",
  "it": "Qualcosa",
  "ca": "Alguna cosa",
  "ar": "شيءٌ ما"
 },
 "Quelque chose qui ne veut surtout pas que Jean revienne.": {
  "en": "Something that above all does not want Jean to return.",
  "es": "Algo que, sobre todo, no quiere que Jean vuelva.",
  "it": "Qualcosa che soprattutto non vuole che Jean torni.",
  "ca": "Alguna cosa que, sobretot, no vol que en Jean torni.",
  "ar": "شيء لا يريد أبدًا أن يعود جان."
 },
 "Qui, lui ?": {
  "en": "Who, him?",
  "es": "¿Quién, él?",
  "it": "Chi, lui?",
  "ca": "Qui, ell?",
  "ar": "من، هو؟"
 },
 "Quinze secteurs.": {
  "en": "Fifteen sectors.",
  "es": "Quince sectores.",
  "it": "Quindici settori.",
  "ca": "Quinze sectors.",
  "ar": "خمسة عشر قطاعًا."
 },
 "RAPPORT PRIORITAIRE": {
  "en": "PRIORITY REPORT",
  "es": "INFORME PRIORITARIO",
  "it": "RAPPORTO PRIORITARIO",
  "ca": "INFORME PRIORITARI",
  "ar": "تقرير ذو أولوية"
 },
 "Rapports, fragments et éléments classés par ordre de découverte.": {
  "en": "Reports, fragments and items ordered by discovery.",
  "es": "Informes, fragmentos y elementos ordenados por descubrimiento.",
  "it": "Rapporti, frammenti ed elementi ordinati per ritrovamento.",
  "ca": "Informes, fragments i elements ordenats per descobriment.",
  "ar": "تقارير وشظايا وعناصر مرتبة بحسب اكتشافها."
 },
 "RÉALITÉ : STABLE // VERSION : 08": {
  "en": "REALITY: STABLE // VERSION: 08",
  "es": "REALIDAD: ESTABLE // VERSIÓN: 08",
  "it": "REALTÀ: STABILE // VERSIONE: 08",
  "ca": "REALITAT: ESTABLE // VERSIÓ: 08",
  "ar": "الواقع: مستقر // النسخة: 08"
 },
 "RÉALITÉ 265": {
  "en": "REALITY 265",
  "es": "REALIDAD 265",
  "it": "REALTÀ 265",
  "ca": "REALITAT 265",
  "ar": "الواقع 265"
 },
 "RECHERCHE DU SIGNAL…": {
  "en": "SEARCHING FOR THE SIGNAL…",
  "es": "BUSCANDO LA SEÑAL…",
  "it": "RICERCA DEL SEGNALE…",
  "ca": "CERCANT EL SENYAL…",
  "ar": "جارٍ البحث عن الإشارة…"
 },
 "RECHERCHER LE FRAGMENT 018 →": {
  "en": "SEARCH FOR FRAGMENT 018 →",
  "es": "BUSCAR EL FRAGMENTO 018 →",
  "it": "CERCA IL FRAMMENTO 018 →",
  "ca": "CERCA EL FRAGMENT 018 →",
  "ar": "ابحث عن الشظية 018 →"
 },
 "RECOMMENCER ↻": {
  "en": "START OVER ↻",
  "es": "EMPEZAR DE NUEVO ↻",
  "it": "RICOMINCIA ↻",
  "ca": "COMENÇA DE NOU ↻",
  "ar": "ابدأ من جديد ↻"
 },
 "RECONSTRUITE": {
  "en": "REBUILT",
  "es": "RECONSTRUIDA",
  "it": "RICOSTRUITA",
  "ca": "RECONSTRUÏDA",
  "ar": "أُعيد بناؤها"
 },
 "Région désertique à l’est.": {
  "en": "Desert region to the east.",
  "es": "Región desértica al este.",
  "it": "Regione desertica a est.",
  "ca": "Regió desèrtica a l'est.",
  "ar": "منطقة صحراوية في الشرق."
 },
 "RELIRE LA CHRONOLOGIE": {
  "en": "READ THE TIMELINE AGAIN",
  "es": "RELEER LA CRONOLOGÍA",
  "it": "RILETGI LA CRONOLOGIA",
  "ca": "RELLEGEIX LA CRONOLOGIA",
  "ar": "أعد قراءة التسلسل الزمني"
 },
 "Réplique": {
  "en": "Line",
  "es": "Réplica",
  "it": "Battuta",
  "ca": "Rèplica",
  "ar": "الجملة"
 },
 "Réplique 1": {
  "en": "Line 1",
  "es": "Réplica 1",
  "it": "Battuta 1",
  "ca": "Rèplica 1",
  "ar": "الجملة 1"
 },
 "RÉPLIQUE SUIVANTE →": {
  "en": "NEXT LINE →",
  "es": "SIGUIENTE RÉPLICA →",
  "it": "BATTUTA SUCCESSIVA →",
  "ca": "RÈPLICA SEGÜENT →",
  "ar": "الجملة التالية →"
 },
 "répond sous l'île.": {
  "en": "answers beneath the island.",
  "es": "responde bajo la isla.",
  "it": "risponde sotto l’isola.",
  "ca": "respon sota l’illa.",
  "ar": "يجيب تحت الجزيرة."
 },
 "REPRENDRE L'HISTOIRE": {
  "en": "RESUME THE STORY",
  "es": "RETOMAR LA HISTORIA",
  "it": "RIPRENDI LA STORIA",
  "ca": "REPRÈN LA HISTÒRIA",
  "ar": "تابع القصة"
 },
 "RÉSEAU INTERDIMENSIONNEL · EN LIGNE": {
  "en": "INTERDIMENSIONAL NETWORK · ONLINE",
  "es": "RED INTERDIMENSIONAL · EN LÍNEA",
  "it": "RETE INTERDIMENSIONALE · ONLINE",
  "ca": "XARXA INTERDIMENSIONAL · EN LÍNIA",
  "ar": "الشبكة بين الأبعاد · متصلة"
 },
 "Ressenti quoi ?": {
  "en": "Felt what?",
  "es": "¿Sentido qué?",
  "it": "Sentito cosa?",
  "ca": "Sentit què?",
  "ar": "شعر بماذا؟"
 },
 "Retour à l'accueil": {
  "en": "Back to home",
  "es": "Volver al inicio",
  "it": "Torna alla home",
  "ca": "Torna a l'inici",
  "ar": "العودة إلى الرئيسية"
 },
 "Retour au Point Zéro": {
  "en": "Back to Point Zero",
  "es": "Volver al Punto Cero",
  "it": "Torna al Punto Zero",
  "ca": "Torna al Punt Zero",
  "ar": "العودة إلى النقطة صفر"
 },
 "RETOURNER AU TERMINAL": {
  "en": "RETURN TO TERMINAL",
  "es": "VOLVER AL TERMINAL",
  "it": "TORNA AL TERMINALE",
  "ca": "TORNAR AL TERMINAL",
  "ar": "العودة إلى الوحدة الطرفية"
 },
 "retrouver ses deux frères et les ramener ensemble.": {
  "en": "to find her two brothers and bring them back together.",
  "es": "reencontrar a sus dos hermanos y reunirlos.",
  "it": "ritrovare i suoi due fratelli e riunirli.",
  "ca": "retrobar els seus dos germans i reunir-los.",
  "ar": "إيجاد شقيقيها وجمعهما من جديد."
 },
 "retrouver son identité et mettre fin au cycle de destruction.": {
  "en": "to recover his identity and end the cycle of destruction.",
  "es": "recuperar su identidad y poner fin al ciclo de destrucción.",
  "it": "ritrovare la propria identità e porre fine al ciclo di distruzione.",
  "ca": "recuperar la seva identitat i posar fi al cicle de destrucció.",
  "ar": "استعادة هويته وإنهاء دورة الدمار."
 },
 "Risky Reels": {
  "en": "Risky Reels",
  "es": "Risky Reels",
  "it": "Risky Reels",
  "ca": "Risky Reels",
  "ar": "Risky Reels"
 },
 "root@point-zero:~$": {
  "en": "root@point-zero:~$",
  "es": "root@point-zero:~$",
  "it": "root@point-zero:~$",
  "ca": "root@point-zero:~$",
  "ar": "root@point-zero:~$"
 },
 "Sa loyauté est sa plus grande force, mais elle le rend aussi vulnérable : Jean sait que Ben risquerait tout pour sauver un ami. Plus les transmissions deviennent précises, plus Ben craint que quelqu'un connaisse ses décisions avant même qu'il les prenne.": {
  "en": "His loyalty is his greatest strength, but it also makes him vulnerable: Jean knows that Ben would risk everything to save a friend. The more precise the transmissions become, the more Ben fears that someone knows his decisions before he even makes them.",
  "es": "Su lealtad es su mayor fuerza, pero también lo hace vulnerable: Jean sabe que Ben lo arriesgaría todo para salvar a un amigo. Cuanto más precisas se vuelven las transmisiones, más teme Ben que alguien conozca sus decisiones antes incluso de que las tome.",
  "it": "La sua lealtà è la sua più grande forza, ma lo rende anche vulnerabile: Jean sa che Ben rischierebbe tutto per salvare un amico. Più le trasmissioni diventano precise, più Ben teme che qualcuno conosca le sue decisioni prima ancora che le prenda.",
  "ca": "La seva lleialtat és la seva força més gran, però també el fa vulnerable: en Jean sap que en Ben ho arriscaria tot per salvar un amic. Com més precises es tornen les transmissions, més tem en Ben que algú conegui les seves decisions abans i tot que les prengui.",
  "ar": "ولاؤه أعظم قوته، لكنه يجعله عرضةً للخطر أيضًا: يعرف جان أن بن سيخاطر بكل شيء لإنقاذ صديق. وكلما زادت دقة البثّات، زاد خوف بن من أن أحدًا يعرف قراراته قبل أن يتخذها."
 },
 "Sa vraie forme ?": {
  "en": "His true form?",
  "es": "¿Su verdadera forma?",
  "it": "La sua vera forma?",
  "ca": "La seva veritable forma?",
  "ar": "شكله الحقيقي؟"
 },
 "SAISON 01": {
  "en": "SEASON 01",
  "es": "TEMPORADA 01",
  "it": "STAGIONE 01",
  "ca": "TEMPORADA 01",
  "ar": "الموسم 01"
 },
 "SAISON 08 // 15 REPÈRES": {
  "en": "SEASON 08 // 15 LANDMARKS",
  "es": "TEMPORADA 08 // 15 PUNTOS DE REFERENCIA",
  "it": "STAGIONE 08 // 15 PUNTI DI RIFERIMENTO",
  "ca": "TEMPORADA 08 // 15 PUNTS DE REFERÈNCIA",
  "ar": "الموسم 08 // 15 معلمًا"
 },
 "SAISON 1 : DÉFERLANTE DE L'ORDRE": {
  "en": "SEASON 1: THE ORDER'S SURGE",
  "es": "TEMPORADA 1: LA OLEADA DEL ORDEN",
  "it": "STAGIONE 1: L’ONDATA DELL’ORDINE",
  "ca": "TEMPORADA 1: L’ONADA DE L’ORDE",
  "ar": "الموسم 1: مدُّ النظام"
 },
 "SAISON 2 : LE FRAGMENT ZÉRO": {
  "en": "SEASON 2: THE ZERO FRAGMENT",
  "es": "TEMPORADA 2: EL FRAGMENTO CERO",
  "it": "STAGIONE 2: IL FRAMMENTO ZERO",
  "ca": "TEMPORADA 2: EL FRAGMENT ZERO",
  "ar": "الموسم 2: الجزء صفر"
 },
 "SAISON 3 : LES MURS BRISÉS": {
  "en": "SEASON 3: THE BROKEN WALLS",
  "es": "TEMPORADA 3: LOS MUROS ROTOS",
  "it": "STAGIONE 3: I MURI INFRANTI",
  "ca": "TEMPORADA 3: ELS MURS TRENCATS",
  "ar": "الموسم 3: الجدران المكسورة"
 },
 "SAISON 4 : STABILISATION": {
  "en": "SEASON 4: STABILISATION",
  "es": "TEMPORADA 4: ESTABILIZACIÓN",
  "it": "STAGIONE 4: STABILIZZAZIONE",
  "ca": "TEMPORADA 4: ESTABILITZACIÓ",
  "ar": "الموسم 4: الاستقرار"
 },
 "SAISON 6 : POINT ZÉRO SE CACHE": {
  "en": "SEASON 6: POINT ZERO HIDES",
  "es": "TEMPORADA 6: EL PUNTO CERO SE ESCONDE",
  "it": "STAGIONE 6: IL PUNTO ZERO SI NASCONDE",
  "ca": "TEMPORADA 6: EL PUNT ZERO S’AMAGA",
  "ar": "الموسم 6: النقطة صفر تختفي"
 },
 "SAISON 7 · CONCLUSION": {
  "en": "SEASON 7 · CONCLUSION",
  "es": "TEMPORADA 7 · CONCLUSIÓN",
  "it": "STAGIONE 7 · CONCLUSIONE",
  "ca": "TEMPORADA 7 · CONCLUSIÓ",
  "ar": "الموسم 7 · الخاتمة"
 },
 "SAISON 7 · ÉPILOGUE": {
  "en": "SEASON 7 · EPILOGUE",
  "es": "TEMPORADA 7 · EPÍLOGO",
  "it": "STAGIONE 7 · EPILOGO",
  "ca": "TEMPORADA 7 · EPÍLEG",
  "ar": "الموسم 7 · خاتمة"
 },
 "SAISON 8 — PREMIÈRE RENCONTRE :": {
  "en": "SEASON 8 — FIRST MEETING:",
  "es": "TEMPORADA 8 — PRIMER ENCUENTRO:",
  "it": "STAGIONE 8 — PRIMO INCONTRO:",
  "ca": "TEMPORADA 8 — PRIMERA TROBADA:",
  "ar": "الموسم 8 — اللقاء الأول:"
 },
 "SAISON 8 · NOUVEL ARRIVANT": {
  "en": "SEASON 8 · NEW ARRIVAL",
  "es": "TEMPORADA 8 · NUEVO LLEGADO",
  "it": "STAGIONE 8 · NUOVO ARRIVO",
  "ca": "TEMPORADA 8 · NOU ARRIBAT",
  "ar": "الموسم 8 · قادم جديد"
 },
 "SAISON 8 · NOUVELLE ÎLE": {
  "en": "SEASON 8 · NEW ISLAND",
  "es": "TEMPORADA 8 · NUEVA ISLA",
  "it": "STAGIONE 8 · NUOVA ISOLA",
  "ca": "TEMPORADA 8 · NOVA ILLA",
  "ar": "الموسم 8 · جزيرة جديدة"
 },
 "Sanctuaire Déferlante": {
  "en": "Rolling Sanctuary",
  "es": "Santuario Rompiente",
  "it": "Santuario Travolgente",
  "ca": "Santuari Devastador",
  "ar": "الملاذ المتلاطم"
 },
 "SANCTUAIRE DÉFERLANTE": {
  "en": "ROLLING SANCTUARY",
  "es": "SANTUARIO ROMPIENTE",
  "it": "SANTUARIO TRAVOLGENTE",
  "ca": "SANTUARI DEVASTADOR",
  "ar": "الملاذ المتلاطم"
 },
 "Sanctuaire installé près du grand lac du nord.": {
  "en": "Sanctuary set near the great northern lake.",
  "es": "Santuario situado cerca del gran lago del norte.",
  "it": "Santuario situato vicino al grande lago del nord.",
  "ca": "Santuari situat a prop del gran llac del nord.",
  "ar": "ملاذ قريب من البحيرة الشمالية الكبرى."
 },
 "Sanctuaire Sampiternel": {
  "en": "Sampiternel Sanctuary",
  "es": "Santuario Sampiternel",
  "it": "Santuario Sampiternel",
  "ca": "Santuari Sampiternel",
  "ar": "ملاذ Sampiternel"
 },
 "sauver ses amis sans sacrifier la liberté de tous les autres.": {
  "en": "to save his friends without sacrificing everyone else's freedom.",
  "es": "salvar a sus amigos sin sacrificar la libertad de todos los demás.",
  "it": "salvare i suoi amici senza sacrificare la libertà di tutti gli altri.",
  "ca": "salvar els seus amics sense sacrificar la llibertat de tots els altres.",
  "ar": "إنقاذ أصدقائه دون التضحية بحرية الآخرين جميعًا."
 },
 "SCÈNE 01 — 02:17 — POSTE D’OBSERVATION": {
  "en": "SCENE 01 — 02:17 — OBSERVATION POST",
  "es": "ESCENA 01 — 02:17 — PUESTO DE OBSERVACIÓN",
  "it": "SCENA 01 — 02:17 — POSTO DI OSSERVAZIONE",
  "ca": "ESCENA 01 — 02:17 — POST D’OBSERVACIÓ",
  "ar": "المشهد 01 — 02:17 — موقع المراقبة"
 },
 "SCÈNE 02 — LISIÈRE DE FREAKY ZERO": {
  "en": "SCENE 02 — FREAKY ZERO FOREST EDGE",
  "es": "ESCENA 02 — LINDERO DE FREAKY ZERO",
  "it": "SCENA 02 — MARGINE DI FREAKY ZERO",
  "ca": "ESCENA 02 — VORERA DE FREAKY ZERO",
  "ar": "المشهد 02 — حدود غابة فريكي زيرو"
 },
 "SCÈNE 03 — TRANSMISSION INCOMPLÈTE": {
  "en": "SCENE 03 — INCOMPLETE TRANSMISSION",
  "es": "ESCENA 03 — TRANSMISIÓN INCOMPLETA",
  "it": "SCENA 03 — TRASMISSIONE INCOMPLETA",
  "ca": "ESCENA 03 — TRANSMISSIÓ INCOMPLETA",
  "ar": "المشهد 03 — بث غير مكتمل"
 },
 "Scènes importantes et conversations retrouvées dans les archives.": {
  "en": "Key scenes and conversations recovered from the archives.",
  "es": "Escenas clave y conversaciones recuperadas de los archivos.",
  "it": "Scene chiave e conversazioni ritrovate negli archivi.",
  "ca": "Escenes clau i converses recuperades dels arxius.",
  "ar": "مشاهد مهمة ومحادثات عُثر عليها في الأرشيف."
 },
 "SCIENTIFIQUE — DOSSIER RESTREINT": {
  "en": "SCIENTIST — RESTRICTED FILE",
  "es": "CIENTÍFICO — EXPEDIENTE RESTRINGIDO",
  "it": "SCIENTIFICO — FASCICOLO RISERVATO",
  "ca": "CIENTÍFIC — EXPEDIENT RESTRINGIT",
  "ar": "عالِم — ملف مقيَّد"
 },
 "Secret :": {
  "en": "Secret:",
  "es": "Secreto:",
  "it": "Segreto:",
  "ca": "Secret:",
  "ar": "السر:"
 },
 "SECTEUR 01": {
  "en": "SECTOR 01",
  "es": "SECTOR 01",
  "it": "SETTORE 01",
  "ca": "SECTOR 01",
  "ar": "القطاع 01"
 },
 "SECTEUR 02": {
  "en": "SECTOR 02",
  "es": "SECTOR 02",
  "it": "SETTORE 02",
  "ca": "SECTOR 02",
  "ar": "القطاع 02"
 },
 "SECTEUR 03": {
  "en": "SECTOR 03",
  "es": "SECTOR 03",
  "it": "SETTORE 03",
  "ca": "SECTOR 03",
  "ar": "القطاع 03"
 },
 "SECTEUR 04": {
  "en": "SECTOR 04",
  "es": "SECTOR 04",
  "it": "SETTORE 04",
  "ca": "SECTOR 04",
  "ar": "القطاع 04"
 },
 "SECTEUR 05": {
  "en": "SECTOR 05",
  "es": "SECTOR 05",
  "it": "SETTORE 05",
  "ca": "SECTOR 05",
  "ar": "القطاع 05"
 },
 "SECTEUR 06": {
  "en": "SECTOR 06",
  "es": "SECTOR 06",
  "it": "SETTORE 06",
  "ca": "SECTOR 06",
  "ar": "القطاع 06"
 },
 "SECTEUR 07": {
  "en": "SECTOR 07",
  "es": "SECTOR 07",
  "it": "SETTORE 07",
  "ca": "SECTOR 07",
  "ar": "القطاع 07"
 },
 "SECTEUR 08": {
  "en": "SECTOR 08",
  "es": "SECTOR 08",
  "it": "SETTORE 08",
  "ca": "SECTOR 08",
  "ar": "القطاع 08"
 },
 "SECTEUR 09": {
  "en": "SECTOR 09",
  "es": "SECTOR 09",
  "it": "SETTORE 09",
  "ca": "SECTOR 09",
  "ar": "القطاع 09"
 },
 "SECTEUR 10": {
  "en": "SECTOR 10",
  "es": "SECTOR 10",
  "it": "SETTORE 10",
  "ca": "SECTOR 10",
  "ar": "القطاع 10"
 },
 "SECTEUR 11": {
  "en": "SECTOR 11",
  "es": "SECTOR 11",
  "it": "SETTORE 11",
  "ca": "SECTOR 11",
  "ar": "القطاع 11"
 },
 "SECTEUR 12": {
  "en": "SECTOR 12",
  "es": "SECTOR 12",
  "it": "SETTORE 12",
  "ca": "SECTOR 12",
  "ar": "القطاع 12"
 },
 "SECTEUR 13": {
  "en": "SECTOR 13",
  "es": "SECTOR 13",
  "it": "SETTORE 13",
  "ca": "SECTOR 13",
  "ar": "القطاع 13"
 },
 "SECTEUR 14": {
  "en": "SECTOR 14",
  "es": "SECTOR 14",
  "it": "SETTORE 14",
  "ca": "SECTOR 14",
  "ar": "القطاع 14"
 },
 "SECTEUR 15": {
  "en": "SECTOR 15",
  "es": "SECTOR 15",
  "it": "SETTORE 15",
  "ca": "SECTOR 15",
  "ar": "القطاع 15"
 },
 "Secteur à l’est de l’île.": {
  "en": "Sector to the east of the island.",
  "es": "Sector al este de la isla.",
  "it": "Settore a est dell'isola.",
  "ca": "Sector a l'est de l'illa.",
  "ar": "قطاع شرق الجزيرة."
 },
 "Secteur agricole au sud-ouest.": {
  "en": "Agricultural sector in the south-west.",
  "es": "Sector agrícola al suroeste.",
  "it": "Settore agricolo a sud-ovest.",
  "ca": "Sector agrícola al sud-oest.",
  "ar": "قطاع زراعي في الجنوب الغربي."
 },
 "Ses deux parents étaient vivants. Ils n'étaient ni des dirigeants ni des scientifiques célèbres. Ils essayaient simplement de donner à leur fils une vie stable. Son père lui répétait que la paix n'était pas l'absence de bruit, mais la capacité de rester ensemble même lorsque tout allait mal. Jean entendait les mots, mais il ne comprenait pas encore ce qu'ils exigeaient réellement.": {
  "en": "Both his parents were alive. They were neither leaders nor famous scientists. They simply tried to give their son a stable life. His father repeated that peace was not the absence of noise, but the ability to stay together even when everything went wrong. Jean heard the words, but did not yet understand what they truly demanded.",
  "es": "Sus dos padres estaban vivos. No eran dirigentes ni científicos famosos. Solo intentaban dar a su hijo una vida estable. Su padre le repetía que la paz no era la ausencia de ruido, sino la capacidad de permanecer juntos incluso cuando todo iba mal. Jean oía las palabras, pero aún no comprendía lo que exigían realmente.",
  "it": "I suoi due genitori erano vivi. Non erano né dirigenti né scienziati famosi. Cercavano semplicemente di dare a loro figlio una vita stabile. Suo padre gli ripeteva che la pace non era l'assenza di rumore, ma la capacità di restare insieme anche quando tutto andava male. Jean udiva le parole, ma non capiva ancora ciò che esigevano davvero.",
  "ca": "Els seus dos pares eren vius. No eren dirigents ni científics famosos. Només intentaven donar al seu fill una vida estable. El seu pare li repetia que la pau no era l'absència de soroll, sinó la capacitat de romandre junts fins i tot quan tot anava malament. En Jean sentia les paraules, però encara no comprenia què exigien realment.",
  "ar": "كان والداه حيّين. لم يكونا قادة ولا علماء مشهورين. كانا يحاولان ببساطة منح ابنهما حياة مستقرة. كان والده يكرّر أن السلام ليس غياب الضجيج، بل القدرة على البقاء معًا حتى حين يسوء كل شيء. سمع جان الكلمات، لكنه لم يفهم بعد ما تتطلبه حقًّا."
 },
 "ses souvenirs impossibles correspondent à une réalité que Jean a officiellement supprimée.": {
  "en": "his impossible memories match a reality that Jean officially erased.",
  "es": "sus recuerdos imposibles corresponden a una realidad que Jean suprimió oficialmente.",
  "it": "i suoi ricordi impossibili corrispondono a una realtà che Jean ha ufficialmente cancellato.",
  "ca": "els seus records impossibles corresponen a una realitat que en Jean va suprimir oficialment.",
  "ar": "ذكرياته المستحيلة تطابق واقعًا محاه جان رسميًّا."
 },
 "Si tu es vraiment sa sœur… pourquoi je ne l'ai jamais su ?": {
  "en": "If you really are his sister… why did I never know?",
  "es": "Si de verdad eres su hermana… ¿por qué no lo supe nunca?",
  "it": "Se sei davvero sua sorella… perché non l'ho mai saputo?",
  "ca": "Si de debò ets la seva germana… per què no ho vaig saber mai?",
  "ar": "إن كنت حقًّا أخته… فلماذا لم أعرف قط؟"
 },
 "SIG 98.4": {
  "en": "SIG 98.4",
  "es": "SIG 98.4",
  "it": "SIG 98.4",
  "ca": "SIG 98.4",
  "ar": "SIG 98.4"
 },
 "SIGNAL : STABLE // 15 REPÈRES": {
  "en": "SIGNAL: STABLE // 15 LANDMARKS",
  "es": "SEÑAL: ESTABLE // 15 PUNTOS DE REFERENCIA",
  "it": "SEGNALE: STABILE // 15 PUNTI DI RIFERIMENTO",
  "ca": "SENYAL: ESTABLE // 15 PUNTS DE REFERÈNCIA",
  "ar": "الإشارة: مستقرة // 15 معلمًا"
 },
 "SIGNAL DÉTECTÉ": {
  "en": "SIGNAL DETECTED",
  "es": "SEÑAL DETECTADA",
  "it": "SEGNALE RILEVATO",
  "ca": "SENYAL DETECTAT",
  "ar": "إشارة مكتشَفة"
 },
 "Son rôle d'éclaireur le place souvent en première ligne. Il ne prétend pas comprendre les phénomènes du Point Zéro, mais il sait reconnaître quand quelque chose ne colle pas. Peu à peu, il commence à se souvenir de lieux où il n'est jamais allé, comme si une autre version de lui essayait de lui transmettre un avertissement.": {
  "en": "His role as scout often puts him on the front line. He does not claim to understand the phenomena of Point Zero, but he knows how to recognise when something does not add up. Little by little, he begins to remember places he has never been to, as if another version of him were trying to send him a warning.",
  "es": "Su papel de explorador lo sitúa a menudo en primera línea. No pretende comprender los fenómenos del Punto Cero, pero sabe reconocer cuándo algo no encaja. Poco a poco, empieza a recordar lugares en los que nunca ha estado, como si otra versión de sí mismo intentara transmitirle una advertencia.",
  "it": "Il suo ruolo di esploratore lo mette spesso in prima linea. Non pretende di capire i fenomeni del Punto Zero, ma sa riconoscere quando qualcosa non quadra. Poco a poco, comincia a ricordare luoghi in cui non è mai stato, come se un'altra versione di lui cercasse di trasmettergli un avvertimento.",
  "ca": "El seu paper d'explorador el situa sovint en primera línia. No pretén entendre els fenòmens del Punt Zero, però sap reconèixer quan alguna cosa no encaixa. A poc a poc, comença a recordar llocs on mai no ha estat, com si una altra versió d'ell mateix intentés transmetre-li un advertiment.",
  "ar": "دوره ككشّاف يضعه غالبًا في الصف الأول. لا يدّعي فهم ظواهر النقطة صفر، لكنه يعرف كيف يميّز عندما لا يستقيم شيء. شيئًا فشيئًا، يبدأ في تذكّر أماكن لم يزرها قط، كأن نسخة أخرى منه تحاول إرسال تحذير إليه."
 },
 "SOUS FREAKY ZERO": {
  "en": "UNDER FREAKY ZERO",
  "es": "BAJO FREAKY ZERO",
  "it": "SOTTO FREAKY ZERO",
  "ca": "SOTA FREAKY ZERO",
  "ar": "تحت فريكي زيرو"
 },
 "Statut final :": {
  "en": "Final status:",
  "es": "Estado final:",
  "it": "Stato finale:",
  "ca": "Estat final:",
  "ar": "الحالة النهائية:"
 },
 "Structure en forme de temple dans la partie ouest.": {
  "en": "Temple-shaped structure in the western part.",
  "es": "Estructura en forma de templo en la parte oeste.",
  "it": "Struttura a forma di tempio nella parte ovest.",
  "ca": "Estructura en forma de temple a la part oest.",
  "ar": "بنية على شكل معبد في الجزء الغربي."
 },
 "suivie d'un code.": {
  "en": "followed by a code.",
  "es": "seguida de un código.",
  "it": "seguita da un codice.",
  "ca": "seguida d’un codi.",
  "ar": "متبوعًا برمز."
 },
 "Synchronisation de la réalité": {
  "en": "Synchronising reality",
  "es": "Sincronizando la realidad",
  "it": "Sincronizzazione della realtà",
  "ca": "Sincronitzant la realitat",
  "ar": "مزامنة الواقع"
 },
 "SYSTÈME": {
  "en": "SYSTEM",
  "es": "SISTEMA",
  "it": "SISTEMA",
  "ca": "SISTEMA",
  "ar": "النظام"
 },
 "SYSTÈME CENTRAL · ACCÈS RESTREINT": {
  "en": "CENTRAL SYSTEM · RESTRICTED ACCESS",
  "es": "SISTEMA CENTRAL · ACCESO RESTRINGIDO",
  "it": "SISTEMA CENTRALE · ACCESSO RISERVATO",
  "ca": "SISTEMA CENTRAL · ACCÉS RESTRINGIT",
  "ar": "النظام المركزي · وصول مقيَّد"
 },
 "TÉLÉCHARGER LA CARTE ↓": {
  "en": "DOWNLOAD THE MAP ↓",
  "es": "DESCARGAR EL MAPA ↓",
  "it": "SCARICA LA MAPPA ↓",
  "ca": "DESCARREGA EL MAPA ↓",
  "ar": "تنزيل الخريطة ↓"
 },
 "Terminal": {
  "en": "Terminal",
  "es": "Terminal",
  "it": "Terminale",
  "ca": "Terminal",
  "ar": "الطرفية",
  "zh": "终端"
 },
 "Terminal — L'Éclat du Point Zéro": {
  "en": "Terminal — The Shard of Point Zero",
  "es": "Terminal — El Resplandor del Punto Cero",
  "it": "Terminale — Lo Splendore del Punto Zero",
  "ca": "Terminal — L’Esclat del Punt Zero",
  "ar": "الطرفية — وهج النقطة صفر"
 },
 "Terrifié à l'idée de se présenter directement au groupe, il envoie Olie pour expliquer son départ de l'île 268. Selon elle, Alyss a fui après avoir ressenti du remords, une émotion qu'il n'avait pas connue depuis très longtemps.": {
  "en": "Terrified at the idea of presenting himself directly to the group, he sends Olie to explain his departure from island 268. According to her, Alyss fled after feeling remorse, an emotion he had not known for a very long time.",
  "es": "Aterrado ante la idea de presentarse directamente al grupo, envía a Olie para explicar su partida de la isla 268. Según ella, Alyss huyó tras sentir remordimiento, una emoción que no había conocido desde hacía muchísimo tiempo.",
  "it": "Terrorizzato all'idea di presentarsi direttamente al gruppo, manda Olie a spiegare la sua partenza dall'isola 268. Secondo lei, Alyss è fuggito dopo aver provato rimorso, un'emozione che non conosceva da molto tempo.",
  "ca": "Terroritzat a la idea de presentar-se directament al grup, envia l'Olie per explicar la seva marxa de l'illa 268. Segons ella, l'Alyss va fugir després de sentir remordiment, una emoció que no havia conegut des de feia moltíssim temps.",
  "ar": "مرعوبًا من فكرة تقديم نفسه مباشرة إلى المجموعة، يرسل أولي لتشرح رحيله من الجزيرة 268. وبحسبها، هرب أليس بعد أن شعر بالندم، شعور لم يعرفه منذ زمن طويل جدًّا."
 },
 "Territoire": {
  "en": "Territory",
  "es": "Territorio",
  "it": "Territorio",
  "ca": "Territori",
  "ar": "الإقليم"
 },
 "The Prison": {
  "en": "The Prison",
  "es": "The Prison",
  "it": "The Prison",
  "ca": "The Prison",
  "ar": "The Prison"
 },
 "Tilted Jool": {
  "en": "Tilted Jool",
  "es": "Tilted Jool",
  "it": "Tilted Jool",
  "ca": "Tilted Jool",
  "ar": "Tilted Jool"
 },
 "Toi… Tu as ses yeux.": {
  "en": "You… You have his eyes.",
  "es": "Tú… Tienes sus ojos.",
  "it": "Tu… Hai i suoi occhi.",
  "ca": "Tu… Tens els seus ulls.",
  "ar": "أنت… لديك عيناه."
 },
 "Ton frère ?": {
  "en": "Your brother?",
  "es": "¿Tu hermano?",
  "it": "Tuo fratello?",
  "ca": "El teu germà?",
  "ar": "أخوك؟"
 },
 "Toujours là-bas. Toujours pris dans cette réalité qui n'en finit pas.": {
  "en": "Still over there. Still caught in that reality that never ends.",
  "es": "Siempre allí. Siempre atrapado en esa realidad que no termina nunca.",
  "it": "Sempre là. Sempre intrappolato in quella realtà che non finisce mai.",
  "ca": "Sempre allà. Sempre atrapat en aquesta realitat que no s'acaba mai.",
  "ar": "لا يزال هناك. لا يزال أسير ذلك الواقع الذي لا ينتهي."
 },
 "Tout commence": {
  "en": "Everything begins",
  "es": "Todo empieza",
  "it": "Tutto comincia",
  "ca": "Tot comença",
  "ar": "كل شيء يبدأ"
 },
 "TRANSCRIPTIONS AUDIO · ACCÈS PUBLIC RESTREINT": {
  "en": "AUDIO TRANSCRIPTS · RESTRICTED PUBLIC ACCESS",
  "es": "TRANSCRIPCIONES DE AUDIO · ACCESO PÚBLICO RESTRINGIDO",
  "it": "TRASCRIZIONI AUDIO · ACCESSO PUBBLICO RISERVATO",
  "ca": "TRANSCRIPCIONS D'ÀUDIO · ACCÉS PÚBLIC RESTRINGIT",
  "ar": "نصوص صوتية · وصول عام مقيَّد"
 },
 "TRANSMISSION 001 — SIGNAL INSTABLE": {
  "en": "TRANSMISSION 001 — UNSTABLE SIGNAL",
  "es": "TRANSMISIÓN 001 — SEÑAL INESTABLE",
  "it": "TRASMISSIONE 001 — SEGNALE INSTABILE",
  "ca": "TRANSMISSIÓ 001 — SENYAL INESTABLE",
  "ar": "البث 001 — إشارة غير مستقرة"
 },
 "TRANSMISSION 002 — ARCHIVE DECA": {
  "en": "TRANSMISSION 002 — DECA ARCHIVE",
  "es": "TRANSMISIÓN 002 — ARCHIVO DECA",
  "it": "TRASMISSIONE 002 — ARCHIVIO DECA",
  "ca": "TRANSMISSIÓ 002 — ARXIU DECA",
  "ar": "البث 002 — أرشيف DECA"
 },
 "TRANSMISSION 003 — ORIGINE INCONNUE": {
  "en": "TRANSMISSION 003 — UNKNOWN ORIGIN",
  "es": "TRANSMISIÓN 003 — ORIGEN DESCONOCIDO",
  "it": "TRASMISSIONE 003 — ORIGINE SCONOSCIUTA",
  "ca": "TRANSMISSIÓ 003 — ORIGEN DESCONEGUT",
  "ar": "البث 003 — أصل مجهول"
 },
 "TRANSMISSION 004 — IDENTITÉ INCONNUE": {
  "en": "TRANSMISSION 004 — UNKNOWN IDENTITY",
  "es": "TRANSMISIÓN 004 — IDENTIDAD DESCONOCIDA",
  "it": "TRASMISSIONE 004 — IDENTITÀ SCONOSCIUTA",
  "ca": "TRANSMISSIÓ 004 — IDENTITAT DESCONEGUDA",
  "ar": "البث 004 — هوية مجهولة"
 },
 "Transmission inconnue": {
  "en": "Unknown transmission",
  "es": "Transmisión desconocida",
  "it": "Trasmissione sconosciuta",
  "ca": "Transmissió desconeguda",
  "ar": "بث مجهول"
 },
 "TRANSMISSION PARTIELLE · SOURCE INCONNUE": {
  "en": "PARTIAL TRANSMISSION · UNKNOWN SOURCE",
  "es": "TRANSMISIÓN PARCIAL · FUENTE DESCONOCIDA",
  "it": "TRASMISSIONE PARZIALE · FONTE SCONOSCIUTA",
  "ca": "TRANSMISSIÓ PARCIAL · FONT DESCONEGUDA",
  "ar": "بث جزئي · مصدر مجهول"
 },
 "Tu as abandonné nos amis et condamné des réalités entières. Tu veux encore me faire croire que tu avais une bonne raison ?": {
  "en": "You abandoned our friends and condemned entire realities. Do you still want to make me believe you had a good reason?",
  "es": "Abandonaste a nuestros amigos y condenaste realidades enteras. ¿Todavía quieres hacerme creer que tenías una buena razón?",
  "it": "Hai abbandonato i nostri amici e condannato intere realtà. Vuoi ancora farmi credere che avevi una buona ragione?",
  "ca": "Vas abandonar els nostres amics i vas condemnar realitats senceres. Encara vols fer-me creure que tenies una bona raó?",
  "ar": "لقد تخليت عن أصدقائنا وحكمت على أواقع كاملة بالدمار. أتريد أن تجعلني أصدّق أن لديك سببًا وجيهًا؟"
 },
 "Tu débarques après tout ce que tu as fait et tu espères qu'on t'accueille comment ?": {
  "en": "You turn up after everything you have done and you expect us to welcome you how?",
  "es": "Apareces después de todo lo que has hecho y ¿cómo esperas que te recibamos?",
  "it": "Ti presenti dopo tutto quello che hai fatto e ti aspetti che ti accogliamo come?",
  "ca": "Apareixes després de tot el que has fet i com esperes que et rebem?",
  "ar": "تظهر بعد كل ما فعلته وتتوقع أن نستقبلك كيف؟"
 },
 "Tu es en train de nous dire que Le Vide a des remords ?": {
  "en": "Are you telling us that the Void feels remorse?",
  "es": "¿Nos estás diciendo que el Vacío siente remordimiento?",
  "it": "Ci stai dicendo che il Vuoto prova rimorso?",
  "ca": "Ens estàs dient que el Buit sent remordiment?",
  "ar": "هل تقولين لنا إن الفراغ يشعر بالندم؟"
 },
 "Tu lui ressembles tellement…": {
  "en": "You look so much like him…",
  "es": "Te pareces tanto a él…",
  "it": "Gli somigli così tanto…",
  "ca": "T'assembles tant a ell…",
  "ar": "أنت تشبهه كثيرًا…"
 },
 "TU M'": {
  "en": "DO YOU ",
  "es": "¿ME ",
  "it": "MI ",
  "ca": "EM ",
  "ar": "هل "
 },
 "Tu m'as promis qu'on le ramènerait.": {
  "en": "You promised me we would bring him back.",
  "es": "Me prometiste que lo traeríamos de vuelta.",
  "it": "Mi hai promesso che l'avremmo riportato indietro.",
  "ca": "Em vas prometre que el tornaríem.",
  "ar": "وعدتني بأننا سنعيده."
 },
 "TU M'ENTENDS ?": {
  "en": "DO YOU HEAR ME ?",
  "es": "¿ME ESCUCHAS ?",
  "it": "MI SENTI ?",
  "ca": "EM SENTS ?",
  "ar": "هل تسمعني ؟"
 },
 "Tu ne peux pas affronter Jean seul !": {
  "en": "You cannot face Jean alone!",
  "es": "¡No puedes enfrentarte a Jean solo!",
  "it": "Non puoi affrontare Jean da solo!",
  "ca": "No pots enfrontar-te a en Jean sol!",
  "ar": "لا يمكنك مواجهة جان وحدك!"
 },
 "Tu ne veux pas sauver le monde. Tu veux être le seul à décider qui a le droit d'y vivre.": {
  "en": "You do not want to save the world. You want to be the only one deciding who has the right to live in it.",
  "es": "No quieres salvar el mundo. Quieres ser el único que decide quién tiene derecho a vivir en él.",
  "it": "Non vuoi salvare il mondo. Vuoi essere l'unico a decidere chi ha il diritto di viverci.",
  "ca": "No vols salvar el món. Vols ser l'únic que decideixi qui té dret a viure-hi.",
  "ar": "أنت لا تريد إنقاذ العالم. تريد أن تكون الوحيد الذي يقرر من يحق له العيش فيه."
 },
 "Tu peux essayer. La liste est déjà prête, Ben. Et ton nom est dessus.": {
  "en": "You can try. The list is already ready, Ben. And your name is on it.",
  "es": "Puedes intentarlo. La lista ya está lista, Ben. Y tu nombre está en ella.",
  "it": "Puoi provarci. La lista è già pronta, Ben. E il tuo nome è sopra.",
  "ca": "Pots intentar-ho. La llista ja està llesta, Ben. I el teu nom hi és.",
  "ar": "يمكنك المحاولة. القائمة جاهزة بالفعل، بن. واسمك عليها."
 },
 "Tu peux l'en sortir ?": {
  "en": "Can you get him out?",
  "es": "¿Puedes sacarlo de ahí?",
  "it": "Puoi tirarlo fuori?",
  "ca": "Pots treure'l d'allà?",
  "ar": "أيمكنك إخراجه؟"
 },
 "Tu poses la mauvaise question. Tu devrais te demander pourquoi son dernier signal est apparu après que j'ai coupé le réseau.": {
  "en": "You are asking the wrong question. You should ask yourself why his last signal appeared after I cut the network.",
  "es": "Haces la pregunta equivocada. Deberías preguntarte por qué su última señal apareció después de que yo cortara la red.",
  "it": "Fai la domanda sbagliata. Dovresti chiederti perché il suo ultimo segnale è apparso dopo che ho tagliato la rete.",
  "ca": "Fas la pregunta equivocada. Hauries de preguntar-te per què el seu últim senyal va aparèixer després que jo tallés la xarxa.",
  "ar": "أنت تطرح السؤال الخاطئ. كان عليك أن تسأل نفسك لماذا ظهرت إشارته الأخيرة بعد أن قطعت الشبكة."
 },
 "Tu vas nous raconter ce qui est arrivé à Jean. Tout.": {
  "en": "You are going to tell us what happened to Jean. Everything.",
  "es": "Vas a contarnos lo que le ocurrió a Jean. Todo.",
  "it": "Ci racconterai ciò che è successo a Jean. Tutto.",
  "ca": "Ens explicaràs què li va passar a en Jean. Tot.",
  "ar": "ستخبرنا بما جرى لجان. كل شيء."
 },
 "Un dossier verrouillé autour des origines de Jean et Ben.": {
  "en": "A sealed file on the origins of Jean and Ben.",
  "es": "Un expediente cerrado sobre los orígenes de Jean y Ben.",
  "it": "Un fascicolo sigillato sulle origini di Jean e Ben.",
  "ca": "Un expedient tancat sobre els orígens d’en Jean i en Ben.",
  "ar": "ملف مغلق حول أصول جان وبين."
 },
 "Un nouveau lieu attire l’attention : une villa moderne gris sombre, installée au milieu d’un lac, avec des piscines et un ponton. C’est là qu’une machine temporelle dépose un nouvel arrivant.": {
  "en": "A new place draws attention: a modern dark-grey villa set in the middle of a lake, with pools and a jetty. That is where a time machine deposits a new arrival.",
  "es": "Un nuevo lugar llama la atención: una villa moderna de gris oscuro, instalada en medio de un lago, con piscinas y un embarcadero. Allí es donde una máquina del tiempo deposita a un nuevo llegado.",
  "it": "Un nuovo luogo attira l’attenzione: una villa moderna grigio scuro, immersa in mezzo a un lago, con piscine e un pontile. È lì che una macchina del tempo deposita un nuovo arrivato.",
  "ca": "Un nou lloc crida l’atenció: una vil·la moderna gris fosc, instal·lada al mig d’un llac, amb piscines i un embarcador. És allà on una màquina del temps deixa un nou arribat.",
  "ar": "مكان جديد يسترعي الانتباه: فيلا عصرية رمادية داكنة، وسط بحيرة، مع مسابح ورصيف. هناك تُنزل آلة زمن قادمًا جديدًا."
 },
 "Un signal inconnu apparaît à chaque fois que Ben découvre une nouvelle information. Il ne se contente pas d'observer les événements : il semble savoir ce que Ben fera ensuite.": {
  "en": "An unknown signal appears each time Ben discovers new information. It does not merely observe events: it seems to know what Ben will do next.",
  "es": "Una señal desconocida aparece cada vez que Ben descubre una nueva información. No se limita a observar los acontecimientos: parece saber lo que Ben hará después.",
  "it": "Un segnale sconosciuto appare ogni volta che Ben scopre una nuova informazione. Non si limita a osservare gli eventi: sembra sapere ciò che Ben farà dopo.",
  "ca": "Un senyal desconegut apareix cada vegada que en Ben descobreix una informació nova. No es limita a observar els esdeveniments: sembla saber què farà en Ben després.",
  "ar": "تظهر إشارة مجهولة في كل مرة يكتشف فيها بن معلومة جديدة. لا تكتفي بمراقبة الأحداث: بل تبدو عارفة بما سيفعله بن بعد ذلك."
 },
 "UNE ÎLE RECONSTRUITE": {
  "en": "A REBUILT ISLAND",
  "es": "UNA ISLA RECONSTRUIDA",
  "it": "UN’ISOLA RICOSTRUITA",
  "ca": "UNA ILLA RECONSTRUÏDA",
  "ar": "جزيرة أُعيد بناؤها"
 },
 "Une île restaurée": {
  "en": "A restored island",
  "es": "Una isla restaurada",
  "it": "Un'isola restaurata",
  "ca": "Una illa restaurada",
  "ar": "جزيرة مستعادة"
 },
 "Une île.": {
  "en": "An island.",
  "es": "Una isla.",
  "it": "Un’isola.",
  "ca": "Una illa.",
  "ar": "جزيرة."
 },
 "Une nuit, Jean observa une lueur immobile derrière les nuages. Pendant une fraction de seconde, la pièce se tut : l'horloge, le vent, les voix de ses parents. Tout sembla suspendu. Puis le monde reprit son cours. Ses parents le rassurèrent, pensant qu'il avait fait un mauvais rêve. Jean, lui, se souvint du silence comme d'une promesse.": {
  "en": "One night, Jean observed a motionless glow behind the clouds. For a fraction of a second, the room fell silent: the clock, the wind, his parents' voices. Everything seemed suspended. Then the world resumed. His parents reassured him, thinking he had had a bad dream. Jean remembered the silence as a promise.",
  "es": "Una noche, Jean observó un resplandor inmóvil tras las nubes. Durante una fracción de segundo, la habitación calló: el reloj, el viento, las voces de sus padres. Todo pareció suspendido. Luego el mundo reanudó su curso. Sus padres lo tranquilizaron, pensando que había tenido una pesadilla. Jean recordó el silencio como una promesa.",
  "it": "Una notte, Jean osservò un bagliore immobile dietro le nuvole. Per una frazione di secondo, la stanza tacque: l'orologio, il vento, le voci dei suoi genitori. Tutto sembrò sospeso. Poi il mondo riprese il suo corso. I suoi genitori lo rassicurarono, pensando che avesse fatto un brutto sogno. Jean ricordò il silenzio come una promessa.",
  "ca": "Una nit, en Jean va observar una lluentor immòbil darrere dels núvols. Durant una fracció de segon, l'habitació va callar: el rellotge, el vent, les veus dels seus pares. Tot va semblar suspès. Després el món va reprendre el seu curs. Els seus pares el van tranquil·litzar, pensant que havia tingut un malson. En Jean va recordar el silenci com una promesa.",
  "ar": "ذات ليلة، راقب جان وهجًا ساكنًا خلف السحاب. ولجزء من الثانية، صمتت الغرفة: الساعة، والريح، وأصوات والديه. بدا كل شيء معلّقًا. ثم استأنف العالم مساره. طمأنه والداه، ظنًّا منه أنه رأى حلمًا سيئًا. أما جان، فتذكّر الصمت كأنه وعد."
 },
 "Une pulsation inconnue remonte des profondeurs de Freaky Zero. La Garde Zéro reprend l'enquête. Cette fois, le signal semble connaître ceux qui l'écoutent.": {
  "en": "An unknown pulse rises from the depths of Freaky Zero. The Zero Guard resumes the investigation. This time, the signal seems to know those who listen to it.",
  "es": "Una pulsación desconocida asciende desde las profundidades de Freaky Zero. La Guardia Cero retoma la investigación. Esta vez, la señal parece conocer a quienes la escuchan.",
  "it": "Una pulsazione sconosciuta risale dalle profondità di Freaky Zero. La Guardia Zero riprende l’indagine. Questa volta, il segnale sembra conoscere chi lo ascolta.",
  "ca": "Una pulsació desconeguda puja de les profunditats de Freaky Zero. La Guàrdia Zero reprèn la investigació. Aquesta vegada, el senyal sembla conèixer qui l’escolta.",
  "ar": "نبضة مجهولة تصعد من أعماق فريكي زيرو. يستأنف حرس الصفر التحقيق. هذه المرة، يبدو أن الإشارة تعرف من يستمعون إليها."
 },
 "Une voix a été interceptée. Son origine reste introuvable.": {
  "en": "A voice was intercepted. Its origin remains untraceable.",
  "es": "Se interceptó una voz. Su origen sigue sin rastrearse.",
  "it": "È stata intercettata una voce. La sua origine resta introvabile.",
  "ca": "S’ha interceptat una veu. El seu origen continua sense rastrejar.",
  "ar": "تم اعتراض صوت. أصله لا يزال مجهولًا."
 },
 "Une voix qui ne devrait plus exister": {
  "en": "A voice that should no longer exist",
  "es": "Una voz que ya no debería existir",
  "it": "Una voce che non dovrebbe più esistere",
  "ca": "Una veu que ja no hauria d'existir",
  "ar": "صوت ما كان يجب أن يوجد بعد"
 },
 "unlock": {
  "en": "unlock",
  "es": "unlock",
  "it": "unlock",
  "ca": "unlock",
  "ar": "unlock"
 },
 "unlock aidanestvivant": {
  "en": "unlock aidanestvivant",
  "es": "unlock aidanestvivant",
  "it": "unlock aidanestvivant",
  "ca": "unlock aidanestvivant",
  "ar": "unlock aidanestvivant"
 },
 "unlock ancienallie": {
  "en": "unlock ancienallie",
  "es": "unlock ancienallie",
  "it": "unlock ancienallie",
  "ca": "unlock ancienallie",
  "ar": "unlock ancienallie"
 },
 "unlock dernierfragment": {
  "en": "unlock dernierfragment",
  "es": "unlock dernierfragment",
  "it": "unlock dernierfragment",
  "ca": "unlock dernierfragment",
  "ar": "unlock dernierfragment"
 },
 "unlock etoile": {
  "en": "unlock etoile",
  "es": "unlock etoile",
  "it": "unlock etoile",
  "ca": "unlock etoile",
  "ar": "unlock etoile"
 },
 "unlock kael": {
  "en": "unlock kael",
  "es": "unlock kael",
  "it": "unlock kael",
  "ca": "unlock kael",
  "ar": "unlock kael"
 },
 "unlock kaelretour": {
  "en": "unlock kaelretour",
  "es": "unlock kaelretour",
  "it": "unlock kaelretour",
  "ca": "unlock kaelretour",
  "ar": "unlock kaelretour"
 },
 "unlock oliekael": {
  "en": "unlock oliekael",
  "es": "unlock oliekael",
  "it": "unlock oliekael",
  "ca": "unlock oliekael",
  "ar": "unlock oliekael"
 },
 "unlock restauration": {
  "en": "unlock restauration",
  "es": "unlock restauration",
  "it": "unlock restauration",
  "ca": "unlock restauration",
  "ar": "unlock restauration"
 },
 "unlock retourimpossible": {
  "en": "unlock retourimpossible",
  "es": "unlock retourimpossible",
  "it": "unlock retourimpossible",
  "ca": "unlock retourimpossible",
  "ar": "unlock retourimpossible"
 },
 "unlock sanctuaire": {
  "en": "unlock sanctuaire",
  "es": "unlock sanctuaire",
  "it": "unlock sanctuaire",
  "ca": "unlock sanctuaire",
  "ar": "unlock sanctuaire"
 },
 "unlock signalbleu": {
  "en": "unlock signalbleu",
  "es": "unlock signalbleu",
  "it": "unlock signalbleu",
  "ca": "unlock signalbleu",
  "ar": "unlock signalbleu"
 },
 "vaincu par les alliés, Jean s’est désintégré en étoile lorsque sa machine a été détruite. La lumière dans le ciel correspondait à cette destruction.": {
  "en": "defeated by the allies, Jean disintegrated into a star when his machine was destroyed. The light in the sky corresponded to that destruction.",
  "es": "vencido por los aliados, Jean se desintegró en estrella cuando su máquina fue destruida. La luz en el cielo correspondía a esa destrucción.",
  "it": "sconfitto dagli alleati, Jean si è disintegrato in una stella quando la sua macchina è stata distrutta. La luce nel cielo corrispondeva a quella distruzione.",
  "ca": "vençut pels aliats, en Jean es va desintegrar en estrella quan la seva màquina va ser destruïda. La llum al cel corresponia a aquesta destrucció.",
  "ar": "بعد هزيمته على يد الحلفاء، تحلَّل جان إلى نجمة عندما دُمِّرت آلته. وكان الضوء في السماء يعبر عن ذلك الدمار."
 },
 "Vanny": {
  "en": "Vanny",
  "es": "Vanny",
  "it": "Vanny",
  "ca": "Vanny",
  "ar": "فاني"
 },
 "VANNY": {
  "en": "VANNY",
  "es": "VANNY",
  "it": "VANNY",
  "ca": "VANNY",
  "ar": "فاني"
 },
 "VANNY :": {
  "en": "VANNY:",
  "es": "VANNY:",
  "it": "VANNY:",
  "ca": "VANNY:",
  "ar": "فاني:"
 },
 "Vanny ne fait pas confiance aux grandes déclarations. Là où Ben voit un ami qu'il faut sauver et Jean voit une solution à imposer, elle cherche les faits, les dates et les contradictions. C'est elle qui fouille les archives, compare les versions du monde et repère les erreurs dans les simulations. Son calme peut donner l'impression qu'elle est distante, mais c'est sa façon de ne pas laisser la peur prendre les décisions à sa place.": {
  "en": "Vanny does not trust grand declarations. Where Ben sees a friend to save and Jean sees a solution to impose, she looks for facts, dates and contradictions. She is the one who digs through the archives, compares versions of the world and spots errors in the simulations. Her calm can give the impression that she is distant, but it is her way of not letting fear make decisions in her place.",
  "es": "Vanny no se fía de las grandes declaraciones. Donde Ben ve a un amigo al que hay que salvar y Jean ve una solución que imponer, ella busca los hechos, las fechas y las contradicciones. Es quien rebusca en los archivos, compara las versiones del mundo y detecta los errores en las simulaciones. Su calma puede dar la impresión de que es distante, pero es su forma de no dejar que el miedo tome las decisiones en su lugar.",
  "it": "Vanny non si fida delle grandi dichiarazioni. Dove Ben vede un amico da salvare e Jean vede una soluzione da imporre, lei cerca i fatti, le date e le contraddizioni. È lei che fruga negli archivi, confronta le versioni del mondo e individua gli errori nelle simulazioni. La sua calma può dare l'impressione che sia distante, ma è il suo modo di non lasciare che la paura prenda le decisioni al posto suo.",
  "ca": "La Vanny no es refia de les grans declaracions. On en Ben veu un amic a salvar i en Jean veu una solució a imposar, ella busca els fets, les dates i les contradiccions. És qui remena els arxius, compara les versions del món i detecta els errors en les simulacions. La seva calma pot fer la impressió que és distant, però és la seva manera de no deixar que la por prengui les decisions al seu lloc.",
  "ar": "لا تثق فاني بالتصريحات الكبيرة. حيث يرى بن صديقًا يجب إنقاذه ويرى جان حلًّا يجب فرضه، تبحث هي عن الوقائع والتواريخ والتناقضات. هي من تنقّب في الأرشيف، وتقارن نسخ العالم، وترصد الأخطاء في المحاكاات. قد يوحي هدوئها بأنها بعيدة، لكنها طريقتها كي لا تدع الخوف يتخذ القرارات مكانها."
 },
 "Vanny ne fait pas confiance aux grandes déclarations. Là où Ben voit un ami qu'il faut sauver et Jean voit une solution à imposer, elle cherche les faits, les dates et les contradictions.…": {
  "en": "Vanny does not trust grand declarations. Where Ben sees a friend to save and Jean sees a solution to impose, she looks for facts, dates and contradictions.…",
  "es": "Vanny no se fía de las grandes declaraciones. Donde Ben ve a un amigo al que hay que salvar y Jean ve una solución que imponer, ella busca los hechos, las fechas y las contradicciones.…",
  "it": "Vanny non si fida delle grandi dichiarazioni. Dove Ben vede un amico da salvare e Jean vede una soluzione da imporre, lei cerca i fatti, le date e le contraddizioni.…",
  "ca": "La Vanny no es refia de les grans declaracions. On en Ben veu un amic a salvar i en Jean veu una solució a imposar, ella busca els fets, les dates i les contradiccions.…",
  "ar": "لا تثق فاني بالتصريحات الكبيرة. حيث يرى بن صديقًا يجب إنقاذه ويرى جان حلًّا يجب فرضه، تبحث هي عن الوقائع والتواريخ والتناقضات.…"
 },
 "Vanny revient, dans des circonstances encore floues, derrière une tour qui devait détruire une faille mais l'a au contraire agrandie. Ducky, un homme riche obsédé par l'anatomie de Point Zéro mais incapable de vaincre le Vide seul, rejoint aussi le groupe après avoir montré ses recherches. Darian, rencontré dans un temple volcanique, reste un allié ambigu, ni confirmé ennemi ni confirmé ami.": {
  "en": "Vanny returns, under still unclear circumstances, behind a tower that was meant to destroy a rift but instead enlarged it. Ducky, a wealthy man obsessed with the anatomy of Point Zero yet unable to defeat the Void alone, also joins the group after showing his research. Darian, met in a volcanic temple, remains an ambiguous ally, neither a confirmed enemy nor a confirmed friend.",
  "es": "Vanny regresa, en circunstancias aún confusas, tras una torre que debía destruir una falla pero que, al contrario, la agrandó. Ducky, un hombre rico obsesionado con la anatomía del Punto Cero pero incapaz de vencer al Vacío solo, también se une al grupo tras mostrar sus investigaciones. Darian, conocido en un templo volcánico, sigue siendo un aliado ambiguo, ni enemigo confirmado ni amigo confirmado.",
  "it": "Vanny torna, in circostanze ancora confuse, dietro una torre che doveva distruggere una faglia ma che invece l’ha ingrandita. Ducky, un uomo ricco ossessionato dall’anatomia del Punto Zero ma incapace di sconfiggere il Vuoto da solo, si unisce anch’egli al gruppo dopo aver mostrato le sue ricerche. Darian, incontrato in un tempio vulcanico, resta un alleato ambiguo, né nemico confermato né amico confermato.",
  "ca": "En Vanny torna, en circumstàncies encara confuses, darrere una torre que havia de destruir una escletxa però que, al contrari, la va engrandir. En Ducky, un home ric obsessionat amb l’anatomia del Punt Zero però incapaç de vèncer el Buit tot sol, també s’uneix al grup després de mostrar les seves recerques. En Darian, conegut en un temple volcànic, continua sent un aliat ambigu, ni enemic confirmat ni amic confirmat.",
  "ar": "تعود فاني، في ظروف لا تزال غامضة، خلف برج كان يُفترض أن يدمّر صدعًا لكنه وسّعه بدلًا من ذلك. وينضم دكي، رجل ثري مهووس بتشريح النقطة صفر لكنه عاجز عن هزيمة الفراغ وحده، إلى المجموعة بعد أن عرض أبحاثه. أما داريان، الذي لُقي في معبد بركاني، فيبقى حليفًا غامضًا، لا عدوًّا مؤكدًا ولا صديقًا مؤكدًا."
 },
 "Ville installée près de la rivière, au sud-est du centre.": {
  "en": "Town set near the river, south-east of the centre.",
  "es": "Ciudad situada cerca del río, al sureste del centro.",
  "it": "Città situata vicino al fiume, a sud-est del centro.",
  "ca": "Ciutat situada a prop del riu, al sud-est del centre.",
  "ar": "بلدة قريبة من النهر، جنوب شرق المركز."
 },
 "VOIX IDENTIFIÉE PARTIELLEMENT // JEAN": {
  "en": "VOICE PARTIALLY IDENTIFIED // JEAN",
  "es": "VOZ IDENTIFICADA PARCIALMENTE // JEAN",
  "it": "VOCE PARZIALMENTE IDENTIFICATA // JEAN",
  "ca": "VEU IDENTIFICADA PARCIALMENT // JEAN",
  "ar": "الصوت محدَّد جزئيًا // جان"
 },
 "VOSS :": {
  "en": "VOSS:",
  "es": "VOSS:",
  "it": "VOSS:",
  "ca": "VOSS:",
  "ar": "فوس:"
 },
 "Voss connaît les travaux qui ont précédé les simulations de Jean. Il affirme ne pas avoir participé au projet final, mais plusieurs dossiers portent sa signature. Il soutient qu'il cherchait à contenir les fractures, pas à contrôler les réalités. La différence entre ces deux objectifs est au cœur du mystère.": {
  "en": "Voss knows the work that preceded Jean's simulations. He claims not to have taken part in the final project, but several files bear his signature. He maintains that he sought to contain fractures, not to control realities. The difference between these two goals lies at the heart of the mystery.",
  "es": "Voss conoce los trabajos que precedieron a las simulaciones de Jean. Afirma no haber participado en el proyecto final, pero varios expedientes llevan su firma. Sostiene que buscaba contener las fracturas, no controlar las realidades. La diferencia entre estos dos objetivos está en el corazón del misterio.",
  "it": "Voss conosce i lavori che hanno preceduto le simulazioni di Jean. Afferma di non aver partecipato al progetto finale, ma diversi fascicoli portano la sua firma. Sostiene di cercare di contenere le fratture, non di controllare le realtà. La differenza tra questi due obiettivi è al cuore del mistero.",
  "ca": "En Voss coneix els treballs que van precedir les simulacions d'en Jean. Afirma no haver participat en el projecte final, però diversos expedients porten la seva signatura. Sosté que buscava contenir les fractures, no controlar les realitats. La diferència entre aquests dos objectius és al cor del misteri.",
  "ar": "يعرف فوس الأعمال التي سبقت محاكاات جان. يؤكد أنه لم يشارك في المشروع الأخير، لكن عدة ملفات تحمل توقيعه. ويقول إنه كان يسعى لاحتواء التصدُّعات، لا للسيطرة على الأواقع. والفارق بين الهدفين يقع في قلب اللغز."
 },
 "Voss détruit ensuite le portail, alors que Jean s'y trouve toujours. L'énergie libérée ne disparaît pas : elle se disperse à travers le ciel, puis un éclat lumineux, de la même nature qu'un Point Zéro mais d'une signature jamais vue auparavant — ni celle de la Garde Zéro ni celle de l'île originelle — s'écrase sur plusieurs points de la réalité, sous les yeux de Ben, Voss, Vanny et Ducky réunis. Cet éclat annonce la dernière phase du conflit. Le sort de Jean sera définitivement révélé à la fin de la Saison 7 : il sera vaincu et mourra lorsque sa machine sera détruite.": {
  "en": "Voss then destroys the portal while Jean is still inside. The energy released does not vanish: it scatters across the sky, and then a luminous shard, of the same nature as a Point Zero but with a signature never seen before — neither that of the Zero Guard nor that of the original island — crashes down on several points of reality, before the eyes of Ben, Voss, Vanny and Ducky gathered together. That shard heralds the final phase of the conflict. Jean's fate will be definitively revealed at the end of Season 7: he will be defeated and die when his machine is destroyed.",
  "es": "Voss destruye entonces el portal, mientras Jean sigue dentro. La energía liberada no desaparece: se dispersa por el cielo y luego un destello luminoso, de la misma naturaleza que un Punto Cero pero con una firma nunca vista antes — ni la de la Guardia Cero ni la de la isla original — se estrella en varios puntos de la realidad, ante los ojos de Ben, Voss, Vanny y Ducky reunidos. Ese destello anuncia la última fase del conflicto. El destino de Jean se revelará definitivamente al final de la Temporada 7: será vencido y morirá cuando su máquina sea destruida.",
  "it": "Voss distrugge poi il portale, mentre Jean si trova ancora dentro. L’energia liberata non svanisce: si disperde nel cielo, poi un frammento luminoso, della stessa natura di un Punto Zero ma con una firma mai vista prima — né quella della Guardia Zero né quella dell’isola originaria — si schianta su diversi punti della realtà, davanti agli occhi di Ben, Voss, Vanny e Ducky riuniti. Quel frammento annuncia l’ultima fase del conflitto. Il destino di Jean sarà rivelato definitivamente alla fine della Stagione 7: sarà sconfitto e morirà quando la sua macchina verrà distrutta.",
  "ca": "En Voss destrueix llavors el portal, mentre en Jean encara hi és dins. L’energia alliberada no desapareix: es dispersa pel cel i després un esclat lluminós, de la mateixa naturalesa que un Punt Zero però amb una signatura mai vista abans — ni la de la Guàrdia Zero ni la de l’illa originària — s’estavella en diversos punts de la realitat, davant dels ulls d’en Ben, en Voss, en Vanny i en Ducky reunits. Aquest esclat anuncia l’última fase del conflicte. El destí d’en Jean es revelarà definitivament al final de la Temporada 7: serà vençut i morirà quan la seva màquina sigui destruïda.",
  "ar": "ثم تدمّر فوس البوابة بينما لا يزال جان في داخلها. الطاقة المنبعثة لا تختفي: تتناثر عبر السماء، ثم يسقط وميض مضيء، من طبيعة النقطة صفر لكن بتوقيع لم يُرَ من قبل — لا توقيع حرس الصفر ولا توقيع الجزيرة الأصلية — على عدة نقاط من الواقع، أمام أعين بن وفوس وفاني ودكي مجتمعين. ذلك الوميض يعلن المرحلة الأخيرة من الصراع. سيُكشف مصير جان نهائيًّا في نهاية الموسم 7: سيُهزم ويموت عندما تُدمَّر آلته."
 },
 "Vous commencez enfin à poser la bonne question.": {
  "en": "You are finally starting to ask the right question.",
  "es": "Por fin empiezas a hacer la pregunta correcta.",
  "it": "Finalmente cominci a fare la domanda giusta.",
  "ca": "Per fi comences a fer la pregunta correcta.",
  "ar": "أخيرًا بدأت تطرح السؤال الصحيح."
 },
 "ZÉRO": {
  "en": "ZERO",
  "es": "CERO",
  "it": "ZERO",
  "ca": "ZERO",
  "ar": "صفر"
 },
 "ZONE 01": {
  "en": "ZONE 01",
  "es": "ZONA 01",
  "it": "ZONA 01",
  "ca": "ZONA 01",
  "ar": "المنطقة 01"
 },
 "ZONE 03": {
  "en": "ZONE 03",
  "es": "ZONA 03",
  "it": "ZONA 03",
  "ca": "ZONA 03",
  "ar": "المنطقة 03"
 },
 "ZONE 04": {
  "en": "ZONE 04",
  "es": "ZONA 04",
  "it": "ZONA 04",
  "ca": "ZONA 04",
  "ar": "المنطقة 04"
 },
 "ZONE 05": {
  "en": "ZONE 05",
  "es": "ZONA 05",
  "it": "ZONA 05",
  "ca": "ZONA 05",
  "ar": "المنطقة 05"
 },
 "ZONE 06": {
  "en": "ZONE 06",
  "es": "ZONA 06",
  "it": "ZONA 06",
  "ca": "ZONA 06",
  "ar": "المنطقة 06"
 },
 "ZONE 09": {
  "en": "ZONE 09",
  "es": "ZONA 09",
  "it": "ZONA 09",
  "ca": "ZONA 09",
  "ar": "المنطقة 09"
 },
 "ZONE 10": {
  "en": "ZONE 10",
  "es": "ZONA 10",
  "it": "ZONA 10",
  "ca": "ZONA 10",
  "ar": "المنطقة 10"
 },
 "ZONE 11": {
  "en": "ZONE 11",
  "es": "ZONA 11",
  "it": "ZONA 11",
  "ca": "ZONA 11",
  "ar": "المنطقة 11"
 },
 "ZONE 12": {
  "en": "ZONE 12",
  "es": "ZONA 12",
  "it": "ZONA 12",
  "ca": "ZONA 12",
  "ar": "المنطقة 12"
 },
 "ZONE 13": {
  "en": "ZONE 13",
  "es": "ZONA 13",
  "it": "ZONA 13",
  "ca": "ZONA 13",
  "ar": "المنطقة 13"
 },
 "ZONE 15": {
  "en": "ZONE 15",
  "es": "ZONA 15",
  "it": "ZONA 15",
  "ca": "ZONA 15",
  "ar": "المنطقة 15"
 },
 "ZONE 16": {
  "en": "ZONE 16",
  "es": "ZONA 16",
  "it": "ZONA 16",
  "ca": "ZONA 16",
  "ar": "المنطقة 16"
 },
 "ZONE 18": {
  "en": "ZONE 18",
  "es": "ZONA 18",
  "it": "ZONA 18",
  "ca": "ZONA 18",
  "ar": "المنطقة 18"
 },
 "ZONE 19": {
  "en": "ZONE 19",
  "es": "ZONA 19",
  "it": "ZONA 19",
  "ca": "ZONA 19",
  "ar": "المنطقة 19"
 },
 "ZONE 22": {
  "en": "ZONE 22",
  "es": "ZONA 22",
  "it": "ZONA 22",
  "ca": "ZONA 22",
  "ar": "المنطقة 22"
 },
 "Zone bâtie à l’ouest du Freaky Zero.": {
  "en": "Built-up area west of Freaky Zero.",
  "es": "Zona edificada al oeste de Freaky Zero.",
  "it": "Zona edificata a ovest di Freaky Zero.",
  "ca": "Zona edificada a l'oest de Freaky Zero.",
  "ar": "منطقة مبنية غرب Freaky Zero."
 },
 "Zone bâtie au sud du centre.": {
  "en": "Built-up area south of the centre.",
  "es": "Zona edificada al sur del centro.",
  "it": "Zona edificata a sud del centro.",
  "ca": "Zona edificada al sud del centre.",
  "ar": "منطقة مبنية جنوب المركز."
 },
 "Zone boisée au nord-ouest.": {
  "en": "Wooded area in the north-west.",
  "es": "Zona boscosa al noroeste.",
  "it": "Zona boscosa a nord-ovest.",
  "ca": "Zona boscosa al nord-oest.",
  "ar": "منطقة حرجية في الشمال الغربي."
 },
 "ZONE CONCERNÉE": {
  "en": "AFFECTED ZONE",
  "es": "ZONA AFECTADA",
  "it": "ZONA INTERESSATA",
  "ca": "ZONA AFECTADA",
  "ar": "المنطقة المعنية"
 },
 "Zone portuaire au nord-ouest.": {
  "en": "Port area in the north-west.",
  "es": "Zona portuaria al noroeste.",
  "it": "Zona portuale a nord-ovest.",
  "ca": "Zona portuària al nord-oest.",
  "ar": "منطقة ميناء في الشمال الغربي."
 },
 "Dossier personnel — Jennifer Derimight.": {
  "en": "Personal file — Jennifer Derimight.",
  "es": "Expediente personal — Jennifer Derimight.",
  "it": "Fascicolo personale — Jennifer Derimight.",
  "ca": "Expedient personal — Jennifer Derimight.",
  "ar": "الملف الشخصي — جينيفر ديرمايت."
 },
 "DOSSIER PERSONNEL · ACCÈS RESTREINT": {
  "en": "PERSONAL FILE · RESTRICTED ACCESS",
  "es": "EXPEDIENTE PERSONAL · ACCESO RESTRINGIDO",
  "it": "FASCICOLO PERSONALE · ACCESSO LIMITATO",
  "ca": "EXPEDIENT PERSONAL · ACCÉS RESTRINGIT",
  "ar": "الملف الشخصي · وصول مقيّد"
 },
 "Jennifer": {
  "en": "Jennifer",
  "es": "Jennifer",
  "it": "Jennifer",
  "ca": "Jennifer",
  "ar": "Jennifer"
 },
 "Derimight": {
  "en": "Derimight",
  "es": "Derimight",
  "it": "Derimight",
  "ca": "Derimight",
  "ar": "Derimight"
 },
 "Nom de code :": {
  "en": "Code name:",
  "es": "Nombre en clave:",
  "it": "Nome in codice:",
  "ca": "Nom en clau:",
  "ar": "الاسم الرمزي:"
 },
 "LOOPING": {
  "en": "LOOPING",
  "es": "LOOPING",
  "it": "LOOPING",
  "ca": "LOOPING",
  "ar": "LOOPING"
 },
 "Dossier déverrouillé depuis le terminal central.": {
  "en": "File unlocked from the central terminal.",
  "es": "Expediente desbloqueado desde el terminal central.",
  "it": "Fascicolo sbloccato dal terminale centrale.",
  "ca": "Expedient desbloquejat des del terminal central.",
  "ar": "تم فتح الملف من الوحدة الطرفية المركزية."
 },
 "NOUVELLE ARRIVÉE": {
  "en": "NEW ARRIVAL",
  "es": "NUEVA LLEGADA",
  "it": "NUOVO ARRIVO",
  "ca": "NOVA ARRIBADA",
  "ar": "وافد جديد"
 },
 "STATUT : NON CONFIRMÉ": {
  "en": "STATUS: UNCONFIRMED",
  "es": "ESTADO: NO CONFIRMADO",
  "it": "STATO: NON CONFERMATO",
  "ca": "ESTAT: NO CONFIRMAT",
  "ar": "الحالة: غير مؤكدة"
 },
 "Identité :": {
  "en": "Identity:",
  "es": "Identidad:",
  "it": "Identità:",
  "ca": "Identitat:",
  "ar": "الهوية:"
 },
 "Statut :": {
  "en": "Status:",
  "es": "Estado:",
  "it": "Stato:",
  "ca": "Estat:",
  "ar": "الحالة:"
 },
 "présence détectée, affiliation inconnue": {
  "en": "presence detected, affiliation unknown",
  "es": "presencia detectada, afiliación desconocida",
  "it": "presenza rilevata, affiliazione sconosciuta",
  "ca": "presència detectada, afiliació desconeguda",
  "ar": "تم رصد وجود، والانتماء غير معروف"
 },
 "Première observation :": {
  "en": "First observation:",
  "es": "Primera observación:",
  "it": "Prima osservazione:",
  "ca": "Primera observació:",
  "ar": "أول رصد:"
 },
 "une anomalie de boucle temporelle enregistrée dans les systèmes de l’Institut Onirique.": {
  "en": "a time-loop anomaly recorded in the Oneiric Institute systems.",
  "es": "una anomalía de bucle temporal registrada en los sistemas del Instituto Onírico.",
  "it": "un'anomalia di ciclo temporale registrata nei sistemi dell'Istituto Onirico.",
  "ca": "una anomalia de bucle temporal registrada als sistemes de l'Institut Oníric.",
  "ar": "خلل في حلقة زمنية سُجّل في أنظمة المعهد الحلمي."
 },
 "Rapport préliminaire": {
  "en": "Preliminary report",
  "es": "Informe preliminar",
  "it": "Rapporto preliminare",
  "ca": "Informe preliminar",
  "ar": "تقرير أولي"
 },
 "Jennifer Derimight vient d'apparaître dans les archives sous le nom de code LOOPING. Les données disponibles sont incomplètes. Les systèmes ont repéré plusieurs répétitions dans les relevés temporels, mais aucun élément ne permet encore de déterminer si Jennifer en est la cause, la victime ou la seule personne capable de les comprendre.": {
  "en": "Jennifer Derimight has appeared in the archives under the codename LOOPING. The available data is incomplete. Systems have detected repeated patterns in temporal readings, but there is not yet enough evidence to determine whether Jennifer is their cause, their victim, or the only person able to understand them.",
  "es": "Jennifer Derimight acaba de aparecer en los archivos con el nombre en clave LOOPING. Los datos disponibles están incompletos. Los sistemas han detectado varias repeticiones en los registros temporales, pero aún no hay pruebas para determinar si Jennifer es su causa, su víctima o la única persona capaz de comprenderlas.",
  "it": "Jennifer Derimight è appena apparsa negli archivi con il nome in codice LOOPING. I dati disponibili sono incompleti. I sistemi hanno rilevato diverse ripetizioni nelle letture temporali, ma non ci sono ancora elementi per stabilire se Jennifer ne sia la causa, la vittima o l'unica persona in grado di comprenderle.",
  "ca": "Jennifer Derimight acaba d'aparèixer als arxius amb el nom en clau LOOPING. Les dades disponibles són incompletes. Els sistemes han detectat diverses repeticions en els registres temporals, però encara no hi ha proves per determinar si Jennifer n'és la causa, la víctima o l'única persona capaç d'entendre-les.",
  "ar": "ظهرت جينيفر ديرمايت للتو في الأرشيفات بالاسم الرمزي LOOPING. البيانات المتاحة غير مكتملة. رصدت الأنظمة تكرارات متعددة في القراءات الزمنية، لكن لا توجد أدلة كافية بعد لتحديد ما إذا كانت جينيفر سببها أم ضحيتها أم الشخص الوحيد القادر على فهمها."
 },
 "Son arrivée pourrait être liée à une anomalie encore active autour du Point Zéro. Toute tentative de contact doit être enregistrée dans le terminal.": {
  "en": "Her arrival may be connected to an anomaly still active around the Zero Point. Any attempt to contact her must be recorded in the terminal.",
  "es": "Su llegada podría estar relacionada con una anomalía que sigue activa alrededor del Punto Cero. Cualquier intento de contacto debe registrarse en el terminal.",
  "it": "Il suo arrivo potrebbe essere collegato a un'anomalia ancora attiva attorno al Punto Zero. Ogni tentativo di contatto deve essere registrato nel terminale.",
  "ca": "La seva arribada podria estar relacionada amb una anomalia encara activa al voltant del Punt Zero. Qualsevol intent de contacte s'ha de registrar al terminal.",
  "ar": "قد يكون وصولها مرتبطًا بخلل لا يزال نشطًا حول نقطة الصفر. يجب تسجيل أي محاولة اتصال في الوحدة الطرفية."
 },
 "Informations classifiées": {
  "en": "Classified information",
  "es": "Información clasificada",
  "it": "Informazioni riservate",
  "ca": "Informació classificada",
  "ar": "معلومات سرية"
 },
 "Motivations :": {
  "en": "Motivations:",
  "es": "Motivaciones:",
  "it": "Motivazioni:",
  "ca": "Motivacions:",
  "ar": "الدوافع:"
 },
 "inconnues.": {
  "en": "unknown.",
  "es": "desconocidas.",
  "it": "sconosciute.",
  "ca": "desconegudes.",
  "ar": "غير معروفة."
 },
 "Liens avec les autres personnages :": {
  "en": "Connections to other characters:",
  "es": "Relaciones con los demás personajes:",
  "it": "Legami con gli altri personaggi:",
  "ca": "Relacions amb els altres personatges:",
  "ar": "الروابط مع الشخصيات الأخرى:"
 },
 "non établis.": {
  "en": "not established.",
  "es": "no establecidas.",
  "it": "non definiti.",
  "ca": "no establertes.",
  "ar": "غير محددة."
 },
 "Origine :": {
  "en": "Origin:",
  "es": "Origen:",
  "it": "Origine:",
  "ca": "Origen:",
  "ar": "الأصل:"
 },
 "dossier incomplet.": {
  "en": "incomplete file.",
  "es": "expediente incompleto.",
  "it": "fascicolo incompleto.",
  "ca": "expedient incomplet.",
  "ar": "ملف غير مكتمل."
 },
 "Dernière note :": {
  "en": "Last note:",
  "es": "Última nota:",
  "it": "Ultima nota:",
  "ca": "Última nota:",
  "ar": "الملاحظة الأخيرة:"
 },
 "« Ce n'est pas la première fois que son nom apparaît. C'est la première fois que nous nous en souvenons. »": {
  "en": "“This is not the first time her name has appeared. It is the first time we remember it.”",
  "es": "« No es la primera vez que aparece su nombre. Es la primera vez que lo recordamos. »",
  "it": "« Non è la prima volta che compare il suo nome. È la prima volta che ce ne ricordiamo. »",
  "ca": "« No és la primera vegada que apareix el seu nom. És la primera vegada que el recordem. »",
  "ar": "« ليست هذه المرة الأولى التي يظهر فيها اسمها. إنها المرة الأولى التي نتذكره فيها. »"
 },
 "CODE ACCEPTÉ. SIGNATURE IDENTIFIÉE : LOOPING. DOSSIER PERSONNEL : JENNIFER DERIMIGHT.": {
  "en": "CODE ACCEPTED. SIGNATURE IDENTIFIED: LOOPING. PERSONAL FILE: JENNIFER DERIMIGHT.",
  "es": "CÓDIGO ACEPTADO. FIRMA IDENTIFICADA: LOOPING. EXPEDIENTE PERSONAL: JENNIFER DERIMIGHT.",
  "it": "CODICE ACCETTATO. FIRMA IDENTIFICATA: LOOPING. FASCICOLO PERSONALE: JENNIFER DERIMIGHT.",
  "ca": "CODI ACCEPTAT. SIGNATURA IDENTIFICADA: LOOPING. EXPEDIENT PERSONAL: JENNIFER DERIMIGHT.",
  "ar": "تم قبول الرمز. تم تحديد التوقيع: LOOPING. الملف الشخصي: JENNIFER DERIMIGHT."
 },
 "Accès temporaire accordé. Certaines données restent classifiées.": {
  "en": "Temporary access granted. Some data remains classified.",
  "es": "Acceso temporal concedido. Algunos datos siguen clasificados.",
  "it": "Accesso temporaneo concesso. Alcuni dati restano riservati.",
  "ca": "Accés temporal concedit. Algunes dades continuen classificades.",
  "ar": "تم منح وصول مؤقت. لا تزال بعض البيانات سرية."
 },
 "OUVRIR LE DOSSIER PERSONNEL — JENNIFER DERIMIGHT": {
  "en": "OPEN PERSONAL FILE — JENNIFER DERIMIGHT",
  "es": "OPEN PERSONAL FILE — JENNIFER DERIMIGHT",
  "it": "OPEN PERSONAL FILE — JENNIFER DERIMIGHT",
  "ca": "OPEN PERSONAL FILE — JENNIFER DERIMIGHT",
  "ar": "OPEN PERSONAL FILE — JENNIFER DERIMIGHT"
 },
 "Dossier verrouillé détecté : J.DERIMIGHT.": {
  "en": "Locked file detected: J.DERIMIGHT.",
  "es": "Archivo bloqueado detectado: J.DERIMIGHT.",
  "it": "Rilevato fascicolo bloccato: J.DERIMIGHT.",
  "ca": "S'ha detectat un expedient bloquejat: J.DERIMIGHT.",
  "ar": "تم اكتشاف ملف مقفل: J.DERIMIGHT."
 },
 "ANOMALIE CÉLESTE // OBSERVATION EN COURS": {
  "en": "CELESTIAL ANOMALY // UNDER OBSERVATION",
  "es": "ANOMALÍA CELESTE // EN OBSERVACIÓN",
  "it": "ANOMALIA CELESTE // OSSERVAZIONE IN CORSO",
  "ca": "ANOMALIA CELESTIAL // EN OBSERVACIÓ",
  "ar": "شذوذ سماوي // قيد المراقبة"
 },
 "Le Point Zéro prépare quelque chose.": {
  "en": "The Zero Point is preparing something.",
  "es": "El Punto Cero está preparando algo.",
  "it": "Il Punto Zero sta preparando qualcosa.",
  "ca": "El Punt Zero està preparant alguna cosa.",
  "ar": "نقطة الصفر تُحضّر شيئًا ما."
 },
 "LA VÉRITABLE RAISON DE LA DISPUTE": {
  "en": "THE REAL REASON FOR THE CONFLICT",
  "es": "LA VERDADERA RAZÓN DEL CONFLICTO",
  "it": "IL VERO MOTIVO DEL CONFLITTO",
  "ca": "LA VERITABLE RAÓ DEL CONFLICTE",
  "ar": "السبب الحقيقي للخلاف"
 },
 "??? — La mère de Jean et Ben": {
  "en": "??? — Jean and Ben’s mother",
  "es": "??? — La madre de Jean y Ben",
  "it": "??? — La madre di Jean e Ben",
  "ca": "??? — La mare d’en Jean i en Ben",
  "ar": "؟؟؟ — والدة جان وبن"
 },
 "Jennifer Derimight": {
  "en": "Jennifer Derimight",
  "es": "Jennifer Derimight",
  "it": "Jennifer Derimight",
  "ca": "Jennifer Derimight",
  "ar": "جينيفر ديرمايت"
 },
 "prépare quelque chose.": {
  "en": "is preparing something.",
  "es": "está preparando algo.",
  "it": "sta preparando qualcosa.",
  "ca": "està preparant alguna cosa.",
  "ar": "تُحضّر شيئًا ما."
 },
 "Un vortex violet se forme dans le ciel. Un rayon d'énergie descend vers l'île et une lueur violette apparaît au centre de la carte. L'Institut Onirique ne peut pas encore déterminer ce qui est en train d'apparaître.": {
  "en": "A purple vortex forms in the sky. A beam of energy descends toward the island, and a purple glow appears at the center of the map. The Oniric Institute cannot yet determine what is emerging.",
  "es": "Un vórtice violeta se forma en el cielo. Un rayo de energía desciende hacia la isla y un resplandor violeta aparece en el centro del mapa. El Instituto Onírico aún no puede determinar qué está apareciendo.",
  "it": "Un vortice viola si forma nel cielo. Un raggio di energia scende verso l’isola e un bagliore viola appare al centro della mappa. L’Istituto Onirico non riesce ancora a determinare cosa stia apparendo.",
  "ca": "Un vòrtex violeta es forma al cel. Un raig d’energia baixa cap a l’illa i una resplendor violeta apareix al centre del mapa. L’Institut Oníric encara no pot determinar què està apareixent.",
  "ar": "تتشكل دوامة أرجوانية في السماء. ينزل شعاع من الطاقة نحو الجزيرة، ويظهر وهج أرجواني في وسط الخريطة. لا يستطيع المعهد الحلمي بعد تحديد ما الذي بدأ بالظهور."
 },
 "THÈME DE L'ÉVÉNEMENT : NON DÉTERMINÉ // NE PAS CONCLURE AVANT L'APPARITION.": {
  "en": "EVENT THEME: UNDETERMINED // DO NOT DRAW CONCLUSIONS BEFORE IT APPEARS.",
  "es": "TEMA DEL EVENTO: SIN DETERMINAR // NO SACAR CONCLUSIONES ANTES DE SU APARICIÓN.",
  "it": "TEMA DELL’EVENTO: NON DETERMINATO // NON TRARRE CONCLUSIONI PRIMA DELLA COMPARSA.",
  "ca": "TEMA DE L’ESDEVENIMENT: INDETERMINAT // NO TREURE CONCLUSIONS ABANS DE L’APARICIÓ.",
  "ar": "موضوع الحدث: غير محدد // لا تستخلصوا استنتاجات قبل ظهوره."
 },
 "NOTE CONFIDENTIELLE · ÉVALUATION INTERNE": {
  "en": "CONFIDENTIAL NOTE · INTERNAL ASSESSMENT",
  "es": "NOTA CONFIDENCIAL · EVALUACIÓN INTERNA",
  "it": "NOTA RISERVATA · VALUTAZIONE INTERNA",
  "ca": "NOTA CONFIDENCIAL · AVALUACIÓ INTERNA",
  "ar": "ملاحظة سرية · تقييم داخلي"
 },
 "il ignore encore les véritables intentions de Jennifer. Ne pas lui révéler prématurément les conclusions de ce dossier.": {
  "en": "he still does not know Jennifer’s true intentions. Do not reveal this report’s conclusions to him prematurely.",
  "es": "todavía desconoce las verdaderas intenciones de Jennifer. No le reveles antes de tiempo las conclusiones de este informe.",
  "it": "non conosce ancora le vere intenzioni di Jennifer. Non rivelargli prematuramente le conclusioni di questo rapporto.",
  "ca": "encara desconeix les veritables intencions de Jennifer. No li revelis prematurament les conclusions d’aquest informe.",
  "ar": "لا يعرف بعد نوايا جينيفر الحقيقية. لا تكشف له استنتاجات هذا التقرير قبل الأوان."
 },
 "Le Point Zéro": {
  "en": "The Zero Point",
  "es": "El Punto Cero",
  "it": "Il Punto Zero",
  "ca": "El Punt Zero",
  "ar": "نقطة الصفر"
 },
 "SAISON 8 · ARCHIVE AUDIO RETROUVÉE": {
  "en": "SEASON 8 · RECOVERED AUDIO ARCHIVE",
  "es": "TEMPORADA 8 · ARCHIVO DE AUDIO RECUPERADO",
  "it": "STAGIONE 8 · ARCHIVIO AUDIO RECUPERATO",
  "ca": "TEMPORADA 8 · ARXIU D’ÀUDIO RECUPERAT",
  "ar": "الموسم 8 · أرشيف صوتي مستعاد"
 },
 "Bien avant leur séparation, Jean voulait que Kael rejoigne son équipe. Kael a refusé. Jean a vécu ce refus comme une trahison. La dispute a dégénéré : Jean a poussé Kael et l'a étranglé. Kael a fini par le repousser d'un coup franc, puis il s'est enfui à toute vitesse. Ce jour-là, leur amitié a été brisée.": {
  "en": "Long before they parted ways, Jean wanted Kael to join his team. Kael refused. Jean saw that refusal as a betrayal. The argument escalated: Jean shoved Kael and choked him. Kael managed to push him away with a sharp kick, then fled as fast as he could. Their friendship ended that day.",
  "es": "Mucho antes de separarse, Jean quería que Kael se uniera a su equipo. Kael se negó. Jean lo consideró una traición. La discusión empeoró: Jean empujó a Kael y lo estranguló. Kael consiguió apartarlo de una patada y huyó a toda velocidad. Aquel día terminó su amistad.",
  "it": "Molto prima di separarsi, Jean voleva che Kael entrasse nella sua squadra. Kael rifiutò. Jean interpretò quel rifiuto come un tradimento. La lite degenerò: Jean spinse Kael e lo strangolò. Kael riuscì ad allontanarlo con un calcio deciso e fuggì rapidamente. Quel giorno la loro amicizia finì.",
  "ca": "Molt abans de separar-se, Jean volia que Kael s'unís al seu equip. Kael s'hi va negar. Jean va viure el rebuig com una traïció. La discussió va empitjorar: Jean va empènyer Kael i el va escanyar. Kael el va apartar d'una puntada de peu i va fugir corrents. Aquell dia es va trencar la seva amistat.",
  "ar": "قبل انفصالهما بوقت طويل، أراد جان أن ينضم كايل إلى فريقه، لكن كايل رفض. اعتبر جان الرفض خيانة. وتصاعد الخلاف، فدفع جان كايل وخنقه. وتمكن كايل من إبعاده بركلة قوية ثم هرب بأقصى سرعة. في ذلك اليوم انتهت صداقتهما."
 },
 "Ben retrouve un ancien enregistrement contenant le récit de cette confrontation. En l'écoutant, il comprend que la rupture entre Jean et Kael ne venait pas d'un simple désaccord : Jean avait tenté de lui imposer sa volonté.": {
  "en": "Ben finds an old recording recounting the confrontation. As he listens, he realizes that Jean and Kael's falling-out was more than a simple disagreement: Jean had tried to force Kael to obey him.",
  "es": "Ben encuentra una antigua grabación sobre el enfrentamiento. Al escucharla, comprende que la ruptura entre Jean y Kael no fue un simple desacuerdo: Jean había intentado imponerle su voluntad.",
  "it": "Ben ritrova una vecchia registrazione dello scontro. Ascoltandola capisce che la rottura tra Jean e Kael non era dovuta a un semplice disaccordo: Jean aveva cercato di imporgli la propria volontà.",
  "ca": "Ben troba un enregistrament antic de l'enfrontament. En escoltar-lo, entén que la ruptura entre Jean i Kael no va ser un simple desacord: Jean havia intentat imposar-li la seva voluntat.",
  "ar": "يعثر بن على تسجيل قديم يروي تفاصيل المواجهة. وعندما يستمع إليه يدرك أن الخلاف بين جان وكايل لم يكن مجرد اختلاف في الرأي، بل إن جان حاول فرض إرادته على كايل."
 },
 "ENREGISTREMENT RÉCUPÉRÉ · K-ARCHIVE-01": {
  "en": "RECOVERED RECORDING · K-ARCHIVE-01",
  "es": "GRABACIÓN RECUPERADA · K-ARCHIVE-01",
  "it": "REGISTRAZIONE RECUPERATA · K-ARCHIVE-01",
  "ca": "ENREGISTRAMENT RECUPERAT · K-ARCHIVE-01",
  "ar": "تسجيل مستعاد · K-ARCHIVE-01"
 },
 "Reconstitution vocale du témoignage retrouvé": {
  "en": "Voice reconstruction of the recovered testimony",
  "es": "Reconstrucción de voz del testimonio recuperado",
  "it": "Ricostruzione vocale della testimonianza recuperata",
  "ca": "Reconstrucció de veu del testimoni recuperat",
  "ar": "إعادة تمثيل صوتية للشهادة المستعادة"
 },
 "ÉCOUTER L'ENREGISTREMENT ▶": {
  "en": "PLAY RECORDING ▶",
  "es": "ESCUCHAR GRABACIÓN ▶",
  "it": "ASCOLTA LA REGISTRAZIONE ▶",
  "ca": "ESCOLTA L’ENREGISTRAMENT ▶",
  "ar": "تشغيل التسجيل ▶"
 },
 "ARRÊTER L’ENREGISTREMENT ■": {
  "en": "STOP RECORDING ■",
  "es": "DETENER GRABACIÓN ■",
  "it": "FERMA LA REGISTRAZIONE ■",
  "ca": "ATURA L’ENREGISTRAMENT ■",
  "ar": "إيقاف التسجيل ■"
 },
 "Fichier audio : prêt à être lu.": {
  "en": "Audio file: ready to play.",
  "es": "Archivo de audio: listo para reproducir.",
  "it": "File audio: pronto per la riproduzione.",
  "ca": "Fitxer d’àudio: a punt per reproduir-se.",
  "ar": "الملف الصوتي جاهز للتشغيل."
 },
 "Lecture de l’archive audio…": {
  "en": "Playing audio archive…",
  "es": "Reproduciendo el archivo de audio…",
  "it": "Riproduzione dell’archivio audio…",
  "ca": "Reproduint l’arxiu d’àudio…",
  "ar": "جارٍ تشغيل الأرشيف الصوتي…"
 },
 "Lecture interrompue.": {
  "en": "Playback stopped.",
  "es": "Reproducción detenida.",
  "it": "Riproduzione interrotta.",
  "ca": "Reproducció aturada.",
  "ar": "تم إيقاف التشغيل."
 },
 "Fin de la lecture.": {
  "en": "Playback finished.",
  "es": "Reproducción finalizada.",
  "it": "Riproduzione terminata.",
  "ca": "Reproducció finalitzada.",
  "ar": "انتهى التشغيل."
 },
 "Impossible de lire le fichier audio.": {
  "en": "Unable to play the audio file.",
  "es": "No se puede reproducir el archivo de audio.",
  "it": "Impossibile riprodurre il file audio.",
  "ca": "No es pot reproduir el fitxer d’àudio.",
  "ar": "تعذر تشغيل الملف الصوتي."
 },
 "TRANSMISSION NON CLASSIFIÉE · IDENTITÉ MASQUÉE": {
  "en": "UNCLASSIFIED TRANSMISSION · IDENTITY CONCEALED",
  "es": "TRANSMISIÓN NO CLASIFICADA · IDENTIDAD OCULTA",
  "it": "TRASMISSIONE NON CLASSIFICATA · IDENTITÀ NASCOSTA",
  "ca": "TRANSMISSIÓ NO CLASSIFICADA · IDENTITAT OCULTA",
  "ar": "إرسال غير مصنف · هوية مخفية"
 },
 "« Pourquoi tu ne nous as jamais parlé de ce qui s'est passé avant tout ça ? »": {
  "en": "“Why did you never tell us what happened before all this?”",
  "es": "«¿Por qué nunca nos contaste lo que pasó antes de todo esto?»",
  "it": "«Perché non ci hai mai parlato di quello che è successo prima di tutto questo?»",
  "ca": "«Per què no ens vas explicar mai què havia passat abans de tot això?»",
  "ar": "«لماذا لم تخبرينا قط بما حدث قبل كل هذا؟»"
 },
 "« Parce que je pensais pouvoir vous protéger en gardant le silence. Je me suis trompée. »": {
  "en": "“Because I thought I could protect you by staying silent. I was wrong.”",
  "es": "«Porque pensé que podía protegeros guardando silencio. Me equivoqué».",
  "it": "«Perché pensavo di potervi proteggere restando in silenzio. Mi sbagliavo».",
  "ca": "«Perquè pensava que us podia protegir guardant silenci. Em vaig equivocar».",
  "ar": "«لأنني ظننت أن الصمت سيحمِيكما. لكنني كنت مخطئة.»"
 },
 "« Tu savais ce que je devenais. Tu aurais pu m'arrêter. »": {
  "en": "“You knew what I was becoming. You could have stopped me.”",
  "es": "«Sabías en qué me estaba convirtiendo. Podrías haberme detenido».",
  "it": "«Sapevi cosa stavo diventando. Avresti potuto fermarmi».",
  "ca": "«Sabies en què m’estava convertint. M’hauries pogut aturar».",
  "ar": "«كنتِ تعرفين ما الذي أصبحت عليه. كان بإمكانك إيقافي.»"
 },
 "« J'ai essayé de sauver mes deux fils. Mais je n'ai pas su vous empêcher de vous perdre. »": {
  "en": "“I tried to save both my sons. But I couldn’t stop you from losing your way.”",
  "es": "«Intenté salvar a mis dos hijos. Pero no pude evitar que os perdierais».",
  "it": "«Ho cercato di salvare entrambi i miei figli. Ma non sono riuscita a impedirvi di perdervi».",
  "ca": "«Vaig intentar salvar els meus dos fills. Però no vaig poder evitar que us perdéssiu».",
  "ar": "«حاولت إنقاذ ابنيّ كليهما، لكنني لم أستطع منعكما من الضياع.»"
 },
 "« Alors dis-nous la vérité. Pas ton nom. Pas encore. Juste la vérité. »": {
  "en": "“Then tell us the truth. Not your name. Not yet. Just the truth.”",
  "es": "«Entonces dinos la verdad. No tu nombre. Todavía no. Solo la verdad».",
  "it": "«Allora dicci la verità. Non il tuo nome. Non ancora. Solo la verità».",
  "ca": "«Doncs digue’ns la veritat. No el teu nom. Encara no. Només la veritat».",
  "ar": "«إذن أخبرينا بالحقيقة. ليس اسمكِ، ليس بعد. الحقيقة فقط.»"
 },
 "« La vérité ne vous rendra pas votre enfance. Mais elle peut vous empêcher de répéter les mêmes erreurs. »": {
  "en": "“The truth won’t give you back your childhood. But it may keep you from repeating the same mistakes.”",
  "es": "«La verdad no os devolverá la infancia. Pero puede evitar que repitáis los mismos errores».",
  "it": "«La verità non vi restituirà l’infanzia. Ma può impedirvi di ripetere gli stessi errori».",
  "ca": "«La veritat no us tornarà la infantesa. Però pot evitar que repetiu els mateixos errors».",
  "ar": "«لن تعيد إليكما الحقيقة طفولتكما، لكنها قد تمنعكما من تكرار الأخطاء نفسها.»"
 },
 "Son identité reste volontairement masquée. Son nom ne sera pas révélé dans cette mise à jour.": {
  "en": "Her identity remains deliberately concealed. Her name will not be revealed in this update.",
  "es": "Su identidad permanece oculta deliberadamente. Su nombre no se revelará en esta actualización.",
  "it": "La sua identità rimane volutamente nascosta. Il suo nome non sarà rivelato in questo aggiornamento.",
  "ca": "La seva identitat continua oculta expressament. El seu nom no es revelarà en aquesta actualització.",
  "ar": "تظل هويتها مخفية عمدًا، ولن يُكشف اسمها في هذا التحديث."
 },
 "Dossier personnel — Jennifer Derimight": {
  "en": "Personal file — Jennifer Derimight",
  "es": "Expediente personal — Jennifer Derimight",
  "it": "Fascicolo personale — Jennifer Derimight",
  "ca": "Expedient personal — Jennifer Derimight",
  "ar": "الملف الشخصي — جينيفر ديرامايت"
 },
 ". Dossier déverrouillé depuis le terminal central.": {
  "en": ". File unlocked from the central terminal.",
  "es": ". Expediente desbloqueado desde el terminal central.",
  "it": ". Fascicolo sbloccato dal terminale centrale.",
  "ca": ". Expedient desbloquejat des del terminal central.",
  "ar": ". تم فتح الملف من المحطة المركزية."
 },
 "Comportement observé": {
  "en": "Observed behavior",
  "es": "Comportamiento observado",
  "it": "Comportamento osservato",
  "ca": "Comportament observat",
  "ar": "السلوك الملحوظ"
 },
 "Jennifer Derimight donne une première impression douce et rassurante. Cette apparence masque pourtant des intentions dangereuses. Ne pas confondre son attitude aimable avec une preuve de confiance.": {
  "en": "Jennifer Derimight seems kind and reassuring at first. But her friendly appearance conceals dangerous intentions. Do not mistake her kindness for trustworthiness.",
  "es": "Jennifer Derimight parece amable y tranquilizadora al principio, pero oculta intenciones peligrosas. No confundas su amabilidad con una prueba de confianza.",
  "it": "Jennifer Derimight sembra gentile e rassicurante all’inizio, ma nasconde intenzioni pericolose. Non confondere la sua gentilezza con l’affidabilità.",
  "ca": "Jennifer Derimight sembla amable i tranquil·litzadora al principi, però amaga intencions perilloses. No confonguis la seva amabilitat amb una prova de confiança.",
  "ar": "تبدو جينيفر ديريمايت لطيفة ومطمئنة في البداية، لكنها تخفي نوايا خطيرة. لا تخلط بين لطفها وجدارتها بالثقة."
 },
 "Consulter les personnages": {
  "en": "View characters",
  "es": "Ver personajes",
  "it": "Visualizza i personaggi",
  "ca": "Consulta els personatges",
  "ar": "عرض الشخصيات"
 },
 "Les Échos du Zéro": {
  "en": "Echoes of the Zero",
  "es": "Los ecos del Cero",
  "it": "Gli echi dello Zero",
  "ca": "Els ecos del Zero",
  "ar": "أصداء الصفر"
 },
 "Nom de saison provisoire. La nouvelle île se dévoile : le Point Zéro domine Tower Zéro, tandis que de nouveaux territoires apparaissent au sud.": {
  "en": "Provisional season name. The new island emerges: the Zero Point dominates Tower Zero, while new territories appear in the south.",
  "es": "Nombre de temporada provisional. La nueva isla se revela: el Punto Cero domina Tower Zéro, mientras aparecen nuevos territorios al sur.",
  "it": "Nome provvisorio della stagione. La nuova isola si rivela: il Punto Zero domina Tower Zéro, mentre nuovi territori appaiono a sud.",
  "ca": "Nom provisional de la temporada. La nova illa es revela: el Punt Zero domina Tower Zéro, mentre apareixen nous territoris al sud.",
  "ar": "اسم الموسم مؤقت. تظهر الجزيرة الجديدة: تهيمن نقطة الصفر على Tower Zéro، بينما تظهر مناطق جديدة في الجنوب."
 },
 "Au centre de l'île, autour du Point Zéro. Ce secteur portait auparavant le nom de Freaky Zero.": {
  "en": "At the center of the island, around the Zero Point. This area was previously called Freaky Zero.",
  "es": "En el centro de la isla, alrededor del Punto Cero. Esta zona antes se llamaba Freaky Zero.",
  "it": "Al centro dell’isola, intorno al Punto Zero. Questa zona si chiamava Freaky Zero.",
  "ca": "Al centre de l’illa, al voltant del Punt Zero. Aquesta zona abans es deia Freaky Zero.",
  "ar": "في وسط الجزيرة، حول نقطة الصفر. كانت هذه المنطقة تُعرف سابقًا باسم Freaky Zero."
 },
 "Grande structure entourée d'un halo bleu, dans le sud de l'île.": {
  "en": "Large structure surrounded by a blue halo in the south of the island.",
  "es": "Gran estructura rodeada por un halo azul en el sur de la isla.",
  "it": "Grande struttura circondata da un alone blu nel sud dell’isola.",
  "ca": "Gran estructura envoltada d’un halo blau al sud de l’illa.",
  "ar": "منشأة كبيرة تحيط بها هالة زرقاء في جنوب الجزيرة."
 },
 "Plage avec une pointe caractéristique au sud-ouest de l'île.": {
  "en": "Beach with a distinctive point on the southwest coast of the island.",
  "es": "Playa con una punta característica en el suroeste de la isla.",
  "it": "Spiaggia con una punta caratteristica a sud-ovest dell’isola.",
  "ca": "Platja amb una punta característica al sud-oest de l’illa.",
  "ar": "شاطئ ذو رأس بارز في جنوب غرب الجزيرة."
 },
 "L'ancienne carte reste disponible dans les archives.": {
  "en": "The previous map remains available in the archives.",
  "es": "El mapa anterior sigue disponible en los archivos.",
  "it": "La mappa precedente rimane disponibile negli archivi.",
  "ca": "El mapa anterior continua disponible als arxius.",
  "ar": "لا تزال الخريطة السابقة متاحة في الأرشيف."
 },
 "ALYSS :": {
  "en": "ALYSS:",
  "es": "ALYSS:",
  "it": "ALYSS:",
  "ca": "ALYSS:",
  "ar": "أليس:"
 },
 "Le Fragment Zéro": {
  "zh": "零点碎片"
 },
 "Paramètres": {
  "zh": "设置"
 },
 "Français": {
  "zh": "法语"
 },
 "Anglais": {
  "zh": "英语"
 },
 "Espagnol": {
  "zh": "西班牙语"
 },
 "Italien": {
  "zh": "意大利语"
 },
 "Chinois": {
  "zh": "中文"
 },
 "Chapitre 2": {
  "zh": "第二章"
 },
 "Saison 1": {
  "zh": "第一季"
 },
 "Saison 2": {
  "zh": "第二季"
 },
 "Garde Zéro": {
  "zh": "零点守卫"
 },
 "Institut Onirique": {
  "zh": "梦境研究所"
 },
 "Langue": {
  "zh": "语言"
 },
 "LANGUAGE": {
  "zh": "语言"
 },
 "Retour": {
  "zh": "返回"
 },
 "Suivant": {
  "zh": "下一步"
 },
 "Précédent": {
  "zh": "上一步"
 },
 "Épisode": {
  "zh": "剧集"
 },
 "Épisodes": {
  "zh": "剧集"
 },
 "Lire": {
  "zh": "阅读"
 },
 "Écouter": {
  "zh": "收听"
 },
 "Rechercher": {
  "zh": "搜索"
 },
 "Envoyer": {
  "zh": "发送"
 },
 "Ouvrir": {
  "zh": "打开"
 },
 "Fermer": {
  "zh": "关闭"
 },
 "Réduire les animations": {
  "zh": "减少动画"
 },
 "Tester l’animation": {
  "zh": "测试动画"
 },
 "Thème": {
  "zh": "主题"
 },
 "Clair": {
  "zh": "浅色"
 },
 "Sombre": {
  "zh": "深色"
 }
};
