# V58 · Rapport de livraison

Base : V57.

Ajouts : carte interactive avec quatre repères pour la Saison 3, consultation des cartes archivées, terminal secondaire avec historique, commandes et accès aux dossiers, traduction des nouveaux composants en FR/EN/IT/ES, correctifs CSS mobile et suppression du second menu visuel.

Limites : les pages historiques conservent leur système de traduction hérité. Leur traduction intégrale n’est pas certifiée ; les quatre repères de la nouvelle carte sont positionnés approximativement et doivent être contrôlés visuellement. Les tests sur navigateurs réels ne sont pas effectués. Le terminal historique est conservé pour compatibilité.
