(() => {
  const button = document.getElementById('play-kael-recording');
  if (!button) return;
  const status = document.getElementById('recording-status');
  const led = document.querySelector('.recording-led');
  const audio = new Audio('assets/archive-k-ben-en.mp3');
  audio.preload = 'metadata';
  const labels = { play: "ÉCOUTER L'ENREGISTREMENT ▶", stop: 'ARRÊTER L’ENREGISTREMENT ■', ready: 'Fichier audio : prêt à être lu.', playing: 'Lecture de l’archive audio…', stopped: 'Lecture interrompue.', ended: 'Fin de la lecture.', error: 'Impossible de lire le fichier audio.' };
  let state = 'ready';
  function refresh() {
    const translate = key => window.FZ ? window.FZ.t(labels[key]) : labels[key];
    button.textContent = translate(audio.paused ? 'play' : 'stop');
    if (status) status.textContent = translate(state);
    led?.classList.toggle('is-playing', !audio.paused);
  }
  button.addEventListener('click', async () => {
    if (!audio.paused) { audio.pause(); state = 'stopped'; refresh(); return; }
    try { await audio.play(); state = 'playing'; refresh(); }
    catch (_) { state = 'error'; refresh(); }
  });
  audio.addEventListener('ended', () => { state = 'ended'; refresh(); });
  audio.addEventListener('error', () => { state = 'error'; refresh(); });
  document.addEventListener('fz:language', refresh);
  refresh();
})();
